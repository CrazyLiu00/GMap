﻿//  Original source code has been modified by AltSoftLab Inc. 2012-2015
//  This source code is provided "as is" without express or implied warranty of any kind.


using System;
using System.Collections.Generic;

using Alt.FarseerPhysics.Collision.Shapes;
using Alt.FarseerPhysics.Common;
using Alt.FarseerPhysics.Common.Decomposition;
using Alt.FarseerPhysics.Dynamics;

using Alt.Sketch;


namespace Alt.FarseerPhysics.Factories
{
    /// <summary>
    /// An easy to use factory for creating bodies
    /// </summary>
    public static class FixtureFactory
    {
        public static Fixture AttachEdge(Vector2 start, Vector2 end, Body body)
        {
            return AttachEdge(start, end, body, null);
        }
        public static Fixture AttachEdge(Vector2 start, Vector2 end, Body body, object userData)// = null)
        {
            EdgeShape edgeShape = new EdgeShape(start, end);
            return body.CreateFixture(edgeShape, userData);
        }

        public static Fixture AttachChainShape(Vertices vertices, Body body)
        {
            return AttachChainShape(vertices, body, null);
        }
        public static Fixture AttachChainShape(Vertices vertices, Body body, object userData)// = null)
        {
            ChainShape shape = new ChainShape(vertices);
            return body.CreateFixture(shape, userData);
        }

        public static Fixture AttachLoopShape(Vertices vertices, Body body)
        {
            return AttachLoopShape(vertices, body, null);
        }
        public static Fixture AttachLoopShape(Vertices vertices, Body body, object userData)// = null)
        {
            ChainShape shape = new ChainShape(vertices, true);
            return body.CreateFixture(shape, userData);
        }

        public static Fixture AttachRectangle(double width, double height, double density, Vector2 offset, Body body)
        {
            return AttachRectangle(width, height, density, offset, body, null);
        }
        public static Fixture AttachRectangle(double width, double height, double density, Vector2 offset, Body body, object userData)// = null)
        {
            Vertices rectangleVertices = PolygonTools.CreateRectangle(width / 2, height / 2);
            rectangleVertices.Translate(ref offset);
            PolygonShape rectangleShape = new PolygonShape(rectangleVertices, density);
            return body.CreateFixture(rectangleShape, userData);
        }

        public static Fixture AttachCircle(double radius, double density, Body body)
        {
            return AttachCircle(radius, density, body, null);
        }
        public static Fixture AttachCircle(double radius, double density, Body body, object userData)// = null)
        {
            if (radius <= 0)
                throw new ArgumentOutOfRangeException("radius", "Radius must be more than 0 meters");

            CircleShape circleShape = new CircleShape(radius, density);
            return body.CreateFixture(circleShape, userData);
        }

        public static Fixture AttachCircle(double radius, double density, Body body, Vector2 offset)
        {
            return AttachCircle(radius, density, body, offset, null);
        }
        public static Fixture AttachCircle(double radius, double density, Body body, Vector2 offset, object userData)// = null)
        {
            if (radius <= 0)
                throw new ArgumentOutOfRangeException("radius", "Radius must be more than 0 meters");

            CircleShape circleShape = new CircleShape(radius, density);
            circleShape.Position = offset;
            return body.CreateFixture(circleShape, userData);
        }

        public static Fixture AttachPolygon(Vertices vertices, double density, Body body)
        {
            return AttachPolygon(vertices, density, body, null);
        }
        public static Fixture AttachPolygon(Vertices vertices, double density, Body body, object userData)// = null)
        {
            if (vertices.Count <= 1)
                throw new ArgumentOutOfRangeException("vertices", "Too few points to be a polygon");

            PolygonShape polygon = new PolygonShape(vertices, density);
            return body.CreateFixture(polygon, userData);
        }

        public static Fixture AttachEllipse(double xRadius, double yRadius, int edges, double density, Body body)
        {
            return AttachEllipse(xRadius, yRadius, edges, density, body, null);
        }
        public static Fixture AttachEllipse(double xRadius, double yRadius, int edges, double density, Body body, object userData)// = null)
        {
            if (xRadius <= 0)
                throw new ArgumentOutOfRangeException("xRadius", "X-radius must be more than 0");

            if (yRadius <= 0)
                throw new ArgumentOutOfRangeException("yRadius", "Y-radius must be more than 0");

            Vertices ellipseVertices = PolygonTools.CreateEllipse(xRadius, yRadius, edges);
            PolygonShape polygonShape = new PolygonShape(ellipseVertices, density);
            return body.CreateFixture(polygonShape, userData);
        }

        public static List<Fixture> AttachCompoundPolygon(List<Vertices> list, double density, Body body)
        {
            return AttachCompoundPolygon(list, density, body, null);
        }
        public static List<Fixture> AttachCompoundPolygon(List<Vertices> list, double density, Body body, object userData)// = null)
        {
            List<Fixture> res = new List<Fixture>(list.Count);

            //Then we create several fixtures using the body
            foreach (Vertices vertices in list)
            {
                if (vertices.Count == 2)
                {
                    EdgeShape shape = new EdgeShape(vertices[0], vertices[1]);
                    res.Add(body.CreateFixture(shape, userData));
                }
                else
                {
                    PolygonShape shape = new PolygonShape(vertices, density);
                    res.Add(body.CreateFixture(shape, userData));
                }
            }

            return res;
        }

        public static Fixture AttachLineArc(double radians, int sides, double radius, bool closed, Body body)
        {
            Vertices arc = PolygonTools.CreateArc(radians, sides, radius);
            arc.Rotate((MathHelper.Pi - radians) / 2);
            return closed ? AttachLoopShape(arc, body) : AttachChainShape(arc, body);
        }

        public static List<Fixture> AttachSolidArc(double density, double radians, int sides, double radius, Body body)
        {
            Vertices arc = PolygonTools.CreateArc(radians, sides, radius);
            arc.Rotate((MathHelper.Pi - radians) / 2);

            //Close the arc
            arc.Add(arc[0]);

            List<Vertices> triangles = Triangulate.ConvexPartition(arc, TriangulationAlgorithm.Earclip);

            return AttachCompoundPolygon(triangles, density, body);
        }
    }
}