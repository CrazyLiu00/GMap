﻿//  Original source code has been modified by AltSoftLab Inc. 2012-2015
//  This source code is provided "as is" without express or implied warranty of any kind.


using System;
using System.Collections.Generic;

using Alt.FarseerPhysics.Collision.Shapes;
using Alt.FarseerPhysics.Common;
using Alt.FarseerPhysics.Common.Decomposition;
using Alt.FarseerPhysics.Dynamics;

using Alt.Sketch;


namespace Alt.FarseerPhysics.Factories
{
    public static class BodyFactory
    {
        //public static Body CreateBody(World world, Vector2 position = new Vector2(), double rotation = 0, BodyType bodyType = BodyType.Static, object userData = null)
        public static Body CreateBody(World world)
        {
            return CreateBody(world, new Vector2());
        }
        public static Body CreateBody(World world, Vector2 position)
        {
            return CreateBody(world, position, 0);
        }
        public static Body CreateBody(World world, Vector2 position, double rotation)
        {
            return CreateBody(world, position, rotation, BodyType.Static);
        }
        public static Body CreateBody(World world, Vector2 position, double rotation, BodyType bodyType)
        {
            return CreateBody(world, position, rotation, bodyType, null);
        }
        public static Body CreateBody(World world, Vector2 position, double rotation, BodyType bodyType, object userData)
        {
            return new Body(world, position, rotation, bodyType, userData);
        }

        public static Body CreateEdge(World world, Vector2 start, Vector2 end)
        {
            return CreateEdge(world, start, end, null);
        }
        public static Body CreateEdge(World world, Vector2 start, Vector2 end, object userData)// = null)
        {
            Body body = CreateBody(world);
            FixtureFactory.AttachEdge(start, end, body, userData);
            return body;
        }

        public static Body CreateChainShape(World world, Vertices vertices)
        {
            return CreateChainShape(world, vertices, new Vector2());
        }
        public static Body CreateChainShape(World world, Vertices vertices, Vector2 position)
        {
            return CreateChainShape(world, vertices, position, null);
        }
        public static Body CreateChainShape(World world, Vertices vertices, Vector2 position// = new Vector2()
            , object userData)// = null)
        {
            Body body = CreateBody(world, position);
            FixtureFactory.AttachChainShape(vertices, body, userData);
            return body;
        }

        public static Body CreateLoopShape(World world, Vertices vertices)
        {
            return CreateLoopShape(world, vertices, new Vector2());
        }
        public static Body CreateLoopShape(World world, Vertices vertices, Vector2 position)
        {
            return CreateLoopShape(world, vertices, position, null);
        }
        public static Body CreateLoopShape(World world, Vertices vertices, Vector2 position// = new Vector2()
            , object userData)// = null)
        {
            Body body = CreateBody(world, position);
            FixtureFactory.AttachLoopShape(vertices, body, userData);
            return body;
        }

        public static Body CreateRectangle(World world, double width, double height, double density)
        {
            return CreateRectangle(world, width, height, density, new Vector2());
        }
        public static Body CreateRectangle(World world, double width, double height, double density, Vector2 position)
        {
            return CreateRectangle(world, width, height, density, position, 0);
        }
        public static Body CreateRectangle(World world, double width, double height, double density, Vector2 position, double rotation)
        {
            return CreateRectangle(world, width, height, density, position, rotation, BodyType.Static);
        }
        public static Body CreateRectangle(World world, double width, double height, double density, Vector2 position, double rotation, BodyType bodyType)
        {
            return CreateRectangle(world, width, height, density, position, rotation, bodyType, null);
        }
        public static Body CreateRectangle(World world, double width, double height, double density, Vector2 position// = new Vector2()
            , double rotation// = 0
            , BodyType bodyType// = BodyType.Static
            , object userData)// = null)
        {
            if (width <= 0)
                throw new ArgumentOutOfRangeException("width", "Width must be more than 0 meters");

            if (height <= 0)
                throw new ArgumentOutOfRangeException("height", "Height must be more than 0 meters");

            Body newBody = CreateBody(world, position, rotation, bodyType);
            newBody.UserData = userData;

            Vertices rectangleVertices = PolygonTools.CreateRectangle(width / 2, height / 2);
            PolygonShape rectangleShape = new PolygonShape(rectangleVertices, density);
            newBody.CreateFixture(rectangleShape);

            return newBody;
        }

        public static Body CreateCircle(World world, double radius, double density)
        {
            return CreateCircle(world, radius, density, new Vector2());
        }
        public static Body CreateCircle(World world, double radius, double density, Vector2 position)
        {
            return CreateCircle(world, radius, density, position, BodyType.Static);
        }
        public static Body CreateCircle(World world, double radius, double density, Vector2 position, BodyType bodyType)
        {
            return CreateCircle(world, radius, density, position, bodyType, null);
        }
        public static Body CreateCircle(World world, double radius, double density, Vector2 position// = new Vector2()
            , BodyType bodyType// = BodyType.Static
            , object userData)// = null)
        {
            Body body = CreateBody(world, position, 0, bodyType);
            FixtureFactory.AttachCircle(radius, density, body, userData);
            return body;
        }

        public static Body CreateEllipse(World world, double xRadius, double yRadius, int edges, double density)
        {
            return CreateEllipse(world, xRadius, yRadius, edges, density, new Vector2());
        }
        public static Body CreateEllipse(World world, double xRadius, double yRadius, int edges, double density, Vector2 position)
        {
            return CreateEllipse(world, xRadius, yRadius, edges, density, position, 0);
        }
        public static Body CreateEllipse(World world, double xRadius, double yRadius, int edges, double density, Vector2 position, double rotation)
        {
            return CreateEllipse(world, xRadius, yRadius, edges, density, position, rotation, BodyType.Static);
        }
        public static Body CreateEllipse(World world, double xRadius, double yRadius, int edges, double density, Vector2 position, double rotation, BodyType bodyType)
        {
            return CreateEllipse(world, xRadius, yRadius, edges, density, position, rotation, bodyType, null);
        }
        public static Body CreateEllipse(World world, double xRadius, double yRadius, int edges, double density, Vector2 position// = new Vector2()
            , double rotation// = 0
            , BodyType bodyType// = BodyType.Static
            , object userData)// = null)
        {
            Body body = CreateBody(world, position, rotation, bodyType);
            FixtureFactory.AttachEllipse(xRadius, yRadius, edges, density, body, userData);
            return body;
        }

        public static Body CreatePolygon(World world, Vertices vertices, double density)
        {
            return CreatePolygon(world, vertices, density, new Vector2());
        }
        public static Body CreatePolygon(World world, Vertices vertices, double density, Vector2 position)
        {
            return CreatePolygon(world, vertices, density, position, 0);
        }
        public static Body CreatePolygon(World world, Vertices vertices, double density, Vector2 position, double rotation)
        {
            return CreatePolygon(world, vertices, density, position, rotation, BodyType.Static);
        }
        public static Body CreatePolygon(World world, Vertices vertices, double density, Vector2 position, double rotation, BodyType bodyType)
        {
            return CreatePolygon(world, vertices, density, position, rotation, bodyType, null);
        }
        public static Body CreatePolygon(World world, Vertices vertices, double density, Vector2 position// = new Vector2()
            , double rotation// = 0
            , BodyType bodyType// = BodyType.Static
            , object userData)// = null)
        {
            Body body = CreateBody(world, position, rotation, bodyType);
            FixtureFactory.AttachPolygon(vertices, density, body, userData);
            return body;
        }

        public static Body CreateCompoundPolygon(World world, List<Vertices> list, double density)
        {
            return CreateCompoundPolygon(world, list, density, new Vector2());
        }
        public static Body CreateCompoundPolygon(World world, List<Vertices> list, double density, Vector2 position)
        {
            return CreateCompoundPolygon(world, list, density, position, 0);
        }
        public static Body CreateCompoundPolygon(World world, List<Vertices> list, double density, Vector2 position, double rotation)
        {
            return CreateCompoundPolygon(world, list, density, position, rotation, BodyType.Static);
        }
        public static Body CreateCompoundPolygon(World world, List<Vertices> list, double density, Vector2 position, double rotation, BodyType bodyType)
        {
            return CreateCompoundPolygon(world, list, density, position, rotation, bodyType, null);
        }
        public static Body CreateCompoundPolygon(World world, List<Vertices> list, double density, Vector2 position// = new Vector2()
            , double rotation// = 0
            , BodyType bodyType// = BodyType.Static
            , object userData)// = null)
        {
            //We create a single body
            Body polygonBody = CreateBody(world, position, rotation, bodyType);
            FixtureFactory.AttachCompoundPolygon(list, density, polygonBody, userData);
            return polygonBody;
        }

        public static Body CreateGear(World world, double radius, int numberOfTeeth, double tipPercentage, double toothHeight, double density)
        {
            return CreateGear(world, radius, numberOfTeeth, tipPercentage, toothHeight, density, new Vector2());
        }
        public static Body CreateGear(World world, double radius, int numberOfTeeth, double tipPercentage, double toothHeight, double density, Vector2 position)
        {
            return CreateGear(world, radius, numberOfTeeth, tipPercentage, toothHeight, density, position, 0);
        }
        public static Body CreateGear(World world, double radius, int numberOfTeeth, double tipPercentage, double toothHeight, double density, Vector2 position, double rotation)
        {
            return CreateGear(world, radius, numberOfTeeth, tipPercentage, toothHeight, density, position, rotation, BodyType.Static);
        }
        public static Body CreateGear(World world, double radius, int numberOfTeeth, double tipPercentage, double toothHeight, double density, Vector2 position, double rotation, BodyType bodyType)
        {
            return CreateGear(world, radius, numberOfTeeth, tipPercentage, toothHeight, density, position, rotation, bodyType, null);
        }
        public static Body CreateGear(World world, double radius, int numberOfTeeth, double tipPercentage, double toothHeight, double density, Vector2 position// = new Vector2()
            , double rotation// = 0
            , BodyType bodyType// = BodyType.Static
            , object userData)// = null)
        {
            Vertices gearPolygon = PolygonTools.CreateGear(radius, numberOfTeeth, tipPercentage, toothHeight);

            //Gears can in some cases be convex
            if (!gearPolygon.IsConvex())
            {
                //Decompose the gear:
                List<Vertices> list = Triangulate.ConvexPartition(gearPolygon, TriangulationAlgorithm.Earclip);

                return CreateCompoundPolygon(world, list, density, position, rotation, bodyType, userData);
            }

            return CreatePolygon(world, gearPolygon, density, position, rotation, bodyType, userData);
        }

        public static Body CreateCapsule(World world, double height, double topRadius, int topEdges, double bottomRadius, int bottomEdges, double density)
        {
            return CreateCapsule(world, height, topRadius, topEdges, bottomRadius, bottomEdges, density, new Vector2());
        }
        public static Body CreateCapsule(World world, double height, double topRadius, int topEdges, double bottomRadius, int bottomEdges, double density, Vector2 position)
        {
            return CreateCapsule(world, height, topRadius, topEdges, bottomRadius, bottomEdges, density, position, 0);
        }
        public static Body CreateCapsule(World world, double height, double topRadius, int topEdges, double bottomRadius, int bottomEdges, double density, Vector2 position, double rotation)
        {
            return CreateCapsule(world, height, topRadius, topEdges, bottomRadius, bottomEdges, density, position, rotation, BodyType.Static);
        }
        public static Body CreateCapsule(World world, double height, double topRadius, int topEdges, double bottomRadius, int bottomEdges, double density, Vector2 position, double rotation, BodyType bodyType)
        {
            return CreateCapsule(world, height, topRadius, topEdges, bottomRadius, bottomEdges, density, position, rotation, bodyType, null);
        }
        public static Body CreateCapsule(World world, double height, double topRadius, int topEdges, double bottomRadius, int bottomEdges, double density, Vector2 position// = new Vector2()
            , double rotation// = 0
            , BodyType bodyType// = BodyType.Static
            , object userData)// = null)
        {
            Vertices verts = PolygonTools.CreateCapsule(height, topRadius, topEdges, bottomRadius, bottomEdges);

            //There are too many vertices in the capsule. We decompose it.
            if (verts.Count >= Settings.MaxPolygonVertices)
            {
                List<Vertices> vertList = Triangulate.ConvexPartition(verts, TriangulationAlgorithm.Earclip);
                return CreateCompoundPolygon(world, vertList, density, position, rotation, bodyType, userData);
            }

            return CreatePolygon(world, verts, density, position, rotation, bodyType, userData);
        }

        public static Body CreateCapsule(World world, double height, double endRadius, double density)
        {
            return CreateCapsule(world, height, endRadius, density, new Vector2());
        }
        public static Body CreateCapsule(World world, double height, double endRadius, double density, Vector2 position)
        {
            return CreateCapsule(world, height, endRadius, density, position, 0);
        }
        public static Body CreateCapsule(World world, double height, double endRadius, double density, Vector2 position, double rotation)
        {
            return CreateCapsule(world, height, endRadius, density, position, rotation, BodyType.Static);
        }
        public static Body CreateCapsule(World world, double height, double endRadius, double density, Vector2 position, double rotation, BodyType bodyType)
        {
            return CreateCapsule(world, height, endRadius, density, position, rotation, bodyType, null);
        }
        public static Body CreateCapsule(World world, double height, double endRadius, double density, Vector2 position// = new Vector2()
            , double rotation// = 0
            , BodyType bodyType// = BodyType.Static
            , object userData)// = null)
        {
            //Create the middle rectangle
            Vertices rectangle = PolygonTools.CreateRectangle(endRadius, height / 2);

            List<Vertices> list = new List<Vertices>();
            list.Add(rectangle);

            Body body = CreateCompoundPolygon(world, list, density, position, rotation, bodyType, userData);
            FixtureFactory.AttachCircle(endRadius, density, body, new Vector2(0, height / 2));
            FixtureFactory.AttachCircle(endRadius, density, body, new Vector2(0, -(height / 2)));

            //Create the two circles
            //CircleShape topCircle = new CircleShape(endRadius, density);
            //topCircle.Position = new Vector2(0, height / 2);
            //body.CreateFixture(topCircle);

            //CircleShape bottomCircle = new CircleShape(endRadius, density);
            //bottomCircle.Position = new Vector2(0, -(height / 2));
            //body.CreateFixture(bottomCircle);
            return body;
        }

        public static Body CreateRoundedRectangle(World world, double width, double height, double xRadius, double yRadius, int segments, double density)
        {
            return CreateRoundedRectangle(world, width, height, xRadius, yRadius, segments, density, new Vector2());
        }
        public static Body CreateRoundedRectangle(World world, double width, double height, double xRadius, double yRadius, int segments, double density, Vector2 position)
        {
            return CreateRoundedRectangle(world, width, height, xRadius, yRadius, segments, density, position, 0);
        }
        public static Body CreateRoundedRectangle(World world, double width, double height, double xRadius, double yRadius, int segments, double density, Vector2 position, double rotation)
        {
            return CreateRoundedRectangle(world, width, height, xRadius, yRadius, segments, density, position, rotation, BodyType.Static);
        }
        public static Body CreateRoundedRectangle(World world, double width, double height, double xRadius, double yRadius, int segments, double density, Vector2 position, double rotation, BodyType bodyType)
        {
            return CreateRoundedRectangle(world, width, height, xRadius, yRadius, segments, density, position, rotation, bodyType, null);
        }
        public static Body CreateRoundedRectangle(World world, double width, double height, double xRadius, double yRadius, int segments, double density, Vector2 position// = new Vector2()
            , double rotation// = 0
            , BodyType bodyType// = BodyType.Static
            , object userData)// = null)
        {
            Vertices verts = PolygonTools.CreateRoundedRectangle(width, height, xRadius, yRadius, segments);

            //There are too many vertices in the capsule. We decompose it.
            if (verts.Count >= Settings.MaxPolygonVertices)
            {
                List<Vertices> vertList = Triangulate.ConvexPartition(verts, TriangulationAlgorithm.Earclip);
                return CreateCompoundPolygon(world, vertList, density, position, rotation, bodyType, userData);
            }

            return CreatePolygon(world, verts, density, position, rotation, bodyType, userData);
        }

        public static Body CreateLineArc(World world, double radians, int sides, double radius)
        {
            return CreateLineArc(world, radians, sides, radius, false);
        }
        public static Body CreateLineArc(World world, double radians, int sides, double radius, bool closed)
        {
            return CreateLineArc(world, radians, sides, radius, closed, new Vector2());
        }
        public static Body CreateLineArc(World world, double radians, int sides, double radius, bool closed, Vector2 position)
        {
            return CreateLineArc(world, radians, sides, radius, closed, position, 0);
        }
        public static Body CreateLineArc(World world, double radians, int sides, double radius, bool closed, Vector2 position, double rotation)
        {
            return CreateLineArc(world, radians, sides, radius, closed, position, rotation, BodyType.Static);
        }
        public static Body CreateLineArc(World world, double radians, int sides, double radius, bool closed// = false
            , Vector2 position// = new Vector2()
            , double rotation// = 0
            , BodyType bodyType)// = BodyType.Static)
        {
            Body body = CreateBody(world, position, rotation, bodyType);
            FixtureFactory.AttachLineArc(radians, sides, radius, closed, body);
            return body;
        }

        public static Body CreateSolidArc(World world, double density, double radians, int sides, double radius)
        {
            return CreateSolidArc(world, density, radians, sides, radius, new Vector2());
        }
        public static Body CreateSolidArc(World world, double density, double radians, int sides, double radius, Vector2 position)
        {
            return CreateSolidArc(world, density, radians, sides, radius, position, 0);
        }
        public static Body CreateSolidArc(World world, double density, double radians, int sides, double radius, Vector2 position, double rotation)
        {
            return CreateSolidArc(world, density, radians, sides, radius, position, rotation, BodyType.Static);
        }
        public static Body CreateSolidArc(World world, double density, double radians, int sides, double radius, Vector2 position// = new Vector2()
            , double rotation// = 0
            , BodyType bodyType)// = BodyType.Static)
        {
            Body body = CreateBody(world, position, rotation, bodyType);
            FixtureFactory.AttachSolidArc(density, radians, sides, radius, body);

            return body;
        }

        public static BreakableBody CreateBreakableBody(World world, Vertices vertices, double density)
        {
            return CreateBreakableBody(world, vertices, density, new Vector2());
        }
        public static BreakableBody CreateBreakableBody(World world, Vertices vertices, double density, Vector2 position)
        {
            return CreateBreakableBody(world, vertices, density, position, 0);
        }
        public static BreakableBody CreateBreakableBody(World world, Vertices vertices, double density, Vector2 position// = new Vector2()
            , double rotation)// = 0)
        {
            //TODO: Implement a Voronoi diagram algorithm to split up the vertices
            List<Vertices> triangles = Triangulate.ConvexPartition(vertices, TriangulationAlgorithm.Earclip);

            BreakableBody breakableBody = new BreakableBody(world, triangles, density, position, rotation);
            breakableBody.MainBody.Position = position;
            world.AddBreakableBody(breakableBody);
            return breakableBody;
        }

        public static BreakableBody CreateBreakableBody(World world, IEnumerable<Shape> shapes)
        {
            return CreateBreakableBody(world, shapes, new Vector2());
        }
        public static BreakableBody CreateBreakableBody(World world, IEnumerable<Shape> shapes, Vector2 position)
        {
            return CreateBreakableBody(world, shapes, position, 0);
        }
        public static BreakableBody CreateBreakableBody(World world, IEnumerable<Shape> shapes, Vector2 position// = new Vector2()
            , double rotation)// = 0)
        {
            BreakableBody breakableBody = new BreakableBody(world, shapes, position, rotation);
            breakableBody.MainBody.Position = position;
            world.AddBreakableBody(breakableBody);
            return breakableBody;
        }
    }
}
