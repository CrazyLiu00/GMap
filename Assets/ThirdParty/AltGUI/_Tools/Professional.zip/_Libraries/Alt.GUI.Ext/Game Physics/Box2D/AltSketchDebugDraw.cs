﻿//  Copyright (C) 2012-2015 AltSoftLab Inc.
//  This source code is provided "as is" without express or implied warranty of any kind.


using System;
using System.Collections.Generic;

using Alt.Sketch;


namespace Alt.Box2D
{
    public class AltSketchDebugDraw : DebugDraw
    {
        public Font m_Font;
        public Brush m_FontBrush = Brushes.White;
        public Graphics m_Graphics;
        double m_Scale = 1;
        Matrix4 m_ViewMatrix = Matrix4.Identity;
        const double m_LineThickness = 1.5;
        double m_FillColorScale = 0.5;

        
        public AltSketchDebugDraw()
        {
        }


        public void SetViewTransform(double dx, double dy, double scale)
        {
            m_Scale = scale;

            m_ViewMatrix = Matrix4.CreateTranslation(dx, dy);
            m_ViewMatrix.Scale(m_Scale, -m_Scale);
        }


        public override void DrawPolygon(ref FixedArray8<Vector2> vertices, int count, Color color)
        {
            if (count == 2)
            {
                DrawSegment(vertices[0], vertices[1], color);
                return;
            }

            Vector2[] verts;
            Vector2 offset = TransformToO(vertices, count, out verts);

            m_Graphics.TranslateTransform(offset);
            {
                m_Graphics.DrawPolygon(new Pen(color, m_LineThickness), verts);
            }
            m_Graphics.TranslateTransform(-offset);
        }


        public override void DrawSolidPolygon(ref FixedArray8<Vector2> vertices, int count, Color color)
        {
            DrawSolidPolygon(ref vertices, count, color, true);
        }

        void DrawSolidPolygon(ref FixedArray8<Vector2> vertices, int count, Color color, bool outline)
        {
            if (count == 2)
            {
                DrawSegment(vertices[0], vertices[1], color);
                return;
            }

            Color colorFill = color * (outline ? m_FillColorScale : 1.0);

            Vector2[] verts;
            Vector2 offset = TransformToO(vertices, count, out verts);
            m_Graphics.TranslateTransform(offset);
            {
                m_Graphics.FillPolygon(colorFill, verts);
            }
            m_Graphics.TranslateTransform(-offset);

            if (outline)
            {
                DrawPolygon(ref vertices, count, color);
            }
        }


        public override void DrawCircle(Vector2 center, double radius, Color color)
        {
            Vector2 offset = Transform(center);
            m_Graphics.TranslateTransform(offset);
            {
                m_Graphics.DrawCircle(new Pen(color, m_LineThickness), Vector2.Zero, radius * m_Scale);
            }
            m_Graphics.TranslateTransform(-offset);
        }


        public override void DrawSolidCircle(Vector2 center, double radius, Vector2 axis, Color color)
        {
            Vector2 offset = Transform(center);
            m_Graphics.TranslateTransform(offset);
            {
                m_Graphics.FillCircle(color * m_FillColorScale, Vector2.Zero, radius * m_Scale);
                m_Graphics.DrawCircle(new Pen(color, m_LineThickness), Vector2.Zero, radius * m_Scale);
            }
            m_Graphics.TranslateTransform(-offset);

            DrawSegment(center, center + axis * radius, color);
        }


        public override void DrawSegment(Vector2 p1, Vector2 p2, Color color)
        {
            m_Graphics.DrawLine(new Pen(color, m_LineThickness), Transform(p1), Transform(p2));
        }


        public override void DrawTransform(ref Transform xf)
        {
            double axisScale = 0.4;
            Vector2 p1 = xf.Position;
            
            Vector2 p2 = p1 + axisScale * xf.R.col1;
            DrawSegment(p1, p2, Color.Red);

            p2 = p1 + axisScale * xf.R.col2;
            DrawSegment(p1, p2, Color.Green);
        }


        public void DrawPoint(Vector2 p, double size, Color color)
        {
            Vector2 hs = new Vector2(size * (m_Scale / 2) / 2.0);
            m_Graphics.FillRectangle(color, Transform(p) - hs, Transform(p) + hs);
        }


        public void DrawString(int x, int y, string s)
        {
            DrawString(x, y, s, null);
        }

        public void DrawString(int x, int y, string s, params object[] args)
        {
            var text = args == null ? s : string.Format(s, args);
            m_Graphics.DrawString(text, m_Font, m_FontBrush, x, y);
        }


        public void DrawAABB(ref AABB aabb, Color color)
        {
            m_Graphics.DrawRectangle(color, Transform(aabb.GetCenter() - aabb.GetExtents()), Transform(aabb.GetCenter() + aabb.GetExtents()));
        }


        Vector2 Transform(Vector2 v)
        {
            Vector2 temp = m_ViewMatrix.Transform(v);

            //  triangulation cache optimization (values lesser 0.1 pixel - no matters)
            {
                double k = 10;
                temp *= k;
                temp = temp.ToPointI().ToVector2();
                temp /= k;
            }

            return temp;
        }

        Vector2 TransformToO(FixedArray8<Vector2> vertices, int count, out Vector2[] verts)
        {
            Vector2 offset = Transform(vertices[0]);
            verts = new Vector2[count];
            Vector2 temp = Vector2.Zero;
            for (int i = 0; i < count; i++)
            {
                verts[i] = temp = Transform(vertices[i]);

                if (offset.X > temp.X)
                {
                    offset.X = temp.X;
                }

                if (offset.Y > temp.Y)
                {
                    offset.Y = temp.Y;
                }
            }

            //  triangulation cache optimization
            for (int i = 0; i < count; i++)
            {
                verts[i] = verts[i] - offset;
            }

            return offset;
        }
    }
}
