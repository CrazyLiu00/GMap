﻿/*
* Farseer Physics Engine:
* Copyright (c) 2012 Ian Qvist
*/

//  Original source code has been modified by AltSoftLab Inc. 2012-2015
//  This source code is provided "as is" without express or implied warranty of any kind.


using System.Collections.Generic;
using System.Diagnostics;

using Alt.FarseerPhysics.Common.Decomposition.Seidel;

using Alt.Sketch;

using Point = Alt.FarseerPhysics.Common.Decomposition.Seidel.Point;


namespace Alt.FarseerPhysics.Common.Decomposition
{
    /// <summary>
    /// Convex decomposition algorithm created by Raimund Seidel
    /// 
    /// Properties:
    /// - Decompose the polygon into trapezoids, then triangulate.
    /// - To use the trapezoid data, use ConvexPartitionTrapezoid()
    /// - Generate a lot of garbage due to incapsulation of the Poly2Tri library.
    /// - Running time is O(n log n), n = number of vertices.
    /// - Running time is almost linear for most simple polygons.
    /// - Does not care about winding order. 
    /// 
    /// For more information, see Raimund Seidel's paper "A simple and fast incremental randomized
    /// algorithm for computing trapezoidal decompositions and for triangulating polygons"
    /// 
    /// See also: "Computational Geometry", 3rd edition, by Mark de Berg et al, Chapter 6.2
    ///           "Computational Geometry in C", 2nd edition, by Joseph O'Rourke
    /// 
    /// Original code from the Poly2Tri project by Mason Green.
    /// http://code.google.com/p/poly2tri/source/browse?repo=archive#hg/scala/src/org/poly2tri/seidel
    /// 
    /// This implementation is from Dec 14, 2010
    /// </summary>
    internal static class SeidelDecomposer
    {
        /// <summary>
        /// Decompose the polygon into several smaller non-concave polygons.
        /// </summary>
        /// <param name="vertices">The polygon to decompose.</param>
        /// <param name="sheer">The sheer to use if you get bad results, try using a higher value.</param>
        /// <returns>A list of triangles</returns>
        public static List<Vertices> ConvexPartition(Vertices vertices)
        {
            return ConvexPartition(vertices, 0.001f);
        }
        public static List<Vertices> ConvexPartition(Vertices vertices, double sheer)// = 0.001f)
        {
            Debug.Assert(vertices.Count > 3);

            List<Seidel.Point> compatList = new List<Seidel.Point>(vertices.Count);

            foreach (Vector2 vertex in vertices)
            {
                compatList.Add(new Seidel.Point(vertex.X, vertex.Y));
            }

            Triangulator t = new Triangulator(compatList, sheer);

            List<Vertices> list = new List<Vertices>();

            foreach (List<Seidel.Point> triangle in t.Triangles)
            {
                Vertices outTriangles = new Vertices(triangle.Count);

                foreach (Seidel.Point outTriangle in triangle)
                {
                    outTriangles.Add(new Vector2(outTriangle.X, outTriangle.Y));
                }

                list.Add(outTriangles);
            }

            return list;
        }

        /// <summary>
        /// Decompose the polygon into several smaller non-concave polygons.
        /// </summary>
        /// <param name="vertices">The polygon to decompose.</param>
        /// <param name="sheer">The sheer to use if you get bad results, try using a higher value.</param>
        /// <returns>A list of trapezoids</returns>
        public static List<Vertices> ConvexPartitionTrapezoid(Vertices vertices)
        {
            return ConvexPartitionTrapezoid(vertices, 0.001f);
        }
        public static List<Vertices> ConvexPartitionTrapezoid(Vertices vertices, double sheer)// = 0.001f)
        {
            List<Seidel.Point> compatList = new List<Seidel.Point>(vertices.Count);

            foreach (Vector2 vertex in vertices)
            {
                compatList.Add(new Seidel.Point(vertex.X, vertex.Y));
            }

            Triangulator t = new Triangulator(compatList, sheer);

            List<Vertices> list = new List<Vertices>();

            foreach (Trapezoid trapezoid in t.Trapezoids)
            {
                Vertices verts = new Vertices();

                List<Seidel.Point> points = trapezoid.GetVertices();
                foreach (Seidel.Point point in points)
                {
                    verts.Add(new Vector2(point.X, point.Y));
                }

                list.Add(verts);
            }

            return list;
        }
    }
}