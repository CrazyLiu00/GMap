//  Copyright (C) 2012-2015 AltSoftLab Inc.
//  This source code is provided "as is" without express or implied warranty of any kind.


using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

using Alt.FarseerPhysics.Collision;
using Alt.FarseerPhysics.Collision.Shapes;
using Alt.FarseerPhysics.Common;
using Alt.FarseerPhysics.Controllers;
using Alt.FarseerPhysics.Dynamics;
using Alt.FarseerPhysics.Dynamics.Contacts;
using Alt.FarseerPhysics.Dynamics.Joints;

using Alt.Sketch;


namespace Alt.FarseerPhysics
{
    /// <summary>
    /// A debug view shows you what happens inside the physics engine. You can view
    /// bodies, joints, fixtures and more.
    /// </summary>
    public class AltSketchDebugViewExt : DebugViewBase, IDisposable
    {
        public Font m_Font;
        public Brush m_FontBrush = Brushes.White;
        public Graphics m_Graphics;
        double m_Scale = 1;
        Matrix4 m_ViewMatrix = Matrix4.Identity;
        const double m_LineThickness = 1.5;
        double m_FillColorScale = 0.5;


        struct ContactPoint
        {
            public Vector2 Normal;
            public Vector2 Position;
            public PointState State;
        }


        struct StringData
        {
            public Color Color;
            public string Text;
            public Vector2 Position;

            public StringData(Vector2 position, string text, Color color)
            {
                Position = position;
                Text = text;
                Color = color;
            }
        }


        //Drawing
        Vector2[] _tempVertices = new Vector2[Settings.MaxPolygonVertices];
        
        Matrix4 _localProjection;
        Matrix4 _localView;

        //Shapes
        public Color DefaultShapeColor = new ColorR(0.9, 0.7, 0.7);
        public Color InactiveShapeColor = new ColorR(0.5, 0.5, 0.3);
        public Color KinematicShapeColor = new ColorR(0.5, 0.5, 0.9);
        public Color SleepingShapeColor = new ColorR(0.6, 0.6, 0.6);
        public Color StaticShapeColor = new ColorR(0.5, 0.9, 0.5);
        public Color TextColor = Color.White;

        //Contacts
        int _pointCount;
        const int MaxContactPoints = 2048;
        ContactPoint[] _points = new ContactPoint[MaxContactPoints];

        //Debug panel
        public Vector2 DebugPanelPosition = new Vector2(55, 100);
        double _max;
        double _avg;
        double _min;

        //Performance graph
        public bool AdaptiveLimits = true;
        public int ValuesToGraph = 500;
        public double MinimumValue;
        public double MaximumValue = 10;
        List<double> _graphValues = new List<double>(500);
        public RectI PerformancePanelBounds = new RectI(330, 100, 200, 100);
        Vector2[] _background = new Vector2[4];
        public bool Enabled = true;

#if XBOX || WINDOWS_PHONE
        public const int CircleSegments = 16;
#else
        public const int CircleSegments = 32;
#endif

        public AltSketchDebugViewExt(World world)
            : base(world)
        {
            if (world != null)
            {
                world.ContactManager.PreSolve += PreSolve;
            }

            //Default flags
            AppendFlags(DebugViewFlags.Shape);
            AppendFlags(DebugViewFlags.Controllers);
            AppendFlags(DebugViewFlags.Joint);
        }


        public void Dispose()
        {
            World.ContactManager.PreSolve -= PreSolve;
        }


        public void SetViewTransform(double dx, double dy, double scale)
        {
            m_Scale = scale;

            m_ViewMatrix = Matrix4.CreateTranslation(dx, dy);
            m_ViewMatrix.Scale(m_Scale, -m_Scale);
        }


        void PreSolve(Contact contact, ref Manifold oldManifold)
        {
            if ((Flags & DebugViewFlags.ContactPoints) == DebugViewFlags.ContactPoints)
            {
                Manifold manifold = contact.Manifold;

                if (manifold.PointCount == 0)
                    return;

                Fixture fixtureA = contact.FixtureA;

                FixedArray2<PointState> state1, state2;
                Collision.Collision.GetPointStates(out state1, out state2, ref oldManifold, ref manifold);

                FixedArray2<Vector2> points;
                Vector2 normal;
                contact.GetWorldManifold(out normal, out points);

                for (int i = 0; i < manifold.PointCount && _pointCount < MaxContactPoints; ++i)
                {
                    if (fixtureA == null)
                    {
                        _points[i] = new ContactPoint();
                    }

                    ContactPoint cp = _points[_pointCount];
                    cp.Position = points[i];
                    cp.Normal = normal;
                    cp.State = state2[i];
                    _points[_pointCount] = cp;
                    ++_pointCount;
                }
            }
        }


        /// <summary>
        /// Call this to draw shapes and other debug draw data.
        /// </summary>
        void DrawDebugData()
        {
            if ((Flags & DebugViewFlags.Shape) == DebugViewFlags.Shape)
            {
                foreach (Body b in World.BodyList)
                {
                    Common.Transform xf;
                    b.GetTransform(out xf);
                    foreach (Fixture f in b.FixtureList)
                    {
                        if (b.Enabled == false)
                            DrawShape(f, xf, InactiveShapeColor);
                        else if (b.BodyType == BodyType.Static)
                            DrawShape(f, xf, StaticShapeColor);
                        else if (b.BodyType == BodyType.Kinematic)
                            DrawShape(f, xf, KinematicShapeColor);
                        else if (b.Awake == false)
                            DrawShape(f, xf, SleepingShapeColor);
                        else
                            DrawShape(f, xf, DefaultShapeColor);
                    }
                }
            }

            if ((Flags & DebugViewFlags.ContactPoints) == DebugViewFlags.ContactPoints)
            {
                const double axisScale = 0.3f;

                for (int i = 0; i < _pointCount; ++i)
                {
                    ContactPoint point = _points[i];

                    if (point.State == PointState.Add)
                        DrawPoint(point.Position, 0.1, new ColorR(0.3, 0.95, 0.3));
                    else if (point.State == PointState.Persist)
                        DrawPoint(point.Position, 0.1, new ColorR(0.3, 0.3, 0.95));

                    if ((Flags & DebugViewFlags.ContactNormals) == DebugViewFlags.ContactNormals)
                    {
                        Vector2 p1 = point.Position;
                        Vector2 p2 = p1 + axisScale * point.Normal;
                        DrawSegment(p1, p2, new ColorR(0.4, 0.9, 0.4));
                    }
                }

                _pointCount = 0;
            }

            if ((Flags & DebugViewFlags.PolygonPoints) == DebugViewFlags.PolygonPoints)
            {
                foreach (Body body in World.BodyList)
                {
                    foreach (Fixture f in body.FixtureList)
                    {
                        PolygonShape polygon = f.Shape as PolygonShape;
                        if (polygon != null)
                        {
                            Common.Transform xf;
                            body.GetTransform(out xf);

                            for (int i = 0; i < polygon.Vertices.Count; i++)
                            {
                                Vector2 tmp = MathUtils.Mul(ref xf, polygon.Vertices[i]);
                                DrawPoint(tmp, 0.1, Color.Red);
                            }
                        }
                    }
                }
            }

            if ((Flags & DebugViewFlags.Joint) == DebugViewFlags.Joint)
            {
                foreach (Joint j in World.JointList)
                {
                    DrawJoint(j);
                }
            }

            if ((Flags & DebugViewFlags.AABB) == DebugViewFlags.AABB)
            {
                Color color = new ColorR(0.9, 0.3, 0.9);
                IBroadPhase bp = World.ContactManager.BroadPhase;

                foreach (Body body in World.BodyList)
                {
                    if (body.Enabled == false)
                        continue;

                    foreach (Fixture f in body.FixtureList)
                    {
                        for (int t = 0; t < f.ProxyCount; ++t)
                        {
                            FixtureProxy proxy = f.Proxies[t];
                            AABB aabb;
                            bp.GetFatAABB(proxy.ProxyId, out aabb);

                            DrawAABB(ref aabb, color);
                        }
                    }
                }
            }

            if ((Flags & DebugViewFlags.CenterOfMass) == DebugViewFlags.CenterOfMass)
            {
                foreach (Body b in World.BodyList)
                {
                    Common.Transform xf;
                    b.GetTransform(out xf);
                    xf.p = b.WorldCenter;
                    DrawTransform(ref xf);
                }
            }

            if ((Flags & DebugViewFlags.Controllers) == DebugViewFlags.Controllers)
            {
                for (int i = 0; i < World.ControllerList.Count; i++)
                {
                    Controller controller = World.ControllerList[i];

                    BuoyancyController buoyancy = controller as BuoyancyController;
                    if (buoyancy != null)
                    {
                        AABB container = buoyancy.Container;
                        DrawAABB(ref container, Color.LightBlue);
                    }
                }
            }

            if ((Flags & DebugViewFlags.DebugPanel) == DebugViewFlags.DebugPanel)
            {
                DrawDebugPanel();
            }
        }

        
        void DrawPerformanceGraph()
        {
            //  Draw background
            m_Graphics.FillRectangle(Color.DarkGray * m_FillColorScale, PerformancePanelBounds);


            _graphValues.Add(World.UpdateTime / TimeSpan.TicksPerMillisecond);

            if (_graphValues.Count > ValuesToGraph + 1)
            {
                _graphValues.RemoveAt(0);
            }

            double x = PerformancePanelBounds.X;
            double deltaX = PerformancePanelBounds.Width / (double)ValuesToGraph;
            double yScale = PerformancePanelBounds.Bottom - (double)PerformancePanelBounds.Top - 2;

            // we must have at least 2 values to start rendering
            if (_graphValues.Count > 2)
            {
                _max = EnumerableHelper.Max(_graphValues);//.Max();
                _avg = EnumerableHelper.Average(_graphValues);//.Average();
                _min = EnumerableHelper.Min(_graphValues);//.Min();

                if (AdaptiveLimits)
                {
                    MaximumValue = _max;
                    MinimumValue = 0;
                }

                // start at last value (newest value added)
                // continue until no values are left
                Vector2[] points = new Vector2[_graphValues.Count];
                double MaximumValueMinusMinimumValue = MaximumValue - MinimumValue;
                for (int i = _graphValues.Count - 1; i >= 0; i--)
                {
                    double y1 = PerformancePanelBounds.Bottom - ((_graphValues[i] / (MaximumValueMinusMinimumValue)) * yScale);
                
                    points[i] = Transform(
                        new Vector2(MathHelper.Clamp(x, PerformancePanelBounds.Left, PerformancePanelBounds.Right),
                            MathHelper.Clamp(y1, PerformancePanelBounds.Top, PerformancePanelBounds.Bottom)));

                    x += deltaX;
                }
                SmoothingMode saveSmoothingMode = m_Graphics.SmoothingMode;
                //  triangulation optimization
                if (!(m_Graphics is SoftwareGraphics))
                {
                    m_Graphics.SmoothingMode = SmoothingMode.None;
                }
                m_Graphics.DrawLines(Pens.LightGreen, points);
                m_Graphics.SmoothingMode = saveSmoothingMode;
            }


            //  Draw background contour
            m_Graphics.DrawRectangle(Color.DarkGray, PerformancePanelBounds);


            DrawString(PerformancePanelBounds.Right + 10, PerformancePanelBounds.Top, string.Format("Max: {0} ms", _max));
            DrawString(PerformancePanelBounds.Right + 10, PerformancePanelBounds.Center.Y - 7, string.Format("Avg: {0} ms", _avg));
            DrawString(PerformancePanelBounds.Right + 10, PerformancePanelBounds.Bottom - 15, string.Format("Min: {0} ms", _min));
        }

        
        void DrawDebugPanel()
        {
            int fixtureCount = 0;
            for (int i = 0; i < World.BodyList.Count; i++)
            {
                fixtureCount += World.BodyList[i].FixtureList.Count;
            }

            int x = (int)DebugPanelPosition.X;
            int y = (int)DebugPanelPosition.Y;

            StringBuilder _debugPanelSb = new StringBuilder();
            _debugPanelSb.AppendLine("Objects:");
            _debugPanelSb.Append("- Bodies: ").AppendLine(World.BodyList.Count.ToString());
            _debugPanelSb.Append("- Fixtures: ").AppendLine(fixtureCount.ToString());
            _debugPanelSb.Append("- Contacts: ").AppendLine(World.ContactList.Count.ToString());
            _debugPanelSb.Append("- Joints: ").AppendLine(World.JointList.Count.ToString());
            _debugPanelSb.Append("- Controllers: ").AppendLine(World.ControllerList.Count.ToString());
            _debugPanelSb.Append("- Proxies: ").AppendLine(World.ProxyCount.ToString());
            DrawString(x, y, _debugPanelSb.ToString());

            _debugPanelSb = new StringBuilder();
            _debugPanelSb.AppendLine("Update time:");
            _debugPanelSb.Append("- Body: ").AppendLine(string.Format("{0} ms", World.SolveUpdateTime / TimeSpan.TicksPerMillisecond));
            _debugPanelSb.Append("- Contact: ").AppendLine(string.Format("{0} ms", World.ContactsUpdateTime / TimeSpan.TicksPerMillisecond));
            _debugPanelSb.Append("- CCD: ").AppendLine(string.Format("{0} ms", World.ContinuousPhysicsTime / TimeSpan.TicksPerMillisecond));
            _debugPanelSb.Append("- Joint: ").AppendLine(string.Format("{0} ms", World.Island.JointUpdateTime / TimeSpan.TicksPerMillisecond));
            _debugPanelSb.Append("- Controller: ").AppendLine(string.Format("{0} ms", World.ControllersUpdateTime / TimeSpan.TicksPerMillisecond));
            _debugPanelSb.Append("- Total: ").AppendLine(string.Format("{0} ms", World.UpdateTime / TimeSpan.TicksPerMillisecond));
            DrawString(x + 110, y, _debugPanelSb.ToString());
        }


        public void DrawAABB(ref AABB aabb, Color color)
        {
            m_Graphics.DrawRectangle(color, Transform(aabb.Center - aabb.Extents), Transform(aabb.Center + aabb.Extents));
        }

        
        void DrawJoint(Joint joint)
        {
            if (!joint.Enabled)
                return;

            Body b1 = joint.BodyA;
            Body b2 = joint.BodyB;
            Common.Transform xf1;
            b1.GetTransform(out xf1);

            Vector2 x2 = Vector2.Zero;

            // WIP David
            if (!joint.IsFixedType())
            {
                Common.Transform xf2;
                b2.GetTransform(out xf2);
                x2 = xf2.p;
            }

            Vector2 p1 = joint.WorldAnchorA;
            Vector2 p2 = joint.WorldAnchorB;
            Vector2 x1 = xf1.p;

            Color color = new ColorR(0.5, 0.8, 0.8);

            switch (joint.JointType)
            {
                case JointType.Distance:
                    DrawSegment(p1, p2, color);
                    break;
                case JointType.Pulley:
                    PulleyJoint pulley = (PulleyJoint)joint;
                    Vector2 s1 = b1.GetWorldPoint(pulley.LocalAnchorA);
                    Vector2 s2 = b2.GetWorldPoint(pulley.LocalAnchorB);
                    DrawSegment(p1, p2, color);
                    DrawSegment(p1, s1, color);
                    DrawSegment(p2, s2, color);
                    break;
                case JointType.FixedMouse:
                    DrawPoint(p1, 0.5f, new ColorR(0.0, 1.0, 0.0));
                    DrawSegment(p1, p2, new ColorR(0.8, 0.8, 0.8));
                    break;
                case JointType.Revolute:
                    DrawSegment(x1, p1, color);
                    DrawSegment(p1, p2, color);
                    DrawSegment(x2, p2, color);

                    DrawSolidCircle(p2, 0.1, Vector2.Zero, Color.Red);
                    DrawSolidCircle(p1, 0.1, Vector2.Zero, Color.Blue);
                    break;
                case JointType.FixedAngle:
                    //Should not draw anything.
                    break;
                case JointType.FixedRevolute:
                    DrawSegment(x1, p1, color);
                    DrawSolidCircle(p1, 0.1, Vector2.Zero, Color.Pink);
                    break;
                case JointType.FixedLine:
                    DrawSegment(x1, p1, color);
                    DrawSegment(p1, p2, color);
                    break;
                case JointType.FixedDistance:
                    DrawSegment(x1, p1, color);
                    DrawSegment(p1, p2, color);
                    break;
                case JointType.FixedPrismatic:
                    DrawSegment(x1, p1, color);
                    DrawSegment(p1, p2, color);
                    break;
                case JointType.Gear:
                    DrawSegment(x1, x2, color);
                    break;
                default:
                    DrawSegment(x1, p1, color);
                    DrawSegment(p1, p2, color);
                    DrawSegment(x2, p2, color);
                    break;
            }
        }


        public void DrawShape(Fixture fixture, Common.Transform xf, Color color)
        {
            switch (fixture.Shape.ShapeType)
            {
                case ShapeType.Circle:
                    {
                        CircleShape circle = (CircleShape)fixture.Shape;

                        Vector2 center = MathUtils.Mul(ref xf, circle.Position);
                        double radius = circle.Radius;
                        Vector2 axis = MathUtils.Mul(xf.q, new Vector2(1.0, 0.0));

                        DrawSolidCircle(center, radius, axis, color);
                    }
                    break;

                case ShapeType.Polygon:
                    {
                        PolygonShape poly = (PolygonShape)fixture.Shape;
                        int vertexCount = poly.Vertices.Count;
                        Debug.Assert(vertexCount <= Settings.MaxPolygonVertices);

                        for (int i = 0; i < vertexCount; ++i)
                        {
                            _tempVertices[i] = MathUtils.Mul(ref xf, poly.Vertices[i]);
                        }

                        DrawSolidPolygon(_tempVertices, vertexCount, color);
                    }
                    break;


                case ShapeType.Edge:
                    {
                        EdgeShape edge = (EdgeShape)fixture.Shape;
                        Vector2 v1 = MathUtils.Mul(ref xf, edge.Vertex1);
                        Vector2 v2 = MathUtils.Mul(ref xf, edge.Vertex2);
                        DrawSegment(v1, v2, color);
                    }
                    break;

                case ShapeType.Chain:
                    {
                        ChainShape chain = (ChainShape)fixture.Shape;

                        for (int i = 0; i < chain.Vertices.Count - 1; ++i)
                        {
                            Vector2 v1 = MathUtils.Mul(ref xf, chain.Vertices[i]);
                            Vector2 v2 = MathUtils.Mul(ref xf, chain.Vertices[i + 1]);
                            DrawSegment(v1, v2, color);
                        }
                    }
                    break;
            }
        }


        public override void DrawPolygon(Vector2[] vertices, int count, double red, double green, double blue, bool closed)// = true)
        {
            DrawPolygon(vertices, count, new ColorR(red, green, blue), closed);
        }

        public void DrawPolygon(Vector2[] vertices, int count, Color color)
        {
            DrawPolygon(vertices, count, color, true);
        }
        public void DrawPolygon(Vector2[] vertices, int count, Color color, bool closed)// = true)
        {
            if (count == 2)
            {
                DrawSegment(vertices[0], vertices[1], color);
                return;
            }

            Vector2[] verts;
            Vector2 offset = TransformToO(vertices, count, out verts);

            m_Graphics.TranslateTransform(offset);
            {
                if (closed)
                {
                    m_Graphics.DrawPolygon(new Pen(color, m_LineThickness), verts);
                }
                else
                {
                    m_Graphics.DrawLines(new Pen(color, m_LineThickness), verts);
                }
            }
            m_Graphics.TranslateTransform(-offset);
        }


        public override void DrawSolidPolygon(Vector2[] vertices, int count, double red, double green, double blue)
        {
            DrawSolidPolygon(vertices, count, new ColorR(red, green, blue));
        }

        public void DrawSolidPolygon(Vector2[] vertices, int count, Color color)
        {
            DrawSolidPolygon(vertices, count, color, true);
        }
        public void DrawSolidPolygon(Vector2[] vertices, int count, Color color, bool outline)// = true)
        {
            if (count == 2)
            {
                DrawSegment(vertices[0], vertices[1], color);
                return;
            }

            Color colorFill = color * (outline ? m_FillColorScale : 1.0);

            Vector2[] verts;
            Vector2 offset = TransformToO(vertices, count, out verts);
            m_Graphics.TranslateTransform(offset);
            {
                m_Graphics.FillPolygon(colorFill, verts);
            }
            m_Graphics.TranslateTransform(-offset);

            if (outline)
            {
                DrawPolygon(vertices, count, color);
            }
        }


        public override void DrawCircle(Vector2 center, double radius, double red, double green, double blue)
        {
            DrawCircle(center, radius, new ColorR(red, green, blue));
        }

        public void DrawCircle(Vector2 center, double radius, Color color)
        {
            Vector2 offset = Transform(center);
            m_Graphics.TranslateTransform(offset);
            {
                m_Graphics.DrawCircle(new Pen(color, m_LineThickness), Vector2.Zero, radius * m_Scale);
            }
            m_Graphics.TranslateTransform(-offset);
        }


        public override void DrawSolidCircle(Vector2 center, double radius, Vector2 axis, double red, double green, double blue)
        {
            DrawSolidCircle(center, radius, axis, new ColorR(red, green, blue));
        }

        public void DrawSolidCircle(Vector2 center, double radius, Vector2 axis, Color color)
        {
            Vector2 offset = Transform(center);
            m_Graphics.TranslateTransform(offset);
            {
                m_Graphics.FillCircle(color * m_FillColorScale, Vector2.Zero, radius * m_Scale);
                m_Graphics.DrawCircle(new Pen(color, m_LineThickness), Vector2.Zero, radius * m_Scale);
            }
            m_Graphics.TranslateTransform(-offset);

            DrawSegment(center, center + axis * radius, color);
        }


        public override void DrawSegment(Vector2 start, Vector2 end, double red, double green, double blue)
        {
            DrawSegment(start, end, new ColorR(red, green, blue));
        }

        public void DrawSegment(Vector2 start, Vector2 end, Color color)
        {
            m_Graphics.DrawLine(new Pen(color, m_LineThickness), Transform(start), Transform(end));
        }


        public override void DrawTransform(ref Common.Transform transform)
        {
            const double axisScale = 0.4;
            Vector2 p1 = transform.p;

            Vector2 p2 = p1 + axisScale * transform.q.GetXAxis();
            DrawSegment(p1, p2, Color.Red);

            p2 = p1 + axisScale * transform.q.GetYAxis();
            DrawSegment(p1, p2, Color.Green);
        }


        public void DrawPoint(Vector2 p, double size, Color color)
        {
            Vector2 hs = new Vector2(size * (m_Scale / 2) / 2.0);
            m_Graphics.FillRectangle(color, Transform(p) - hs, Transform(p) + hs);
        }


        public void DrawString(int x, int y, string text)
        {
            DrawString(new Vector2(x, y), text);
        }

        public void DrawString(Vector2 position, string text)
        {
            m_Graphics.DrawString(text, m_Font, m_FontBrush, position);
        }


        public void DrawArrow(Vector2 start, Vector2 end, double length, double width, bool drawStartIndicator, Color color)
        {
            // Draw connection segment between start- and end-point
            DrawSegment(start, end, color);

            // Precalculate halfwidth
            double halfWidth = width / 2;

            // Create directional reference
            Vector2 rotation = (start - end);
            rotation.Normalize();

            // Calculate angle of directional vector
            double angle = (double)Math.Atan2(rotation.X, -rotation.Y);
            // Create matrix for rotation
            Matrix4 rotMatrix = Matrix4.CreateRotationZ(angle);
            // Create translation matrix for end-point
            Matrix4 endMatrix = Matrix4.CreateTranslation(end.X, end.Y, 0);

            // Setup arrow end shape
            Vector2[] verts = new Vector2[3];
            verts[0] = new Vector2(0, 0);
            verts[1] = new Vector2(-halfWidth, -length);
            verts[2] = new Vector2(halfWidth, -length);

            // Rotate end shape
            Vector2.Transform(verts, ref rotMatrix, verts);
            // Translate end shape
            Vector2.Transform(verts, ref endMatrix, verts);

            // Draw arrow end shape
            DrawSolidPolygon(verts, 3, color, false);

            if (drawStartIndicator)
            {
                // Create translation matrix for start
                Matrix4 startMatrix = Matrix4.CreateTranslation(start.X, start.Y, 0);
                // Setup arrow start shape
                Vector2[] baseVerts = new Vector2[4];
                baseVerts[0] = new Vector2(-halfWidth, length / 4);
                baseVerts[1] = new Vector2(halfWidth, length / 4);
                baseVerts[2] = new Vector2(halfWidth, 0);
                baseVerts[3] = new Vector2(-halfWidth, 0);

                // Rotate start shape
                Vector2.Transform(baseVerts, ref rotMatrix, baseVerts);
                // Translate start shape
                Vector2.Transform(baseVerts, ref startMatrix, baseVerts);
                // Draw start shape
                DrawSolidPolygon(baseVerts, 4, color, false);
            }
        }


        public void RenderDebugData()
        {
            if (!Enabled)
            {
                return;
            }

            //Nothing is enabled - don't draw the debug view.
            if (Flags == 0)
            {
                return;
            }


            DrawDebugData();


            if ((Flags & DebugViewFlags.PerformanceGraph) == DebugViewFlags.PerformanceGraph)
            {
                Matrix4 viewMatrix = m_ViewMatrix;
                m_ViewMatrix = Matrix4.Identity;
                {
                    DrawPerformanceGraph();
                }
                m_ViewMatrix = viewMatrix;
            }
        }


        Vector2 Transform(Vector2 v)
        {
            Vector2 temp = m_ViewMatrix.Transform(v);

            //  triangulation cache optimization (values lesser 0.1 pixel - no matters)
            {
                double k = 10;
                temp *= k;
                temp = temp.ToPointI().ToVector2();
                temp /= k;
            }

            return temp;
        }

        Vector2 TransformToO(Vector2[] vertices, int count, out Vector2[] verts)
        {
            Vector2 offset = Transform(vertices[0]);
            verts = new Vector2[count];
            Vector2 temp = Vector2.Zero;
            for (int i = 0; i < count; i++)
            {
                verts[i] = temp = Transform(vertices[i]);

                if (offset.X > temp.X)
                {
                    offset.X = temp.X;
                }

                if (offset.Y > temp.Y)
                {
                    offset.Y = temp.Y;
                }
            }

            //  triangulation cache optimization
            for (int i = 0; i < count; i++)
            {
                verts[i] = verts[i] - offset;
            }

            return offset;
        }
    }
}
