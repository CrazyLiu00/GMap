//  Original source code has been modified by AltSoftLab Inc. 2012-2015
//  This source code is provided "as is" without express or implied warranty of any kind.

using System;
using System.Diagnostics;

using Alt.Sketch;


namespace Alt.GUI.PieChart
{
    /// <summary>
    ///  Quadrilateral object.
    /// </summary>
    class Quadrilateral : IDisposable
    {
        /// <summary>
        ///   Creates empty <c>Quadrilateral</c> object
        /// </summary>
        protected Quadrilateral()
        {
        }


        /// <summary>
        ///   Initilizes <c>Quadrilateral</c> object with given corner points.
        /// </summary>
        /// <param name="point1">
        ///   First <c>Point</c>.
        /// </param>
        /// <param name="point2">
        ///   Second <c>Point</c>.
        /// </param>
        /// <param name="point3">
        ///   Third <c>Point</c>.
        /// </param>
        /// <param name="point4">
        ///   Fourth <c>Point</c>.
        /// </param>
        /// <param name="toClose">
        ///   Indicator should the quadrilateral be closed by the line.
        /// </param>
        public Quadrilateral(Point point1, Point point2, Point point3, Point point4, bool toClose)
        {
            /*byte[] pointTypes = (byte[])s_quadrilateralPointTypes.Clone();
            if (toClose)
                pointTypes[3] |= (byte)PathPointType.CloseSubpath;
            m_path = new GraphicsPath(new Point[] { point1, point2, point3, point4 }, pointTypes);*/

            m_path = new GraphicsPath();
            if (toClose)
            {
                m_path.AddLines(new Point[] { point1, point2, point3, point4 });
                m_path.CloseFigure();
                //m_path.AddPolygon(new Point[] { point1, point2, point3, point4 });
            }
            else
            {
                m_path.AddLines(new Point[] { point1, point2, point3, point4 });
            }
        }


        /// <summary>
        ///   <c>Finalize</c> method.
        /// </summary>
        ~Quadrilateral()
        {
            Dispose(false);
        }


        /// <summary>
        ///   Implementation of <c>IDisposable</c> interface.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        /// <summary>
        ///   Disposes of all pie slices.
        /// </summary>
        protected virtual void Dispose(bool disposing)
        {
            if (!m_disposed)
            {
                if (disposing)
                {
                    m_path.Dispose();
                }
                m_disposed = true;
            }
        }


        /// <summary>
        ///   Draws the <c>Quadrilateral</c> with <c>Graphics</c> provided.
        /// </summary>
        /// <param name="graphics">
        ///   <c>Graphics</c> used to draw.
        /// </param>
        /// <param name="pen">
        ///   <c>Pen</c> used to draw outline.
        /// </param>
        /// <param name="brush">
        ///   <c>Brush</c> used to fill the inside. 
        /// </param>
        public void Draw(Graphics graphics, Pen pen, Brush brush)
        {
            graphics.FillPath(brush, m_path);
            graphics.DrawPath(pen, m_path);
        }


        /// <summary>
        ///   Checks if the given <c>Point</c> is contained within the 
        ///   quadrilateral.
        /// </summary>
        /// <param name="point">
        ///   <c>Point</c> structure to check for.
        /// </param>
        /// <returns>
        ///   <c>true</c> if the point is contained within the quadrilateral.
        /// </returns>
        public bool Contains(Point point)
        {
            if (m_path.PointCount == 0 || m_path.PathPoints.Length == 0)
                return false;
            return Contains(point, m_path.PathPoints);
        }


        /// <summary>
        ///   Checks if given <c>Point</c> is contained within quadrilateral
        ///   defined by <c>cornerPoints</c> provided.
        /// </summary>
        /// <param name="point">
        ///   <c>Point</c> to check.
        /// </param>
        /// <param name="cornerPoints">
        ///   Array of <c>Point</c> structures defining corners of the
        ///   quadrilateral.
        /// </param>
        /// <returns>
        ///   <c>true</c> if the point is contained within the quadrilateral.
        /// </returns>
        public static bool Contains(Point point, Point[] cornerPoints)
        {
            int intersections = 0;
            for (int i = 1; i < cornerPoints.Length; ++i)
            {
                if (DoesIntersect(point, cornerPoints[i], cornerPoints[i - 1]))
                    ++intersections;
            }
            if (DoesIntersect(point, cornerPoints[cornerPoints.Length - 1], cornerPoints[0]))
                ++intersections;
            return (intersections % 2 != 0);
        }


        /// <summary>
        ///   Checks if the line coming out of the <c>point</c> downwards 
        ///   intersects with a line through <c>point1</c> and <c>point2</c>.
        /// </summary>
        /// <param name="point">
        ///   <c>Point</c> from which vertical line is drawn downwards.
        /// </param>
        /// <param name="point1">
        ///   First <c>Point</c> through which line is drawn.
        /// </param>
        /// <param name="point2">
        ///   Second <c>Point</c> through which line is drawn.
        /// </param>
        /// <returns>
        ///   <c>true</c> if lines intersect.
        /// </returns>
        private static bool DoesIntersect(Point point, Point point1, Point point2)
        {
            double x2 = point2.X;
            double y2 = point2.Y;
            double x1 = point1.X;
            double y1 = point1.Y;
            if ((x2 < point.X && x1 >= point.X) || (x2 >= point.X && x1 < point.X))
            {
                double y = (y2 - y1) / (x2 - x1) * (point.X - x1) + y1;
                return y > point.Y;
            }
            return false;
        }


        /// <summary>
        ///   <c>GraphicsPath</c> representing the quadrilateral.
        /// </summary>
        GraphicsPath m_path = new GraphicsPath();

        
        bool m_disposed = false;


        /*NoNeed
        /// <summary>
        ///   <c>PathPointType</c>s decribing the <c>GraphicsPath</c> points.
        /// </summary>
        static byte[] s_quadrilateralPointTypes = new byte[]  {   
                                                                          (byte)PathPointType.Start,
                                                                          (byte)PathPointType.Line,
                                                                          (byte)PathPointType.Line,
                                                                          (byte)PathPointType.Line | (byte)PathPointType.CloseSubpath 
                                                                      };*/

        internal static readonly Quadrilateral Empty = new Quadrilateral();
    }
}
