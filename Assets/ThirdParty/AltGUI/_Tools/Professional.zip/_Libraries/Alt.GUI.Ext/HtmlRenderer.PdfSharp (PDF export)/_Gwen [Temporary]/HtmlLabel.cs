//  Copyright (C) 2012-2015 AltSoftLab Inc.
//  This source code is provided "as is" without express or implied warranty of any kind.

using System;

using Alt.ComponentModel;
using Alt.Sketch;

using Alt.GUI.HtmlRenderer;
using Alt.GUI.HtmlRenderer.Adapters.Entities;
using Alt.GUI.HtmlRenderer.Core;
using Alt.GUI.HtmlRenderer.Core.Entities;

using Alt.GUI.Temporary.Gwen;
using Alt.GUI.Temporary.Gwen.Control;


namespace Alt.GUI.HtmlRenderer.Temporary.Gwen
{
    /// <summary>
    /// Provides HTML rendering using the text property.<br/>
    /// AltGUI control that will render html content in it's client rectangle.<br/>
    /// Using <see cref="AutoSize"/> and <see cref="AutoSizeHeightOnly"/> client can control how the html content effects the
    /// size of the label. Either case scrollbars are never shown and html content outside of client bounds will be clipped.
    /// <see cref="MaximumSize"/> and <see cref="MinimumSize"/> with AutoSize can limit the max/min size of the control<br/>
    /// The control will handle mouse and keyboard events on it to support html text selection, copy-paste and mouse clicks.<br/>
    /// <para>
    /// The major differential to use HtmlPanel or HtmlLabel is size and scrollbars.<br/>
    /// If the size of the control depends on the html content the HtmlLabel should be used.<br/>
    /// If the size is set by some kind of layout then HtmlPanel is more suitable, also shows scrollbars if the html contents is larger than the control client rectangle.<br/>
    /// </para>
    /// <para>
    /// <h4>AutoSize:</h4>
    /// <u>AutoSize = AutoSizeHeightOnly = false</u><br/>
    /// The label size will not change by the html content. MaximumSize and MinimumSize are ignored.<br/>
    /// <br/>
    /// <u>AutoSize = true</u><br/>
    /// The width and height is adjustable by the html content, the width will be longest line in the html, MaximumSize.Width will restrict it but it can be lower than that.<br/>
    /// <br/>
    /// <u>AutoSizeHeightOnly = true</u><br/>
    /// The width of the label is set and will not change by the content, the height is adjustable by the html content with restrictions to the MaximumSize.Height and MinimumSize.Height values.<br/>
    /// </para>
    /// <para>
    /// <h4>LinkClicked event</h4>
    /// Raised when the user clicks on a link in the html.<br/>
    /// Allows canceling the execution of the link.
    /// </para>
    /// <para>
    /// <h4>StylesheetLoad event:</h4>
    /// Raised when aa stylesheet is about to be loaded by file path or URI by link element.<br/>
    /// This event allows to provide the stylesheet manually or provide new source (file or uri) to load from.<br/>
    /// If no alternative data is provided the original source will be used.<br/>
    /// </para>
    /// <para>
    /// <h4>ImageLoad event:</h4>
    /// Raised when an image is about to be loaded by file path or URI.<br/>
    /// This event allows to provide the image manually, if not handled the image will be loaded from file or download from URI.
    /// </para>
    /// <para>
    /// <h4>RenderError event:</h4>
    /// Raised when an error occurred during html rendering.<br/>
    /// </para>
    /// </summary>
    public class HtmlLabel :
        //Base
        DoubleBufferedControl, IHtmlControl
    {
        public Point MouseLocation
        {
            get
            {
                return PointToClient(MousePosition);
            }
        }

        public GUI.MouseButtons GetMouseButtons()
        {
            return MouseButtons;
        }

        void IHtmlControl.Invalidate()
        {
            Refresh();
        }


        /// <summary>
        /// 
        /// </summary>
        HtmlContainer _htmlContainer;

        /// <summary>
        /// the raw base stylesheet data used in the control
        /// </summary>
        string _baseRawCssData;

        /// <summary>
        /// the base stylesheet data used in the panel
        /// </summary>
        CssData _baseCssData;

        /// <summary>
        /// is to handle auto size of the control height only
        /// </summary>
        bool _autoSizeHight;


        public Color BackColor
        {
            get
            {
                return ClientBackColor;
            }
            set
            {
                ClientBackColor = value;
            }
        }


        TextRenderingHint m_TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
        public TextRenderingHint TextRenderingHint
        {
            get
            {
                return m_TextRenderingHint;
            }
            set
            {
                m_TextRenderingHint = value;

                Refresh();
            }
        }


        /// <summary>
        /// Creates a new HTML Label
        /// </summary>
        public HtmlLabel(Base parent)
            : base(parent)
        {
            this.SoftwareRender = true;

            AutoSize = true;
            ClientBackColor = Color.White;

            _htmlContainer = new HtmlContainer();
            _htmlContainer.MaxSize = MaximumSize;
            _htmlContainer.LinkClicked += OnLinkClicked;
            _htmlContainer.RenderError += OnRenderError;
            _htmlContainer.Refresh += OnRefresh;
            _htmlContainer.StylesheetLoad += OnStylesheetLoad;
            _htmlContainer.ImageLoad += OnImageLoad;

            m_Timer = new GUI.Timer(1);
            m_Timer.Tick += new EventHandler(Timer_Tick);
            m_Timer.Start();
        }


        /// <summary>
        /// Raised when the user clicks on a link in the html.<br/>
        /// Allows canceling the execution of the link.
        /// </summary>
        public event EventHandler<HtmlLinkClickedEventArgs> LinkClicked;

        /// <summary>
        /// Raised when an error occured during html rendering.<br/>
        /// </summary>
        public event EventHandler<HtmlRenderErrorEventArgs> RenderError;

        /// <summary>
        /// Raised when aa stylesheet is about to be loaded by file path or URI by link element.<br/>
        /// This event allows to provide the stylesheet manually or provide new source (file or uri) to load from.<br/>
        /// If no alternative data is provided the original source will be used.<br/>
        /// </summary>
        public event EventHandler<HtmlStylesheetLoadEventArgs> StylesheetLoad;

        /// <summary>
        /// Raised when an image is about to be loaded by file path or URI.<br/>
        /// This event allows to provide the image manually, if not handled the image will be loaded from file or download from URI.
        /// </summary>
        public event EventHandler<HtmlImageLoadEventArgs> ImageLoad;


        /// <summary>
        /// Is content selection is enabled for the rendered html (default - true).<br/>
        /// If set to 'false' the rendered html will be static only with ability to click on links.
        /// </summary>
        [Browsable(true)]
        [DefaultValue(true)]
        [Category("Behavior")]
        [EditorBrowsable(EditorBrowsableState.Always)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        [Description("Is content selection is enabled for the rendered html.")]
        public bool IsSelectionEnabled
        {
            get { return _htmlContainer.IsSelectionEnabled; }
            set { _htmlContainer.IsSelectionEnabled = value; }
        }


        /// <summary>
        /// Is the build-in context menu enabled and will be shown on mouse right click (default - true)
        /// </summary>
        [Browsable(true)]
        [DefaultValue(true)]
        [Category("Behavior")]
        [EditorBrowsable(EditorBrowsableState.Always)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        [Description("Is the build-in context menu enabled and will be shown on mouse right click.")]
        public bool IsContextMenuEnabled
        {
            get { return _htmlContainer.IsContextMenuEnabled; }
            set { _htmlContainer.IsContextMenuEnabled = value; }
        }


        /// <summary>
        /// Set base stylesheet to be used by html rendered in the panel.
        /// </summary>
        [Browsable(true)]
        [Description("Set base stylesheet to be used by html rendered in the control.")]
        [Category("Appearance")]
        public string BaseStylesheet
        {
            get { return _baseRawCssData; }
            set
            {
                _baseRawCssData = value;
                _baseCssData = HtmlRender.ParseStyleSheet(value, true);
            }
        }


        /// <summary>
        /// Automatically sets the size of the label by content size
        /// </summary>
        bool m_AutoSize;
        [Browsable(true)]
        [DefaultValue(true)]
        [EditorBrowsable(EditorBrowsableState.Always)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        [Description("Automatically sets the size of the label by content size.")]
        public bool AutoSize
        {
            get
            {
                return m_AutoSize;
            }
            set
            {
                m_AutoSize = value;

                if (value)
                {
                    _autoSizeHight = false;
                    
                    PerformLayout();

                    //Invalidate();
                    Refresh();
                }
            }
        }


        /// <summary>
        /// Automatically sets the height of the label by content height (width is not effected).
        /// </summary>
        [Browsable(true)]
        [DefaultValue(false)]
        [Category("Layout")]
        [Description("Automatically sets the height of the label by content height (width is not effected)")]
        public bool AutoSizeHeightOnly
        {
            get { return _autoSizeHight; }
            set
            {
                _autoSizeHight = value;
                if (value)
                {
                    AutoSize = false;

                    PerformLayout();
                    
                    //Invalidate();
                    Refresh();
                }
            }
        }


        /// <summary>
        /// Gets or sets the max size the control get be set by <see cref="AutoSize"/> or <see cref="AutoSizeHeightOnly"/>.
        /// </summary>
        /// <returns>An ordered pair of type <see cref="T:SizeI"/> representing the width and height of a rectangle.</returns>
        [Description("If AutoSize or AutoSizeHeightOnly is set this will restrict the max size of the control (0 is not restricted)")]
        public override SizeI MaximumSize
        {
            get { return base.MaximumSize; }
            set
            {
                base.MaximumSize = value;
                if (_htmlContainer != null)
                {
                    _htmlContainer.MaxSize = value;
                    
                    PerformLayout();
                    
                    //Invalidate();
                    Refresh();
                }
            }
        }


        /// <summary>
        /// Gets or sets the min size the control get be set by <see cref="AutoSize"/> or <see cref="AutoSizeHeightOnly"/>.
        /// </summary>
        /// <returns>An ordered pair of type <see cref="T:SizeI"/> representing the width and height of a rectangle.</returns>
        [Description("If AutoSize or AutoSizeHeightOnly is set this will restrict the min size of the control (0 is not restricted)")]
        public override SizeI MinimumSize
        {
            get { return base.MinimumSize; }
            set { base.MinimumSize = value; }
        }


        /// <summary>
        /// Gets or sets the html of this control.
        /// </summary>
        string m_Text;
        [Description("Sets the html of this control.")]
        public override string Text
        {
            get
            {
                return m_Text;
            }
            set
            {
                m_Text = value;

                if (!IsDisposed)
                {
                    _htmlContainer.SetHtml(Text, _baseCssData);
                    
                    PerformLayout();
                    
                    //Invalidate();
                    Refresh();
                }
            }
        }


        /// <summary>
        /// Get html from the current DOM tree with inline style.
        /// </summary>
        /// <returns>generated html</returns>
        public string GetHtml()
        {
            return _htmlContainer != null ? _htmlContainer.GetHtml() : null;
        }


        /// <summary>
        /// Perform the layout of the html in the control.
        /// </summary>
        void PerformLayout()
        {
            if (_htmlContainer != null)
            {
                if (AutoSize)
                    _htmlContainer.MaxSize = Alt.Sketch.Size.Empty;
                else if (AutoSizeHeightOnly)
                    _htmlContainer.MaxSize = new Size(Width, 0);
                else
                    _htmlContainer.MaxSize = Size;

                using (Graphics g = Graphics.CreateDefaultGraphics())
                {
                    _htmlContainer.PerformLayout(g);

                    if (AutoSize || _autoSizeHight)
                    {
                        if (AutoSize)
                        {
                            Size = SizeI.Round(_htmlContainer.ActualSize);
                            if (MaximumSize.Width > 0 && MaximumSize.Width < _htmlContainer.ActualSize.Width)
                            {
                                // to allow the actual size be smaller than max we need to set max size only if it is really larger
                                _htmlContainer.MaxSize = MaximumSize;
                                _htmlContainer.PerformLayout(g);

                                Size = SizeI.Round(_htmlContainer.ActualSize);
                            }
                            else if (MinimumSize.Width > 0 && MinimumSize.Width > _htmlContainer.ActualSize.Width)
                            {
                                // if min size is larger than the actual we need to re-lyout so all 100% layouts will be correct
                                _htmlContainer.MaxSize = new Size(MinimumSize.Width, 0);
                                _htmlContainer.PerformLayout(g);

                                Size = SizeI.Round(_htmlContainer.ActualSize);
                            }
                        }
                        else if (_autoSizeHight)
                        {
                            Height = (int)_htmlContainer.ActualSize.Height;
                        }
                    }
                }
            }

            //  base.OnLayout(levent);
        }


        /// <summary>
        /// Perform paint of the html in the control.
        /// </summary>
        protected override void OnPaint(GUI.PaintEventArgs e)
        {
            base.OnPaint(e);

            if (_htmlContainer != null)
            {
                e.Graphics.TextRenderingHint = TextRenderingHint;// TextRenderingHint.AntiAliasGridFit;// ClearTypeGridFit;
                _htmlContainer.PerformPaint(e.Graphics);
            }
        }


        /// <summary>
        /// Handle mouse move to handle hover cursor and text selection. 
        /// </summary>
        protected override void OnMouseMove(GUI.MouseEventArgs e)
        {
            base.OnMouseMove(e);

            if (_htmlContainer != null)
            {
                _htmlContainer.HandleMouseMove(this, e);
            }
        }


        /// <summary>
        /// Handle mouse down to handle selection. 
        /// </summary>
        protected override void OnMouseDown(GUI.MouseEventArgs e)
        {
            base.OnMouseDown(e);

            if (_htmlContainer != null)
            {
                _htmlContainer.HandleMouseDown(this, e);
            }
        }


        /// <summary>
        /// Handle mouse leave to handle cursor change.
        /// </summary>
        protected override void OnMouseLeave(EventArgs e)
        {
            base.OnMouseLeave(e);

            if (_htmlContainer != null)
            {
                _htmlContainer.HandleMouseLeave(this);
            }
        }


        /// <summary>
        /// Handle mouse up to handle selection and link click. 
        /// </summary>
        protected override void OnMouseUp(GUI.MouseEventArgs e)
        {
            base.OnMouseClick(e);

            if (_htmlContainer != null)
            {
                _htmlContainer.HandleMouseUp(this, e);
            }
        }


        /// <summary>
        /// Handle mouse double click to select word under the mouse. 
        /// </summary>
        protected override void OnMouseDoubleClick(GUI.MouseEventArgs e)
        {
            base.OnMouseDoubleClick(e);

            if (_htmlContainer != null)
            {
                _htmlContainer.HandleMouseDoubleClick(this, e);
            }
        }


        /// <summary>
        /// Propogate the LinkClicked event from root container.
        /// </summary>
        void OnLinkClicked(object sender, HtmlLinkClickedEventArgs e)
        {
            if (LinkClicked != null)
            {
                LinkClicked(this, e);
            }
        }


        HtmlRenderErrorEventArgs m_RenderErrorData;
        /// <summary>
        /// Propagate the Render Error event from root container.
        /// </summary>
        void OnRenderError(object sender, HtmlRenderErrorEventArgs e)
        {
            lock (m_Lock)
            {
                m_RenderErrorData = e;
            }
        }


        /// <summary>
        /// Propagate the stylesheet load event from root container.
        /// </summary>
        void OnStylesheetLoad(object sender, HtmlStylesheetLoadEventArgs e)
        {
            if (StylesheetLoad != null)
            {
                StylesheetLoad(this, e);
            }
        }


        /// <summary>
        /// Propagate the image load event from root container.
        /// </summary>
        void OnImageLoad(object sender, HtmlImageLoadEventArgs e)
        {
            if (ImageLoad != null)
            {
                ImageLoad(this, e);
            }
        }


        object m_Lock = new object();
        bool m_NeedPerformLayout = false;
        bool m_NeedInvalidate = false;
        /// <summary>
        /// Handle html renderer invalidate and re-layout as requested.
        /// </summary>
        void OnRefresh(object sender, HtmlRefreshEventArgs e)
        {
            lock (m_Lock)
            {
                if (e.Layout)
                {
                    //PerformLayout();
                    m_NeedPerformLayout = true;
                }

                //Invalidate();
                m_NeedInvalidate = true;
            }
        }

        
        /// <summary>
        /// Release the html container resources.
        /// </summary>
        public override void Dispose()
        {
            if (m_Timer != null)
            {
                m_Timer.Stop();
                m_Timer.Dispose();
                m_Timer = null;
            }

            if (_htmlContainer != null)
            {
                _htmlContainer.LinkClicked -= OnLinkClicked;
                _htmlContainer.RenderError -= OnRenderError;
                _htmlContainer.Refresh -= OnRefresh;
                _htmlContainer.StylesheetLoad -= OnStylesheetLoad;
                _htmlContainer.ImageLoad -= OnImageLoad;
                _htmlContainer.Dispose();
                _htmlContainer = null;
            }

            base.Dispose();
        }


        GUI.Timer m_Timer;
        void Timer_Tick(object sender, EventArgs e)
        {
            lock (m_Lock)
            {
                if (m_NeedPerformLayout)
                {
                    PerformLayout();
                    m_NeedPerformLayout = false;
                }

                if (m_NeedInvalidate)
                {
                    //Invalidate();
                    Refresh();

                    m_NeedInvalidate = false;
                }


                //
                if (m_RenderErrorData != null &&
                    RenderError != null)
                {
                    RenderError(this, m_RenderErrorData);

                    m_RenderErrorData = null;
                }
            }
        }


        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);

            PerformLayout();

            Refresh();
        }
    }
}
