//  Copyright (C) 2012-2015 AltSoftLab Inc.
//  This source code is provided "as is" without express or implied warranty of any kind.

using System;

using Alt.ComponentModel;
using Alt.Sketch;

using Alt.GUI.HtmlRenderer;
using Alt.GUI.HtmlRenderer.Adapters;
using Alt.GUI.HtmlRenderer.Adapters.Entities;
using Alt.GUI.HtmlRenderer.Core;
using Alt.GUI.HtmlRenderer.Core.Entities;

using Alt.GUI.Temporary.Gwen;
using Alt.GUI.Temporary.Gwen.Control;


namespace Alt.GUI.HtmlRenderer.Temporary.Gwen
{
    /// <summary>
    /// Provides HTML rendering using the text property.<br/>
    /// WindowsForms control that will render html content in it's client rectangle.<br/>
    /// If <see cref="AutoScroll"/> is true and the layout of the html resulted in its content beyond the client bounds 
    /// of the panel it will show scrollbars (horizontal/verticle) allowing to scroll the content.<br/>
    /// If <see cref="AutoScroll"/> is false html content outside the client bounds will be cliped.<br/>
    /// The control will handle mouse and keyboard events on it to support html text selection, copy-paste and mouse clicks.<br/>
    /// <para>
    /// The major differential to use HtmlPanel or HtmlLabel is size and scrollbars.<br/>
    /// If the size of the control depends on the html content the HtmlLabel should be used.<br/>
    /// If the size is set by some kind of layout then HtmlPanel is more suitable, also shows scrollbars if the html contents is larger than the control client rectangle.<br/>
    /// </para>
    /// <para>
    /// <h4>AutoScroll:</h4>
    /// Allows showing scrollbars if html content is placed outside the visible boundaries of the panel.
    /// </para>
    /// <para>
    /// <h4>LinkClicked event:</h4>
    /// Raised when the user clicks on a link in the html.<br/>
    /// Allows canceling the execution of the link.
    /// </para>
    /// <para>
    /// <h4>StylesheetLoad event:</h4>
    /// Raised when aa stylesheet is about to be loaded by file path or URI by link element.<br/>
    /// This event allows to provide the stylesheet manually or provide new source (file or uri) to load from.<br/>
    /// If no alternative data is provided the original source will be used.<br/>
    /// </para>
    /// <para>
    /// <h4>ImageLoad event:</h4>
    /// Raised when an image is about to be loaded by file path or URI.<br/>
    /// This event allows to provide the image manually, if not handled the image will be loaded from file or download from URI.
    /// </para>
    /// <para>
    /// <h4>RenderError event:</h4>
    /// Raised when an error occured during html rendering.<br/>
    /// </para>
    /// </summary>
    public class HtmlPanel : ScrollControl
    {
        class HtmlDrawingPanel : DoubleBufferedControl, IHtmlControl
        {
            public Point MouseLocation
            {
                get
                {
                    return PointToClient(MousePosition);
                }
            }

            public GUI.MouseButtons GetMouseButtons()
            {
                return MouseButtons;
            }

            void IHtmlControl.Invalidate()
            {
                Refresh();
            }


            HtmlContainer _htmlContainer
            {
                get
                {
                    return (Parent as HtmlPanel)._htmlContainer;
                }
            }


            TextRenderingHint m_TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
            public TextRenderingHint TextRenderingHint
            {
                get
                {
                    return m_TextRenderingHint;
                }
                set
                {
                    m_TextRenderingHint = value;

                    Refresh();
                }
            }


            public HtmlDrawingPanel(HtmlPanel parent) :
                base(parent)
            {
                this.SoftwareRender = true;

                SetBounds(0, 0, 100, 100);

                KeyboardInputEnabled = true;
            }


            void HideTooltip()
            {
                ToolTipHandler.Disable(this);
            }
            

            /// <summary>
            /// Perform paint of the html in the control.
            /// </summary>
            protected override void OnPaint(GUI.PaintEventArgs e)
            {
                base.OnPaint(e);

                if (_htmlContainer != null)
                {
                    _htmlContainer.ScrollOffset = DoubleBuffered ? Point.Zero :
                        //  Need correct real offset
                        (Parent as HtmlPanel).ScrollPosition;
                    e.Graphics.TextRenderingHint = TextRenderingHint;// TextRenderingHint.AntiAliasGridFit;// ClearTypeGridFit;
                    _htmlContainer.PerformPaint(e.Graphics);
                }
            }


            /// <summary>
            /// Set focus on the control for keyboard scrrollbars handling.
            /// </summary>
            protected override void OnClick(EventArgs e)
            {
                HideTooltip();

                base.OnClick(e);

                Focus();
            }


            /// <summary>
            /// Handle mouse move to handle hover cursor and text selection. 
            /// </summary>
            protected override void OnMouseMove(GUI.MouseEventArgs e)
            {
                base.OnMouseMove(e);

                if (_htmlContainer != null)
                {
                    _htmlContainer.HandleMouseMove(this, e);
                }
            }


            /// <summary>
            /// Handle mouse leave to handle cursor change.
            /// </summary>
            protected override void OnMouseLeave(EventArgs e)
            {
                base.OnMouseLeave(e);

                if (_htmlContainer != null)
                {
                    _htmlContainer.HandleMouseLeave(this);
                }
            }


            /// <summary>
            /// Handle mouse down to handle selection. 
            /// </summary>
            protected override void OnMouseDown(GUI.MouseEventArgs e)
            {
                HideTooltip();

                base.OnMouseDown(e);

                if (_htmlContainer != null)
                {
                    _htmlContainer.HandleMouseDown(this, e);
                }
            }


            /// <summary>
            /// Handle mouse up to handle selection and link click. 
            /// </summary>
            protected override void OnMouseUp(GUI.MouseEventArgs e)
            {
                base.OnMouseClick(e);

                if (_htmlContainer != null)
                {
                    _htmlContainer.HandleMouseUp(this, e);
                }
            }


            /// <summary>
            /// Handle mouse double click to select word under the mouse. 
            /// </summary>
            protected override void OnMouseDoubleClick(GUI.MouseEventArgs e)
            {
                HideTooltip();

                base.OnMouseDoubleClick(e);

                if (_htmlContainer != null)
                {
                    _htmlContainer.HandleMouseDoubleClick(this, e);
                }
            }


            /// <summary>
            /// Handle key down event for selection, copy and scrollbars handling.
            /// </summary>
            protected override void OnKeyDown(GUI.KeyEventArgs e)
            {
                HideTooltip();

                base.OnKeyDown(e);

                if (_htmlContainer != null)
                {
                    _htmlContainer.HandleKeyDown(this, e);
                }
                /*TEMP
                if (e.KeyCode == Keys.Up)
                {
                    VerticalScroll.Value = Math.Max(VerticalScroll.Value - 70, VerticalScroll.Minimum);
                    PerformLayout();
                }
                else if (e.KeyCode == Keys.Down)
                {
                    VerticalScroll.Value = Math.Min(VerticalScroll.Value + 70, VerticalScroll.Maximum);
                    PerformLayout();
                }
                else if (e.KeyCode == Keys.PageDown)
                {
                    VerticalScroll.Value = Math.Min(VerticalScroll.Value + 400, VerticalScroll.Maximum);
                    PerformLayout();
                }
                else if (e.KeyCode == Keys.PageUp)
                {
                    VerticalScroll.Value = Math.Max(VerticalScroll.Value - 400, VerticalScroll.Minimum);
                    PerformLayout();
                }
                else if (e.KeyCode == Keys.End)
                {
                    VerticalScroll.Value = VerticalScroll.Maximum;
                    PerformLayout();
                }
                else if (e.KeyCode == Keys.Home)
                {
                    VerticalScroll.Value = VerticalScroll.Minimum;
                    PerformLayout();
                }*/
            }
        }



        public override void SetToolTipText(String text)
        {
            m_DrawingPanel.SetToolTipText(text);
        }


        public override Base ToolTip
        {
            get
            {
                return m_DrawingPanel.ToolTip;
            }
            set
            {
                m_DrawingPanel.ToolTip = value;
            }
        }


        internal override string HtmlTooltipText
        {
            get
            {
                return m_DrawingPanel.HtmlTooltipText;
            }
            set
            {
                m_DrawingPanel.HtmlTooltipText = value;
            }
        }


        public Color BackColor
        {
            get
            {
                return m_DrawingPanel.ClientBackColor;
            }
            set
            {
                m_DrawingPanel.ClientBackColor = value;
            }
        }


        public TextRenderingHint TextRenderingHint
        {
            get
            {
                return m_DrawingPanel.TextRenderingHint;
            }
            set
            {
                m_DrawingPanel.TextRenderingHint = value;
            }
        }


        /// <summary>
        /// 
        /// </summary>
        HtmlContainer _htmlContainer;

        /// <summary>
        /// the raw base stylesheet data used in the control
        /// </summary>
        string _baseRawCssData;

        /// <summary>
        /// the base stylesheet data used in the control
        /// </summary>
        CssData _baseCssData;


        HtmlDrawingPanel m_DrawingPanel;


        /// <summary>
        /// Creates a new HtmlPanel and sets a basic css for it's styling.
        /// </summary>
        public HtmlPanel(Base parent)
            : base(parent)
        {
            AutoHideBars = true;

            _htmlContainer = new HtmlContainer();
            _htmlContainer.LinkClicked += OnLinkClicked;
            _htmlContainer.RenderError += OnRenderError;
            _htmlContainer.Refresh += OnRefresh;
            _htmlContainer.StylesheetLoad += OnStylesheetLoad;
            _htmlContainer.ImageLoad += OnImageLoad;

            m_DrawingPanel = new HtmlDrawingPanel(this);

            m_Timer = new GUI.Timer(1);
            m_Timer.Tick += new EventHandler(Timer_Tick);
            m_Timer.Start();
        }


        /// <summary>
        /// Raised when the user clicks on a link in the html.<br/>
        /// Allows canceling the execution of the link.
        /// </summary>
        public event EventHandler<HtmlLinkClickedEventArgs> LinkClicked;

        /// <summary>
        /// Raised when an error occured during html rendering.<br/>
        /// </summary>
        public event EventHandler<HtmlRenderErrorEventArgs> RenderError;

        /// <summary>
        /// Raised when aa stylesheet is about to be loaded by file path or URI by link element.<br/>
        /// This event allows to provide the stylesheet manually or provide new source (file or uri) to load from.<br/>
        /// If no alternative data is provided the original source will be used.<br/>
        /// </summary>
        public event EventHandler<HtmlStylesheetLoadEventArgs> StylesheetLoad;

        /// <summary>
        /// Raised when an image is about to be loaded by file path or URI.<br/>
        /// This event allows to provide the image manually, if not handled the image will be loaded from file or download from URI.
        /// </summary>
        public event EventHandler<HtmlImageLoadEventArgs> ImageLoad;


        /// <summary>
        /// Is content selection is enabled for the rendered html (default - true).<br/>
        /// If set to 'false' the rendered html will be static only with ability to click on links.
        /// </summary>
        [Browsable(true)]
        [DefaultValue(true)]
        [Category("Behavior")]
        [EditorBrowsable(EditorBrowsableState.Always)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        [Description("Is content selection is enabled for the rendered html.")]
        public bool IsSelectionEnabled
        {
            get { return _htmlContainer.IsSelectionEnabled; }
            set { _htmlContainer.IsSelectionEnabled = value; }
        }


        /// <summary>
        /// Is the build-in context menu enabled and will be shown on mouse right click (default - true)
        /// </summary>
        [Browsable(true)]
        [DefaultValue(true)]
        [Category("Behavior")]
        [EditorBrowsable(EditorBrowsableState.Always)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        [Description("Is the build-in context menu enabled and will be shown on mouse right click.")]
        public bool IsContextMenuEnabled
        {
            get { return _htmlContainer.IsContextMenuEnabled; }
            set { _htmlContainer.IsContextMenuEnabled = value; }
        }


        /// <summary>
        /// Set base stylesheet to be used by html rendered in the panel.
        /// </summary>
        [Browsable(true)]
        [Category("Appearance")]
        [Description("Set base stylesheet to be used by html rendered in the control.")]
        public string BaseStylesheet
        {
            get { return _baseRawCssData; }
            set
            {
                _baseRawCssData = value;
                _baseCssData = HtmlRender.ParseStyleSheet(value, true);
            }
        }


        /// <summary>
        /// Gets or sets a value indicating whether the container enables the user to scroll to any controls placed outside of its visible boundaries. 
        /// </summary>
        [Browsable(true)]
        [Description("Sets a value indicating whether the container enables the user to scroll to any controls placed outside of its visible boundaries.")]
        public bool AutoScroll
        {
            get
            {
                return CanScrollH || CanScrollV;
            }
            set
            {
                EnableScroll(value, value);
            }
        }


        /// <summary>
        /// Gets or sets the text of this panel
        /// </summary>
        string m_Text;
        [Browsable(true)]
        [Description("Sets the html of this control.")]
        public string Text
        {
            get
            {
                return m_Text;
            }
            set
            {
                m_Text = value;

                if (!IsDisposed)
                {
                    //VerticalScroll.Value = VerticalScroll.Minimum;
                    ScrollToTop();

                    _htmlContainer.SetHtml(Text, _baseCssData);
                    
                    PerformLayout();

                    //Invalidate();
                    m_DrawingPanel.Refresh();
                }
            }
        }


        /// <summary>
        /// Get html from the current DOM tree with inline style.
        /// </summary>
        /// <returns>generated html</returns>
        public string GetHtml()
        {
            return _htmlContainer != null ? _htmlContainer.GetHtml() : null;
        }


        /// <summary>
        /// Perform the layout of the html in the control.
        /// </summary>
        void PerformLayout()
        {
            PerformHtmlLayout();

            //TEMP  base.OnLayout(levent);

            // to handle if vertical scrollbar is appearing or disappearing
            if (_htmlContainer != null &&
                Math.Abs(_htmlContainer.MaxSize.Width - ClientSize.Width) > 0.1)
            {
                PerformHtmlLayout();

                //TEMP  base.OnLayout(levent);
            }
        }


        /// <summary>
        /// Perform html container layout by the current panel client size.
        /// </summary>
        void PerformHtmlLayout()
        {
            if (_htmlContainer != null)
            {
                using (Graphics g = //CreateGraphics()
                    Graphics.CreateDefaultGraphics())
                {
                    _htmlContainer.MaxSize = new Size(Width, 0);
                    _htmlContainer.PerformLayout(g);

                    //  resize
                    if (_htmlContainer.ActualSize.Height > Height)
                    {
                        _htmlContainer.MaxSize = new Size(Width - VerticalScrollBarWidth, 0);
                        _htmlContainer.PerformLayout(g);
                    }
                }

                //AutoScrollMinSize = SizeI.Round(_htmlContainer.ActualSize);
                m_DrawingPanel.Size = _htmlContainer.ActualSize.ToSizeI();
            }
        }


        /// <summary>
        /// Propagate the LinkClicked event from root container.
        /// </summary>
        void OnLinkClicked(object sender, HtmlLinkClickedEventArgs e)
        {
            if (LinkClicked != null)
            {
                LinkClicked(this, e);
            }
        }


        HtmlRenderErrorEventArgs m_RenderErrorData;
        /// <summary>
        /// Propagate the Render Error event from root container.
        /// </summary>
        void OnRenderError(object sender, HtmlRenderErrorEventArgs e)
        {
            lock (m_Lock)
            {
                m_RenderErrorData = e;
            }
        }


        /// <summary>
        /// Propagate the stylesheet load event from root container.
        /// </summary>
        private void OnStylesheetLoad(object sender, HtmlStylesheetLoadEventArgs e)
        {
            if (StylesheetLoad != null)
            {
                StylesheetLoad(this, e);
            }
        }


        /// <summary>
        /// Propagate the image load event from root container.
        /// </summary>
        void OnImageLoad(object sender, HtmlImageLoadEventArgs e)
        {
            if (ImageLoad != null)
            {
                ImageLoad(this, e);
            }
        }


        object m_Lock = new object();
        bool m_NeedPerformLayout = false;
        bool m_NeedInvalidate = false;
        /// <summary>
        /// Handle html renderer invalidate and re-layout as requested.
        /// </summary>
        void OnRefresh(object sender, HtmlRefreshEventArgs e)
        {
            lock (m_Lock)
            {
                if (e.Layout)
                {
                    //PerformLayout();
                    m_NeedPerformLayout = true;
                }

                //Invalidate();
                m_NeedInvalidate = true;
            }
        }


        /// <summary>
        /// Used to add arrow keys to the handled keys in <see cref="OnKeyDown"/>.
        /// </summary>
        protected override bool IsInputKey(GUI.Keys keyData)
        {
            switch (keyData)
            {
                case GUI.Keys.Right:
                case GUI.Keys.Left:
                case GUI.Keys.Up:
                case GUI.Keys.Down:
                    return true;
                case GUI.Keys.Shift | GUI.Keys.Right:
                case GUI.Keys.Shift | GUI.Keys.Left:
                case GUI.Keys.Shift | GUI.Keys.Up:
                case GUI.Keys.Shift | GUI.Keys.Down:
                    return true;
            }

            return base.IsInputKey(keyData);
        }


        /// <summary>
        /// Release the html container resources.
        /// </summary>
        public override void Dispose()
        {
            if (m_Timer != null)
            {
                m_Timer.Stop();
                m_Timer.Dispose();
                m_Timer = null;
            }

            if (_htmlContainer != null)
            {
                _htmlContainer.LinkClicked -= OnLinkClicked;
                _htmlContainer.RenderError -= OnRenderError;
                _htmlContainer.Refresh -= OnRefresh;
                _htmlContainer.StylesheetLoad -= OnStylesheetLoad;
                _htmlContainer.ImageLoad -= OnImageLoad;
                _htmlContainer.Dispose();
                _htmlContainer = null;
            }

            base.Dispose();
        }


        GUI.Timer m_Timer;
        void Timer_Tick(object sender, EventArgs e)
        {
            lock (m_Lock)
            {
                if (m_NeedPerformLayout)
                {
                    PerformLayout();
                    m_NeedPerformLayout = false;
                }

                if (m_NeedInvalidate)
                {
                    m_DrawingPanel.//Invalidate();
                        Refresh();
                    m_NeedInvalidate = false;
                }


                //
                if (m_RenderErrorData != null &&
                    RenderError != null)
                {
                    RenderError(this, m_RenderErrorData);

                    m_RenderErrorData = null;
                }
            }
        }


        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);

            PerformLayout();

            Refresh();
        }
    }
}
