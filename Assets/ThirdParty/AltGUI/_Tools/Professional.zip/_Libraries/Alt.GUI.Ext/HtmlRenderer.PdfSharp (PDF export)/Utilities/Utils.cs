//  Original source code has been modified by AltSoftLab Inc. 2012-2015
//  This source code is provided "as is" without express or implied warranty of any kind.

using Alt.Sketch;

using Alt.GUI.HtmlRenderer.Adapters.Entities;

using Alt.GUI.PdfSharp.Drawing;


namespace Alt.GUI.HtmlRenderer.PdfSharp.Utilities
{
    /// <summary>
    /// Utilities for converting WindowsForms entities to HtmlRenderer core entities.
    /// </summary>
    internal static class Utils
    {
        /// <summary>
        /// Convert from WindowsForms point to core point.
        /// </summary>
        public static RPoint Convert(XPoint p)
        {
            return new RPoint(p.X, p.Y);
        }

        /// <summary>
        /// Convert from WindowsForms point to core point.
        /// </summary>
        public static XPoint[] Convert(RPoint[] points)
        {
            XPoint[] myPoints = new XPoint[points.Length];
            for (int i = 0; i < points.Length; i++)
                myPoints[i] = Convert(points[i]);
            return myPoints;
        }

        /// <summary>
        /// Convert from core point to WindowsForms point.
        /// </summary>
        public static XPoint Convert(RPoint p)
        {
            return new XPoint(p.X, p.Y);
        }

        /// <summary>
        /// Convert from WindowsForms size to core size.
        /// </summary>
        public static RSize Convert(XSize s)
        {
            return new RSize(s.Width, s.Height);
        }

        /// <summary>
        /// Convert from core size to WindowsForms size.
        /// </summary>
        public static XSize Convert(RSize s)
        {
            return new XSize(s.Width, s.Height);
        }

        /// <summary>
        /// Convert from WindowsForms rectangle to core rectangle.
        /// </summary>
        public static RRect Convert(XRect r)
        {
            return new RRect(r.X, r.Y, r.Width, r.Height);
        }

        /// <summary>
        /// Convert from core rectangle to WindowsForms rectangle.
        /// </summary>
        public static XRect Convert(RRect r)
        {
            return new XRect(r.X, r.Y, r.Width, r.Height);
        }

        /// <summary>
        /// Convert from WindowsForms color to core color.
        /// </summary>
        public static RColor Convert(XColor c)
        {
            var gc = c.ToGdiColor();
            return RColor.FromArgb(gc.A, gc.R, gc.G, gc.B);
        }

        /// <summary>
        /// Convert from core color to WindowsForms color.
        /// </summary>
        public static XColor Convert(RColor c)
        {
            return XColor.FromArgb(Color.FromArgb(c.A, c.R, c.G, c.B));
        }
    }
}