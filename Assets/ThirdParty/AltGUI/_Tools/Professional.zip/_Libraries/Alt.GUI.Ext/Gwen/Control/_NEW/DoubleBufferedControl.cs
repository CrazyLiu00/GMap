﻿//  Copyright (C) 2012-2015 AltSoftLab Inc.
//  This source code is provided "as is" without express or implied warranty of any kind.

using System;

using Alt.GUI.Temporary.Gwen.Input;
using Alt.GUI;
using Alt.Sketch;


namespace Alt.GUI.Temporary.Gwen.Control
{
    /// <summary>
    /// DoubleBufferedControl control.
    /// </summary>
    public class DoubleBufferedControl : Label
    {
        RenderImage m_BackBuffer;
        RenderImage BackBuffer
        {
            get
            {
                if (ClientRectangle.Size.IsEmpty)
                {
                    return null;
                }

                if (m_BackBuffer == null ||
                    m_BackBuffer.PixelSize != ClientRectangle.Size)
                {
                    if (m_BackBuffer != null)
                    {
                        m_BackBuffer.Paint -= new PaintEventHandler(BackBuffer_Paint);
                        m_BackBuffer.Dispose();
                        m_BackBuffer = null;
                    }

                    m_BackBuffer = new RenderImage(ClientRectangle.Size,
                        UseTransparentBackground ? PixelFormat.Format32bppArgb : PixelFormat.Format24bppRgb);
                    m_BackBuffer.Paint += new PaintEventHandler(BackBuffer_Paint);
                    m_BackBuffer.SoftwareRender = m_SoftwareRender;

                    m_NeedRefresh = true;
                }

                return m_BackBuffer;
            }
        }


        bool m_NeedRefresh = true;
        public bool NeedRefresh
        {
            get
            {
                return
                    (m_NeedRefresh ||
                    m_BackBuffer == null ||
                    m_BackBuffer.PixelSize != ClientRectangle.Size) && !ClientRectangle.Size.IsEmpty;
            }
            set
            {
                m_NeedRefresh = value;
            }
        }


        bool m_DoubleBuffered = true;
        public bool DoubleBuffered
        {
            get
            {
                return m_DoubleBuffered;
            }
            set
            {
                m_DoubleBuffered = value;
            }
        }


        bool m_UseTransparentBackground = true;
        public bool UseTransparentBackground
        {
            get
            {
                return m_UseTransparentBackground;
            }
            set
            {
                m_UseTransparentBackground = value;
            }
        }


        bool m_SoftwareRender = false;
        public bool SoftwareRender
        {
            get
            {
                return m_SoftwareRender;
            }
            set
            {
                if (m_SoftwareRender == value)
                {
                    return;
                }

                m_SoftwareRender = value;

                if (m_BackBuffer != null)
                {
                    m_BackBuffer.SoftwareRender = m_SoftwareRender;
                }
            }
        }


        /// <summary>
        /// DoubleBufferedControl constructor.
        /// </summary>
        /// <param name="parent">Parent control.</param>
        public DoubleBufferedControl(Base parent)
            : base(parent)
        {
            SetSize(100, 100);
            MouseInputEnabled = true;
            Alignment = Pos.Center;
            TextPadding = new Padding(3, 3, 3, 3);

            //ClientBackColor = Color.Empty;
        }

        public override void Dispose()
        {
            if (m_BackBuffer != null)
            {
                m_BackBuffer.Paint -= new PaintEventHandler(BackBuffer_Paint);
                m_BackBuffer.Dispose();
                m_BackBuffer = null;
            }

            base.Dispose();
        }


        protected override void Render(Skin.Base skin)
        {
            if (!DoubleBuffered)
            {
                base.Render(skin);
                return;
            }


            if (skin == null ||
                skin.Renderer == null)
            {
                return;
            }

            Graphics graphics_main = skin.Renderer.Graphics;
            if (graphics_main == null)
            {
                return;
            }


            GraphicsState state = graphics_main.Save();

            //  Clipping
            PointI oldRenderOffset = skin.Renderer.RenderOffset;
            RectI oldRegion = skin.Renderer.ClipRegion;
            {
                skin.Renderer.AddRenderOffset(InnerBounds.Location);
                graphics_main.RenderOffset += skin.Renderer.RenderOffset;
                graphics_main.RenderSize = ClientRectangle.Size;

                skin.Renderer.AddClipRegion(InnerBounds);

                skin.Renderer.StartClip();
            }


            RenderImage backbuffer = BackBuffer;
            if (backbuffer != null)
            {
                if (NeedRefresh)
                {
                    /*  Moved to BackBuffer_Paint
                    Graphics graphics = Graphics.FromImage(backbuffer);
                    graphics.Clear(ClientBackColor);

                    PaintEventArgs paint_event = new PaintEventArgs(graphics, new RectI(PointI.Zero, backbuffer.PixelSize));
                    DoPaint(paint_event);*/
                    backbuffer.NeedUpdate();

                    m_NeedRefresh = false;
                }

                //graphics_main.DrawImage(backbuffer, PointI.Zero);
                DrawRenderImage(new PaintEventArgs(graphics_main, new RectI(PointI.Zero, ClientRectangle.Size)), backbuffer);
            }

            
            OnPostPaint(new PaintEventArgs(graphics_main, new RectI(PointI.Zero, ClientRectangle.Size)));


            graphics_main.Restore(state);


            //  Clipping
            {
                skin.Renderer.ClipRegion = oldRegion;
                skin.Renderer.StartClip();
                skin.Renderer.RenderOffset = oldRenderOffset;
            }
        }
        
        protected virtual void DrawRenderImage(PaintEventArgs e, ImageSource image)
        {
            e.Graphics.DrawImage(image, PointI.Zero);
        }


        void BackBuffer_Paint(object sender, PaintEventArgs paint_event)
        {
            paint_event.Graphics.Clear(ClientBackColor);

            DoPaint(paint_event);
        }


        public override void Refresh()
        {
            base.Refresh();

            m_NeedRefresh = true;
        }


        public override void Invalidate()
        {
            base.Invalidate();

            //m_NeedRefresh = true;
        }
    }
}
