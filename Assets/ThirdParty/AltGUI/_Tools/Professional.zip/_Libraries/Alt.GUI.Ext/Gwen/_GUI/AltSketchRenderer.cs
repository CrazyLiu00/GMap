﻿//  Copyright (C) 2012-2015 AltSoftLab Inc.
//  This source code is provided "as is" without express or implied warranty of any kind.

using System;
using System.Collections.Generic;
using System.Diagnostics;

using Alt.Sketch;


namespace Alt.GUI.Temporary.Gwen.Renderer
{
    sealed class AltSketchRenderer : Base, ICacheToTexture
    {
        Color m_Color;

        readonly Dictionary<Tuple<String, Tuple<Font, Color>>, TextRenderer> m_DrawStringCache;
        readonly Dictionary<Tuple<String, Font>, SizeI> m_MesureStringCache;
        readonly Graphics m_MeasureTextGraphics; // only used for text measurement
        //bool m_ClipEnabled;
        bool m_TextureEnabled;
        static Bitmap m_LastTextureBitmap;

        StringFormat m_StringFormat;


        bool ShouldCacheToTexture = true;


        public AltSketchRenderer()
            : this(false)
        {
        }

        public AltSketchRenderer(bool shouldCacheToTexture)
            : base(shouldCacheToTexture)
        {
            ShouldCacheToTexture = shouldCacheToTexture;

            m_DrawStringCache = new Dictionary<Tuple<String, Tuple<Font, Color>>, TextRenderer>();
            m_MesureStringCache = new Dictionary<Tuple<String, Font>, SizeI>();
            m_MeasureTextGraphics = Graphics.FromImage(new Bitmap(1, 1));//1024, 1024, PixelFormat.Format32bppArgb));
            m_StringFormat = new StringFormat(StringFormat.GenericTypographic);
            m_StringFormat.FormatFlags |= StringFormatFlags.MeasureTrailingSpaces;

            m_CacheUpdateIntervalTimer = new IntervalTimer(500);

            m_CacheUpdateTimer = new GUI.Timer();
            m_CacheUpdateTimer.Interval = m_CacheUpdateIntervalTimer.Interval;
            m_CacheUpdateTimer.Tick += CacheUpdateTimer_Tick;
            m_CacheUpdateTimer.Start();
        }


        public override void Dispose()
        {
            FlushTextCache();

            if (m_CacheUpdateTimer != null)
            {
                m_CacheUpdateTimer.Stop();
                m_CacheUpdateTimer.Dispose();
                m_CacheUpdateTimer = null;
            }

            base.Dispose();
        }


        public override void Begin()
        {
            //m_ClipEnabled = false;
            m_TextureEnabled = false;
            m_LastTextureBitmap = null;
        }


        public override void End()
        {
        }


        /// <summary>
        /// Clears the text rendering cache. Make sure to call this if cached strings size becomes too big (check TextCacheSize).
        /// </summary>
        void FlushTextCache()
        {
            // todo: some auto-expiring cache? based on number of elements or age
			foreach (TextRenderer textRenderer in m_DrawStringCache.Values)
            {
                textRenderer.Dispose();
            }

            m_DrawStringCache.Clear();
        }


        public override void DrawFilledRect(RectI rect)
        {
            m_TextureEnabled = false;

            rect = Translate(rect);

            DrawRect(rect);
        }


        public override Color DrawColor
        {
            get { return m_Color; }
            set
            {
                m_Color = value;
            }
        }


        GraphicsState m_BeforeClipGraphicsStateSave;
        public override void StartClip()
        {
            //m_ClipEnabled = true;

            m_BeforeClipGraphicsStateSave = Graphics.Save();

            //TEMP  Graphics.IntersectClip(ClipRegion);
            Graphics.Clip = new Region(ClipRegion.ToRect() - Graphics.RenderOffset +
                (IsRTGStackEmpty ? GraphicsInitialRenderOffset : Point.Zero));
        }


        public override void EndClip()
        {
            //m_ClipEnabled = false;

            Graphics.Restore(m_BeforeClipGraphicsStateSave);
            m_BeforeClipGraphicsStateSave = null;
        }


        public override void DrawTexturedRect(Texture t, RectI rect, float u1// = 0
            , float v1// = 0
            , float u2// = 1
            , float v2)// = 1)
        {
            // Missing image, not loaded properly?
            if (t.RendererData == null)
            {
                DrawMissingImage(rect);
                return;
            }

            DrawTexturedRect((Bitmap)t.RendererData, rect, u1, v1, u2, v2);
        }


        void DrawTexturedRect(Bitmap bmp, RectI rect)
        {
            DrawTexturedRect(bmp, rect, 0, 0, 1, 1);
        }


        void DrawTexturedRect(Bitmap bmp, RectI rect, float u1// = 0
            , float v1// = 0
            , float u2// = 1
            , float v2)// = 1)
        {
            rect = Translate(rect);

            m_LastTextureBitmap = bmp;

            m_TextureEnabled = true;

            DrawRect(rect, u1, v1, u2, v2);
        }


        void DrawRect(RectI rect)//, float u1 = 0, float v1 = 0, float u2 = 1, float v2 = 1)
        {
            DrawRect(rect, 0, 0, 1, 1);
        }


        void DrawRect(RectI rect, float u1// = 0
            , float v1// = 0
            , float u2// = 1
            , float v2)// = 1)
        {
            if (Graphics != null)
            {
                //NoNeed    SmoothingMode oldSmoothingMode = Graphics.SmoothingMode;
                //NoNeed    Graphics.SmoothingMode = SmoothingMode.None;

                if (!m_TextureEnabled ||
                    m_LastTextureBitmap == null)
                {
                    if (DrawColor.A != 0)//NoNeed to Draw
                    {
                        /*Not good for batching
                        if (!(Graphics is SoftwareGraphics) &&//because Fill is faster then stroke in SoftwareGraphics
                            (rect.Height == 1 || rect.Width == 1) &&
                            rect.Height != rect.Width)
                        {
                            if (rect.Height == 1)
                            {
                                Graphics.DrawLine(DrawColor, rect.X, rect.Y, rect.Right - 1, rect.Y);
                            }
                            else
                            {
                                Graphics.DrawLine(DrawColor, rect.X, rect.Y, rect.X, rect.Bottom - 1);
                            }
                        }
                        else*/
                        {
                            Graphics.FillRectangle(DrawColor, rect);
                        }
                    }
                }
                else
                {
                    SizeI imageSize = m_LastTextureBitmap.PixelSize;
                    Rect srcRect = Rect.FromLTRB(
                        u1 * imageSize.Width, v1 * imageSize.Height,
                        u2 * imageSize.Width, v2 * imageSize.Height);
                    //*NoNeed
                    if (imageSize == srcRect.Size)
                    {
                        if (srcRect.Size == rect.Size)
                        {
                            Graphics.DrawImage(m_LastTextureBitmap, rect.Location);
                        }
                        else
                        {
                            Graphics.DrawImage(m_LastTextureBitmap, rect);
                        }
                    }
                    else
                    {
                        //m_CurrentGraphics.FillRectangle(Brushes.Red, rect);
                        if (srcRect.Size == rect.Size)
                        {
                            Graphics.DrawImage(m_LastTextureBitmap, rect.Location, srcRect);
                        }
                        else    //NoNeed*/
                        {
                            Graphics.DrawImage(m_LastTextureBitmap, rect, srcRect);
                        }
                    }
                }

                //NoNeed    Graphics.SmoothingMode = oldSmoothingMode;
            }
        }


        public override SizeI MeasureText(Font font, string text)
        {
            //Debug.Print(String.Format("MeasureText '{0}'", text));
            Alt.Sketch.Font sysFont = font;//.RenderFont;

            if (sysFont == null ||
                //Math.Abs(font.RealSize - font.Size * Scale) > 2)
                Math.Abs(font.Size - font.Size * Scale) > 2)
            {
                //Font.FreeFont(font);
                //Font.LoadFont(font, Scale);
                //sysFont = font.RenderFont;
                sysFont = new Font(font.FontFamily, font.Size * Scale);
            }

			Tuple<String, Font> key = new Tuple<String, Font>(text, font);

            if (m_MesureStringCache.ContainsKey(key))
            {
                //var tex = m_StringCache[key].Texture;
                //return new SizeI(tex.Width, tex.Height);
                return m_MesureStringCache[key];
            }


            if (m_MesureStringCache.Count > 200)//0) // each cached string is an allocated texture, flush the cache once in a while in your real project
            {
                m_MesureStringCache.Clear();
            }


            Size size = m_MeasureTextGraphics.MeasureString(text, sysFont, PointI.Empty, m_StringFormat);
            size.Height += 1;

            //return new PointI((int)Math.Round(size.Width), (int)Math.Round(size.Height));
            //return new PointI((int)size.Width, (int)size.Height);
            SizeI result = new SizeI((int)System.Math.Ceiling(size.Width), (int)System.Math.Ceiling(size.Height));
            m_MesureStringCache.Add(key, result);

            return result;
        }


        public override void RenderText(Font font, PointI position, string text)
        {
            //Debug.Print(String.Format("RenderText {0}", font.FaceName));

            // The DrawString(...) below will bind a new texture
            // so make sure everything is rendered!
            //MY    Flush();

            Alt.Sketch.Font sysFont = font;//.RenderFont;

            if (sysFont == null ||
                //Math.Abs(font.RealSize - font.Size * Scale) > 2)
                Math.Abs(font.Size - font.Size * Scale) > 2)
            {
                //Font.FreeFont(font);
                //Font.LoadFont(font, Scale);
                //sysFont = font.RenderFont;
                sysFont = new Font(font.FontFamily, font.Size * Scale);
            }

            /*if (m_CurrentGraphics != null)
            {
                m_CurrentGraphics.DrawString(text, sysFont, Brushes.Gray, Translate(position), m_StringFormat);
            }
            return;*/

			Tuple<String, Tuple<Font, Color>> key = new Tuple<String, Tuple<Font, Color>>(text, new Tuple<Font, Color>(font, DrawColor));

            if (!m_DrawStringCache.ContainsKey(key))
            {
                // not cached - create text renderer
                //NoNeed  Debug.Print(String.Format("RenderText: caching \"{0}\", {1}", text, font.Name));//FaceName));

                SizeI size = MeasureText(font, text);
                TextRenderer tr = new TextRenderer(size.Width, size.Height, this);
                tr.DrawString(text, sysFont, new SolidColorBrush(DrawColor),
                    //  PointI.Empty,
                    new PointI(0, 1),
                    m_StringFormat); // renders string on the texture

                DrawTexturedRect(tr.Texture, new RectI(position.X, position.Y, tr.Texture.Width, tr.Texture.Height));

                m_DrawStringCache.Add(key, tr);
            }
            else
            {
                TextRenderer tr = m_DrawStringCache[key];
                tr.Touch();

                DrawTexturedRect(tr.Texture, new RectI(position.X, position.Y, tr.Texture.Width, tr.Texture.Height));
            }


            UpdateTextCacheIfNeed();
        }


        internal static void LoadTextureInternal(Texture t, Bitmap bmp)
        {
            switch (bmp.PixelFormat)
            {
                case PixelFormat.Format32bppArgb:
                case PixelFormat.Format24bppRgb:
                    break;
                default:
                    t.Failed = true;
                    return;
            }


            // Sort out our GWEN texture
            t.RendererData = bmp;
            t.Width = bmp.PixelWidth;
            t.Height = bmp.PixelHeight;

            m_LastTextureBitmap = bmp;
        }


        public override void LoadTexture(Texture t)
        {
            Bitmap bmp;
            try
            {
                bmp = new Bitmap(t.Name);
            }
            catch (Exception)
            {
                t.Failed = true;
                return;
            }

            LoadTextureInternal(t, bmp);

            //  NotGood (audoDisposing when need more better)
            //bmp.Dispose();
        }


        public override void LoadTextureStream(Texture t, System.IO.Stream data)
        {
            Bitmap bmp;
            try
            {
                bmp = new Bitmap(data);
            }
            catch (Exception)
            {
                t.Failed = true;
                return;
            }

            LoadTextureInternal(t, bmp);

            //  NotGood (audoDisposing when need more better)
            //bmp.Dispose();
        }


        public override void LoadTextureRaw(Texture t, byte[] pixelData)
        {
            Bitmap bmp;
            try
            {
                //unsafe
                {
                    //fixed (byte* ptr = &pixelData[0])
                    bmp = new Bitmap(t.Width, t.Height, 4 * t.Width, PixelFormat.Format32bppArgb, pixelData);//(IntPtr)ptr);
                }
            }
            catch (Exception)
            {
                t.Failed = true;
                return;
            }

            // Sort out our GWEN texture
            t.RendererData = bmp;
            m_LastTextureBitmap = bmp;
        }


        public override void FreeTexture(Texture t)
        {
            if (t.RendererData == null)
            {
                return;
            }

            //MY    int tex = (int)t.RendererData;
            Bitmap bmp = (Bitmap)t.RendererData;
            if (bmp == null)
            {
                return;
            }

            t.RendererData = null;

            //  NotGood (audoDisposing when need more better)
            //bmp.Dispose();
        }


        public override Color PixelColor(Texture texture, int x, int y, Color defaultColor)
        {
            if (texture == null ||
                texture.RendererData == null)
            {
                return defaultColor;
            }

            Bitmap bmp = (Bitmap)texture.RendererData;
            if (bmp == null)
            {
                return defaultColor;
            }

            return bmp.GetPixel((int)x, (int)y);
        }
        

        /// <summary>
        /// Cache to texture provider.
        /// </summary>
        public override ICacheToTexture CTT
        {
            get
            {
                if (ShouldCacheToTexture)
                {
                    return this;
                }

                return null;
            }
        }



        //  Implementation of ICacheToTexture

        Dictionary<Control.Base, Tuple<Bitmap, Graphics>> m_RT;
        Stack<Graphics> m_RTGStack;
        Graphics m_RealRT;


        bool IsRTGStackEmpty
        {
            get
            {
                if (m_RTGStack == null)
                {
                    return true;
                }

                return m_RTGStack.Count == 0;
            }
        }


        public void Initialize()
        {
            m_RT = new Dictionary<Control.Base, Tuple<Bitmap, Graphics>>();
            m_RTGStack = new Stack<Graphics>();
        }


        public void ShutDown()
        {
            m_RT.Clear();
            if (m_RTGStack.Count > 0)
                throw new InvalidOperationException("Render stack not empty");
        }


        /// <summary>
        /// Called to set the target up for rendering.
        /// </summary>
        /// <param name="control">Control to be rendered.</param>
        public void SetupCacheTexture(Control.Base control)
        {
            UpdateCacheTexture(control);

            m_RealRT = Graphics;
            m_RTGStack.Push(Graphics); // save current RT
            Graphics = m_RT[control].Item2; // make cache current RT
        }


        /// <summary>
        /// Called when cached rendering is done.
        /// </summary>
        /// <param name="control">Control to be rendered.</param>
        public void FinishCacheTexture(Control.Base control)
        {
            Graphics = m_RTGStack.Pop();
        }


        /// <summary>
        /// Called when gwen wants to draw the cached version of the control. 
        /// </summary>
        /// <param name="control">Control to be rendered.</param>
        public void DrawCachedControlTexture(Control.Base control)
        {
            Bitmap ri = m_RT[control].Item1;

            Graphics rt = Graphics;
            Graphics = m_RealRT;
            DrawTexturedRect(ri, control.Bounds);
            Graphics = rt;
        }


        /// <summary>
        /// Called to actually create a cached texture. 
        /// </summary>
        /// <param name="control">Control to be rendered.</param>
        public void CreateControlCacheTexture(Control.Base control)
        {
            // initialize cache RT
            if (!m_RT.ContainsKey(control))
            {
                Bitmap bmp = new Bitmap(control.Width, control.Height, PixelFormat.Format32bppArgb);
                m_RT[control] = new Tuple<Bitmap, Graphics>(bmp, Graphics.FromImage(bmp));
            }
        }


        void UpdateCacheTexture(Control.Base control)
        {
            if (m_RT.ContainsKey(control))
            {
                Bitmap bmp = m_RT[control].Item1;
                if (bmp.PixelWidth != control.Width ||
                    bmp.PixelHeight != control.Height)
                {
                    bmp = new Bitmap(control.Width, control.Height, PixelFormat.Format32bppArgb);
                    m_RT[control] = new Tuple<Bitmap, Graphics>(bmp, Graphics.FromImage(bmp));
                }
            }
        }



        GUI.Timer m_CacheUpdateTimer;
        IntervalTimer m_CacheUpdateIntervalTimer;
        void UpdateTextCacheIfNeed()
        {
            if (m_CacheUpdateIntervalTimer.IsTimeOver)
            {
                Int64 currentTime = Alt.IntervalTimer.Ticks;

                List<Tuple<String, Tuple<Font, Color>>> temp = new List<Tuple<String, Tuple<Font, Color>>>();

				foreach (KeyValuePair<Tuple<String, Tuple<Font, Color>>, TextRenderer> kvp in m_DrawStringCache)
                {
                    if (kvp.Value.IsLiveTimeOver(currentTime))
                    {
                        kvp.Value.Dispose();

                        temp.Add(kvp.Key);
                    }
                }

				foreach (Tuple<String, Tuple<Font, Color>> item in temp)
                {
                    m_MesureStringCache.Remove(new Tuple<string, Font>(item.Item1, item.Item2.Item1));

                    m_DrawStringCache.Remove(item);
                }
                temp.Clear();
            }
        }

        void CacheUpdateTimer_Tick(object sender, EventArgs e)
        {
            UpdateTextCacheIfNeed();
        }



        /// <summary>
        /// Uses System.Drawing for 2d text rendering.
        /// </summary>
        sealed class TextRenderer : DisposableObject
        {
            Int64 m_TouchTime;
            internal void Touch()
            {
                m_TouchTime = Alt.IntervalTimer.Ticks;
            }

            internal bool IsLiveTimeOver(Int64 currentTime)
            {
                return Alt.IntervalTimer.ConvertTicksToMSec(currentTime - m_TouchTime) > 500;
            }


            //readonly
            Bitmap bmp;
            //readonly Graphics gfx;
            //readonly
            Gwen.Texture texture;
            bool disposed;
            Renderer.AltSketchRenderer m_Renderer;


            public Texture Texture { get { return texture; } }


            /// <summary>
            /// Constructs a new instance.
            /// </summary>
            /// <param name="width">The width of the backing store in pixels.</param>
            /// <param name="height">The height of the backing store in pixels.</param>
            /// <param name="renderer">GWEN renderer.</param>
            public TextRenderer(int width, int height, Renderer.AltSketchRenderer renderer)
            {
                Touch();

                if (width <= 0)
                    throw new ArgumentOutOfRangeException("width");
                if (height <= 0)
                    throw new ArgumentOutOfRangeException("height");

                m_Renderer = renderer;

                /*  LATER
                bmp = new Bitmap(width, height, PixelFormat.Format32bppArgb);
                gfx = Graphics.FromImage(bmp);

                // NOTE:    TextRenderingHint.AntiAliasGridFit looks sharper and in most cases better
                //          but it comes with a some problems.
                //
                //          1.  Graphic.MeasureString and format.MeasureCharacterRanges 
                //              seem to return wrong values because of this.
                //
                //          2.  While typing the kerning changes in random places in the sentence.
                // 
                //          Until 1st problem is fixed we should use TextRenderingHint.AntiAlias...  :-(

                gfx.TextRenderingHint = TextRenderingHint.AntiAlias;
                gfx.Clear(Color.Transparent);
                texture = new Texture(renderer) {Width = width, Height = height};*/
            }


            /// <summary>
            /// Draws the specified string to the backing store.
            /// </summary>
            /// <param name="text">The <see cref="System.String"/> to draw.</param>
            /// <param name="font">The <see cref="Font"/> that will be used.</param>
            /// <param name="brush">The <see cref="Brush"/> that will be used.</param>
            /// <param name="point">The location of the text on the backing store, in 2d pixel coordinates.
            /// The origin (0, 0) lies at the top-left corner of the backing store.</param>
            public void DrawString(string text, Alt.Sketch.Font font, Brush brush, PointI point, StringFormat format)
            {
                SolidColorBrush scb = brush as SolidColorBrush;
                if (scb != null)
                {
                    if (scb.Color == Color.Empty ||
                        scb.Color == Color.Transparent)
                    {
                        brush = Brushes.Gray;
                    }
                }

                //gfx.DrawString(text, font, brush, point, format); // render text on the bitmap
                
                //bmp = Graphics.CreateDefaultGraphics().CreateStringImage(text, font, brush, point, format); // render text on the bitmap
                Size size = Graphics.CreateDefaultGraphics().MeasureString(text, font, PointI.Empty, format);
                bmp = new Bitmap((int)System.Math.Ceiling(size.Width) + point.X, (int)System.Math.Ceiling(size.Height) + point.Y);
                using (Graphics graphics = Graphics.FromImage(bmp))
                {
                    //  Need for premultiply
                    if (scb != null)
                    {
                        graphics.Clear(Color.FromArgb(0, scb.Color));
                    }

                    graphics.DrawString(text, font, brush, point, format); // render text on the bitmap
                }

                //texture = new Texture(m_Renderer) { Width = bmp.PixelWidth, Height = bmp.PixelHeight };
				texture = new Texture(m_Renderer);
				texture.Width = bmp.PixelWidth;
				texture.Height = bmp.PixelHeight;

				AltSketchRenderer.LoadTextureInternal(texture, bmp); // copy bitmap to gl texture
            }


            protected override void Dispose(bool disposing)
            {
                if (!disposed)
                {
                    if (disposing)
                    {
                        /*NotGood (audoDisposing when need more better)
                        if (!bmp.IsDisposed)
                        {
                            bmp.Dispose();
                        }*/

                        //gfx.Dispose();
                        texture.Dispose();
                    }

                    disposed = true;
                }

                base.Dispose(disposing);
            }
        }
    }
}
