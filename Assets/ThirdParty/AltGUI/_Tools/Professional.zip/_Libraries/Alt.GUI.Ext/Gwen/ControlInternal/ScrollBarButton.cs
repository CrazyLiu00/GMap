﻿//  Original source code has been modified by AltSoftLab Inc. 2012-2015
//  This source code is provided "as is" without express or implied warranty of any kind.

using System;
using Alt.GUI.Temporary.Gwen.Control;

namespace Alt.GUI.Temporary.Gwen.ControlInternal
{
    /// <summary>
    /// Scrollbar button.
    /// </summary>
    public class ScrollBarButton : Gwen.Control.Button
    {
        Pos m_Direction;


        /// <summary>
        /// Initializes a new instance of the <see cref="ScrollBarButton"/> class.
        /// </summary>
        /// <param name="parent">Parent control.</param>
        public ScrollBarButton(Base parent)
            : base(parent)
        {
            SetDirectionUp();
        }

        public virtual void SetDirectionUp()
        {
            m_Direction = Pos.Top;
        }

        public virtual void SetDirectionDown()
        {
            m_Direction = Pos.Bottom;
        }

        public virtual void SetDirectionLeft()
        {
            m_Direction = Pos.Left;
        }

        public virtual void SetDirectionRight()
        {
            m_Direction = Pos.Right;
        }

        /// <summary>
        /// Renders the control using specified skin.
        /// </summary>
        /// <param name="skin">Skin to use.</param>
        protected override void Render(Skin.Base skin)
        {
            skin.DrawScrollButton(this, m_Direction, IsDepressed, IsHovered, IsDisabled);
        }
    }
}
