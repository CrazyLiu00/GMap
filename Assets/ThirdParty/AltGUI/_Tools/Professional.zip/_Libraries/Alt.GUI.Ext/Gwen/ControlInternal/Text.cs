﻿//  Original source code has been modified by AltSoftLab Inc. 2012-2015
//  This source code is provided "as is" without express or implied warranty of any kind.

//#define DEBUG_TEXT_MEASURE

using System;

using Alt.Sketch;

using Alt.GUI.Temporary.Gwen.Control;


namespace Alt.GUI.Temporary.Gwen.ControlInternal
{
    /// <summary>
    /// Displays text. Always sized to contents.
    /// </summary>
    public class Text : Base
    {
        String m_String;
        Font m_Font;


        /// <summary>
        /// Font used to display the text.
        /// </summary>
        /// <remarks>
        /// The font is not being disposed by this class.
        /// </remarks>
        public Font Font
        {
            get { return m_Font; }
            set
            {
                m_Font = value;
                SizeToContents();
            }
        }


        /// <summary>
        /// Text to display.
        /// </summary>
        public String String
        {
            get { return m_String; }
            set
            {
                m_String = value;
                SizeToContents();
            }
        }


		Color m_TextColor = Color.White;
        /// <summary>
        /// Text color.
        /// </summary>
        public Color TextColor
		{
			get
			{
				return m_TextColor;
			}
			set
			{
				m_TextColor = value;
			}
		}


        /// <summary>
        /// Determines whether the control should be automatically resized to fit the text.
        /// </summary>
        //public bool AutoSizeToContents { get; set; } // [omeg] added


        /// <summary>
        /// Text length in characters.
        /// </summary>
        public int Length { get { return String.Length; } }


		Color m_TextColorOverride = Color.White;
        /// <summary>
        /// Text color override - used by tooltips.
        /// </summary>
        public Color TextColorOverride
		{
			get
			{
				return m_TextColorOverride;
			}
			set
			{
				m_TextColorOverride = value;
			}
		}


		String m_TextOverride;
        /// <summary>
        /// Text override - used to display different string.
        /// </summary>
        public String TextOverride
		{
			get
			{
				return m_TextOverride;
			}
			set
			{
				m_TextOverride = value;
			}
		}


        /// <summary>
        /// Initializes a new instance of the <see cref="Text"/> class.
        /// </summary>
        /// <param name="parent">Parent control.</param>
        public Text(Base parent)
            : base(parent)
        {
            m_Font = Skin.DefaultFont;
            m_String = string.Empty;
            TextColor = Skin.Colors.Label.Default;
            MouseInputEnabled = false;
            TextColorOverride = Color.FromArgb(0, 255, 255, 255); // A==0, override disabled
        }


        /// <summary>
        /// Renders the control using specified skin.
        /// </summary>
        /// <param name="skin">Skin to use.</param>
        protected override void Render(Skin.Base skin)
        {
            if (Length == 0 || Font == null) return;

            if (TextColorOverride.A == 0)
                skin.Renderer.DrawColor = TextColor;
            else
                skin.Renderer.DrawColor = TextColorOverride;

            skin.Renderer.RenderText(Font, PointI.Empty, TextOverride ?? String);

#if DEBUG_TEXT_MEASURE
            {
                PointI lastPos = PointI.Empty;

                for (int i = 0; i < m_String.Length + 1; i++)
                {
                    String sub = (TextOverride ?? String).Substring(0, i);
                    PointI p = Skin.Renderer.MeasureText(Font, sub);

                    RectI rect = new RectI();
                    rect.Location = lastPos;
                    rect.Size = new Size(p.X - lastPos.X, p.Y);
                    skin.Renderer.DrawColor = Color.FromArgb(64, 0, 0, 0);
                    skin.Renderer.DrawLinedRect(rect);

                    lastPos = new PointI(rect.Right, 0);
                }
            }
#endif
        }


        /// <summary>
        /// Lays out the control's interior according to alignment, padding, dock etc.
        /// </summary>
        /// <param name="skin">Skin to use.</param>
        protected override void Layout(Skin.Base skin)
        {
            SizeToContents();

            base.Layout(skin);
        }


        /// <summary>
        /// Handler invoked when control's scale changes.
        /// </summary>
        protected override void OnScaleChanged()
        {
            Invalidate();
        }


        /// <summary>
        /// Sizes the control to its contents.
        /// </summary>
        public void SizeToContents()
        {
            if (String == null)
                return;

            if (Font == null)
            {
                throw new InvalidOperationException("Text.SizeToContents() - No Font!!\n");
            }

            SizeI p = new SizeI(1, (int)(Font.Size + 0.5));

            if (Length > 0)
            {
                p = Skin.Renderer.MeasureText(Font, TextOverride ?? String);
            }

            if (p.Width == Width && p.Height == Height)
                return;

            SetSize(p.Width, p.Height);
            Invalidate();
            InvalidateParent();
        }


        /// <summary>
        /// Gets the coordinates of specified character in the text.
        /// </summary>
        /// <param name="index">Character index.</param>
        /// <returns>Character position in local coordinates.</returns>
        public PointI GetCharacterPosition(int index)
        {
            if (Length == 0 || index <= 0)
            {
                return new PointI(0, 0);
            }

            if (!string.IsNullOrEmpty(TextOverride ?? String))
            {
                int len = (TextOverride ?? String).Length;
                if (index > len)
                {
                    index = len;
                }

                String sub = (TextOverride ?? String).Substring(0, index);
                SizeI p = Skin.Renderer.MeasureText(Font, sub);

                return p.ToPointI();
            }

            return PointI.Zero;
        }


        /// <summary>
        /// Searches for a character closest to given point.
        /// </summary>
        /// <param name="p">PointI.</param>
        /// <returns>Character index.</returns>
        public int GetClosestCharacter(PointI p)
        {
            int distance = MaxCoord;
            int c = 0;

            for (int i = 0; i < String.Length + 1; i++)
            {
                PointI cp = GetCharacterPosition(i);
                int dist = Math.Abs(cp.X - p.X); // TODO: handle multiline

                if (dist > distance)
                    continue;

                distance = dist;
                c = i;
            }

            return c;
        }
    }
}
