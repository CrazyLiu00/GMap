﻿//  Original source code has been modified by AltSoftLab Inc. 2012-2015
//  This source code is provided "as is" without express or implied warranty of any kind.

using Alt.GUI.Temporary.Gwen.Control;
using Alt.GUI.Temporary.Gwen.Input;

using Alt.Sketch;


namespace Alt.GUI.Temporary.Gwen
{
    /// <summary>
    /// Tooltip handling.
    /// </summary>
    public class ToolTipHandler
    {
        Canvas m_Canvas;
        public InputHandler InputHandler
        {
            get
            {
                return m_Canvas.InputHandler;
            }
        }

        
        Base g_ToolTip;


        internal ToolTipHandler(Canvas canvas)
        {
            m_Canvas = canvas;
        }


        /// <summary>
        /// Enables tooltip display for the specified control.
        /// </summary>
        /// <param name="control">Target control.</param>
        public void Enable(Base control)
        {
            if (control == null ||
                control.ToolTip == null)
            {
                return;
            }

            if (g_ToolTip != control)
            {
                Alt.ComponentModel.CancelEventArgs args = new Alt.ComponentModel.CancelEventArgs();

                control.ToolTip.OnPopupAsToolTip(control, args);
                
                if (args.Cancel)
                {
                    return;
                }
            }

            g_ToolTip = control;
        }


        /// <summary>
        /// Disables tooltip display for the specified control.
        /// </summary>
        /// <param name="control">Target control.</param>
        public void Disable(Base control)
        {
            if (g_ToolTip == control)
            {
                g_ToolTip = null;
            }
        }


        /// <summary>
        /// Disables tooltip display for the specified control.
        /// </summary>
        /// <param name="control">Target control.</param>
        public void ControlDeleted(Base control)
        {
            Disable(control);
        }


        /// <summary>
        /// Renders the currently visible tooltip.
        /// </summary>
        /// <param name="skin"></param>
        public void RenderToolTip(Skin.Base skin)
        {
            if (g_ToolTip == null ||
                g_ToolTip.ToolTip == null)
            {
                return;
            }

            Renderer.Base render = skin.Renderer;

            //PointI oldRenderOffset = render.RenderOffset;
            PointI mousePos = InputHandler.MousePosition;
            RectI bounds = g_ToolTip.ToolTip.Bounds;

            RectI offsetRect = Util.FloatRect(mousePos.X - bounds.Width * 0.5f, mousePos.Y - bounds.Height - 10, bounds.Width, bounds.Height);
            offsetRect = Util.ClampRectToRect(offsetRect, g_ToolTip.GetCanvas().Bounds);
            PointI offset = offsetRect.Location;

            //Calculate offset on screen bounds
            render.AddRenderOffset(offset);
            render.EndClip();

            if (!g_ToolTip.ToolTip.OwnerDraw)
            {
                skin.DrawToolTip(g_ToolTip.ToolTip);
            }

            g_ToolTip.ToolTip.ToolTipLayout(skin);
            g_ToolTip.ToolTip.DoRender(skin);

            //render.RenderOffset = oldRenderOffset;
            render.AddRenderOffset(-offset);
            render.StartClip();
        }
    }
}
