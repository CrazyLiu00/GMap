﻿//  Original source code has been modified by AltSoftLab Inc. 2012-2015
//  This source code is provided "as is" without express or implied warranty of any kind.

using System;
using System.Text.RegularExpressions;

using Alt.Sketch;


namespace Alt.GUI.Temporary.Gwen
{
    /// <summary>
    /// Misc utility functions.
    /// </summary>
    public static class Util
    {
        public static int Round(float x)
        {
            return (int)Math.Round(x
#if !SILVERLIGHT
                , MidpointRounding.AwayFromZero
#endif
                );
        }
        /*
        public static int Trunc(float x)
        {
            return (int)Math.Truncate(x);
        }
        */
        public static int Ceil(double x)
        {
            return (int)Math.Ceiling(x);
        }


        public static PointI FloatPoint(double x, double y)
        {
            return new PointI((int)x, (int)y);
        }

        public static RectI FloatRect(double x, double y, double w, double h)
        {
            return new RectI((int)x, (int)y, (int)w, (int)h);
        }


        public static int Clamp(int x, int min, int max)
        {
            if (x < min)
                return min;
            if (x > max)
                return max;
            return x;
        }

        public static float Clamp(float x, float min, float max)
        {
            if (x < min)
                return min;
            if (x > max)
                return max;
            return x;
        }


        public static RectI ClampRectToRect(RectI inside, RectI outside)//, bool clampSize = false)
        {
            return ClampRectToRect(inside, outside, false);
        }

        public static RectI ClampRectToRect(RectI inside, RectI outside, bool clampSize)// = false)
        {
            if (inside.X < outside.X)
                inside.X = outside.X;

            if (inside.Y < outside.Y)
                inside.Y = outside.Y;

            if (inside.Right > outside.Right)
            {
                if (clampSize)
                    inside.Width = outside.Width;
                else
                    inside.X = outside.Right - inside.Width;
            }
            if (inside.Bottom > outside.Bottom)
            {
                if (clampSize)
                    inside.Height = outside.Height;
                else
                    inside.Y = outside.Bottom - inside.Height;
            }

            return inside;
        }


        // from http://stackoverflow.com/questions/359612/how-to-change-rgb-color-to-hsv
        public static HSV ToHSV(//this
            Color color)
        {
            HSV hsv = new HSV();
            int max = Math.Max(color.R, Math.Max(color.G, color.B));
            int min = Math.Min(color.R, Math.Min(color.G, color.B));

            hsv.h = (float)color.GetHue();
            hsv.s = (max == 0) ? 0 : 1f - (1f * min / max);
            hsv.v = max / 255f;

            return hsv;
        }


        public static Color HSVToColor(float h, float s, float v)
        {
            int hi = Convert.ToInt32(Math.Floor(h / 60)) % 6;
            float f = h / 60 - (float)Math.Floor(h / 60);

            v = v * 255;
            int va = Convert.ToInt32(v);
            int p = Convert.ToInt32(v * (1 - s));
            int q = Convert.ToInt32(v * (1 - f * s));
            int t = Convert.ToInt32(v * (1 - (1 - f) * s));

            if (hi == 0)
                return Color.FromArgb(255, va, t, p);
            if (hi == 1)
                return Color.FromArgb(255, q, va, p);
            if (hi == 2)
                return Color.FromArgb(255, p, va, t);
            if (hi == 3)
                return Color.FromArgb(255, p, q, va);
            if (hi == 4)
                return Color.FromArgb(255, t, p, va);
            return Color.FromArgb(255, va, p, q);
        }


        // can't create extension operators
        /*NoNeed
        public static Color Subtract(this Color color, Color other)
        {
            return Color.FromArgb(color.A - other.A, color.R - other.R, color.G - other.G, color.B - other.B);
        }

        public static Color Add(this Color color, Color other)
        {
            return Color.FromArgb(color.A + other.A, color.R + other.R, color.G + other.G, color.B + other.B);
        }

        public static Color Multiply(this Color color, float amount)
        {
            return Color.FromArgb(color.A, (int)(color.R * amount), (int)(color.G * amount), (int)(color.B * amount));
        }

        public static RectI Add(this RectI r, RectI other)
        {
            return new RectI(r.X + other.X, r.Y + other.Y, r.Width + other.Width, r.Height + other.Height);
        }*/


        /// <summary>
        /// Splits a string but keeps the separators intact (at the end of split parts).
        /// </summary>
        /// <param name="text">String to split.</param>
        /// <param name="separators">Separator characters.</param>
        /// <returns>Split strings.</returns>
        public static String[] SplitAndKeep(String text, String separators)
        {
            return Regex.Split(text, @"(?=[" + separators + "])");
        }


        static DateTime m_LastTime;
        static float m_CurrentTime;


        /// <summary>
        /// Gets time since last measurement.
        /// </summary>
        /// <returns>Time interval in seconds.</returns>
        public static float GetTimeInSeconds()
        {
            DateTime time = DateTime.UtcNow;
            TimeSpan diff = time - m_LastTime;
            double seconds = diff.TotalSeconds;
            if (seconds > 0.1)
                seconds = 0.1;
            m_CurrentTime += (float)seconds;
            m_LastTime = time;
            return m_CurrentTime;
        }
    }
}
