﻿//  Original source code has been modified by AltSoftLab Inc. 2012-2015
//  This source code is provided "as is" without express or implied warranty of any kind.

using System;
using System.Collections.Generic;
using System.Diagnostics;

using Alt.GUI.Temporary.Gwen.Anim;
using Alt.GUI.Temporary.Gwen.DragDrop;
using Alt.GUI.Temporary.Gwen.Input;
using Alt.GUI;
using Alt.Sketch;


namespace Alt.GUI.Temporary.Gwen.Control
{
    /// <summary>
    /// Base control class.
    /// </summary>
    public class Base : IDisposable
    {
        Timer m_InvokeTimer;

        List<Delegate> m_GUIDeferredCalls = new List<Delegate>();
        void InvokeTimer_Tick(object sender, EventArgs e)
        {
            lock (m_GUIDeferredCalls)
            {
                foreach (Delegate methodInvoker in m_GUIDeferredCalls)
                {
                    try
                    {
                        methodInvoker.DynamicInvoke(null);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.ToString());
                    }
                }

                m_GUIDeferredCalls.Clear();

                StopInvokeTimer();
            }
        }

        public void Invoke(Delegate method)
        {
            lock (m_GUIDeferredCalls)
            {
                m_GUIDeferredCalls.Add(method);

                StartInvokeTimer();
            }
        }


        public //IAsyncResult
            void BeginInvoke(Delegate method)
        {
            /*object[] prms = null;
            if (method is EventHandler)
                prms = new object[] { this, EventArgs.Empty };
            return BeginInvokeInternal(method, prms);*/

            Invoke(method);
        }


        void StartInvokeTimer()
        {
            if (m_InvokeTimer == null)
            {
                m_InvokeTimer = new Timer();
                m_InvokeTimer.Interval = 1;
                m_InvokeTimer.Tick += new EventHandler(InvokeTimer_Tick);
            }

            m_InvokeTimer.Start();
        }

        void StopInvokeTimer()
        {
            if (m_InvokeTimer != null)
            {
                m_InvokeTimer.Stop();
            }
        }



        public bool Capture
        {
            get
            {
                return InputHandler.MouseFocus == this;
            }
            set
            {
                InputHandler.MouseFocus = value ? this : null;
            }
        }


        public InputHandler InputHandler
        {
            get
            {
                return GetCanvas().InputHandler;
            }
        }

        public DragAndDrop DragAndDrop
        {
            get
            {
                return GetCanvas().DragAndDrop;
            }
        }

        public ToolTipHandler ToolTipHandler
        {
            get
            {
                return GetCanvas().ToolTipHandler;
            }
        }


        public static Font DefaultRenderFont
        {
            get
            {
                //return new Font("Microsoft Sans Serif", 8.25f);
                return new Alt.Sketch.Font(FontFamily.GenericSansSerif, 8.25);
            }//, "DefaultFont"); }
        }


        public event EventHandler Click;
        protected virtual void OnClick(EventArgs e)
        {
            if (Click != null)
            {
                Click(this, e);
            }
        }

        public event EventHandler DoubleClick;
        protected virtual void OnDoubleClick(EventArgs e)
        {
            if (DoubleClick != null)
            {
                DoubleClick(this, e);
            }
        }


        public event EventHandler MouseEnter;
        public event EventHandler MouseLeave;
        public event MouseEventHandler MouseMove;
        public event MouseEventHandler MouseDown;
        public event MouseEventHandler MouseUp;
        public event MouseEventHandler MouseClick;
        public event MouseEventHandler MouseDoubleClick;
        public event MouseEventHandler MouseWheel;

        public event PreviewKeyDownEventHandler PreviewKeyDown;
        public event KeyEventHandler KeyDown;
        public event KeyPressEventHandler KeyPress;
        public event KeyEventHandler KeyUp;


        object m_Tag;
        public object Tag
        {
            get
            {
                return m_Tag;
            }
            set
            {
                m_Tag = value;
            }
        }


        public MouseButtons MouseButtons
        {
            get
            {
                return InputHandler.MouseButtons;
            }
        }


        public PointI MousePosition
        {
            get
            {
                return InputHandler.MousePosition;
            }
        }


        public Keys ModifierKeys
        {
            get
            {
                return InputHandler.ModifierKeys;
            }
        }


        public PointI PointToScreen(PointI p)
        {
            return LocalPosToCanvas(p + InnerBounds.Location);
        }


        public RectI RectangleToScreen(RectI r)
        {
            return new RectI(PointToScreen(r.Location), r.Size);
        }


        public PointI PointToClient(PointI p)
        {
            return CanvasPosToLocal(p - InnerBounds.Location);
        }


        public RectI RectangleToClient(RectI r)
        {
            return new RectI(PointToClient(r.Location), r.Size);
        }


        Menu m_ContextMenu;
        public Menu ContextMenu
        {
            get
            {
                return m_ContextMenu;
            }
            set
            {
                if (m_ContextMenu == value)
                {
                    return;
                }

                if (m_ContextMenu != null)
                {
                    m_ContextMenu.Close();
                    m_ContextMenu.Dispose();
                }

                m_ContextMenu = value;
                m_ContextMenu.Parent = GetCanvas();
            }
        }


        string m_HtmlTooltipText = string.Empty;
        internal virtual string HtmlTooltipText
        {
            get
            {
                return m_HtmlTooltipText;
            }
            set
            {
                m_HtmlTooltipText = value;
            }
        }


        bool m_OwnerDraw = false;
        public bool OwnerDraw
        {
            get
            {
                return m_OwnerDraw;
            }
            set
            {
                m_OwnerDraw = value;
            }
        }


        // this REALLY needs to be replaced with control-specific events
        /// <summary>
        /// Delegate used for all control event handlers.
        /// </summary>
        /// <param name="control">Event source.</param>
        public delegate void GwenEventHandler(Base control);


        bool m_Disposed;
        public bool IsDisposed
        {
            get
            {
                return m_Disposed;
            }
        }


        Base m_Parent;

        /// <summary>
        /// This is the panel's actual parent - most likely the logical 
        /// parent's InnerPanel (if it has one). You should rarely need this.
        /// </summary>
        Base m_ActualParent;

        /// <summary>
        /// If the innerpanel exists our children will automatically become children of that 
        /// instead of us - allowing us to move them all around by moving that panel (useful for scrolling etc).
        /// </summary>
        protected Base m_InnerPanel;

        Base m_ToolTip;

        Skin.Base m_Skin;

        RectI m_Bounds;
        RectI m_RenderBounds;
        RectI m_InnerBounds;
        Padding m_Padding;
        Margin m_Margin;

        String m_Name;

        bool m_RestrictToParent;
        bool m_Disabled;
        bool m_Hidden;
        bool m_MouseInputEnabled;
        bool m_KeyboardInputEnabled;
        bool m_DrawBackground;

        Pos m_Dock;

        Alt.GUI.Cursor m_Cursor;

        bool m_Tabable;

        bool m_NeedsLayout;
        bool m_CacheTextureDirty;
        bool m_CacheToTexture;

        Package m_DragAndDrop_Package;

        object m_UserData;

        bool m_DrawDebugOutlines;


        /// <summary>
        /// double list of children.
        /// </summary>
        readonly List<Base> m_Children;

        /// <summary>
        /// Invoked when mouse pointer enters the control.
        /// </summary>
        public event GwenEventHandler HoverEnter;


        /// <summary>
        /// Invoked when mouse pointer leaves the control.
        /// </summary>
        public event GwenEventHandler HoverLeave;


        /// <summary>
        /// Invoked when control's bounds have been changed.
        /// </summary>
        public event GwenEventHandler BoundsChanged;


        /// <summary>
        /// Accelerator map.
        /// </summary>
        readonly Dictionary<String, GwenEventHandler> m_Accelerators;


        public const int MaxCoord = 4096; // added here from various places in code


        /// <summary>
        /// Logical list of children. If InnerPanel is not null, returns InnerPanel's children.
        /// </summary>
        public List<Base> Children
        {
            get
            {
                if (m_InnerPanel != null)
                {
                    return m_InnerPanel.Children;
                }

                return m_Children;
            }
        }


        /// <summary>
        /// The logical parent. It's usually what you expect, the control you've parented it to.
        /// </summary>
        public Base Parent
        {
            get
            {
                return m_Parent;
            }
            set
            {
                if (m_Parent == value)
                {
                    return;
                }

                if (m_Parent != null)
                {
                    m_Parent.RemoveChild(this, false);
                }

                m_Parent = value;
                m_ActualParent = null;

                if (m_Parent != null)
                {
                    m_Parent.AddChild(this);
                }
            }
        }


        // todo: ParentChanged event?

        /// <summary>
        /// Dock position.
        /// </summary>
        public Pos Dock
        {
            get { return m_Dock; }
            set
            {
                if (m_Dock == value)
                    return;

                m_Dock = value;

                Invalidate();
                InvalidateParent();
            }
        }


        /// <summary>
        /// Current skin.
        /// </summary>
        public Skin.Base Skin
        {
            get
            {
                if (m_Skin != null)
                {
                    return m_Skin;
                }

                if (m_Parent != null)
                {
                    return m_Parent.Skin;
                }

                throw new InvalidOperationException("GetSkin: null");
            }
        }


        /// <summary>
        /// Current tooltip.
        /// </summary>
        public virtual Base ToolTip
        {
            get
            {
                return m_ToolTip;
            }
            set
            {
                m_ToolTip = value;
                if (m_ToolTip != null)
                {
                    m_ToolTip.Parent = this;
                    m_ToolTip.IsHidden = true;
                }

                if (IsHovered)
                {
                    if (ToolTip != null)
                    {
                        ToolTipHandler.Enable(this);
                    }
                    else
                    {
                        ToolTipHandler.Disable(this);
                    }
                }
            }
        }


        /// <summary>
        /// Indicates whether this control is a menu component.
        /// </summary>
        internal virtual bool IsMenuComponent
        {
            get
            {
                if (m_Parent == null)
                    return false;
                return m_Parent.IsMenuComponent;
            }
        }

        /// <summary>
        /// Determines whether the control should be clipped to its bounds while rendering.
        /// </summary>
        protected virtual bool ShouldClip { get { return true; } }

        /// <summary>
        /// Current padding - inner spacing.
        /// </summary>
        public Padding Padding
        {
            get { return m_Padding; }
            set
            {
                if (m_Padding == value)
                    return;

                m_Padding = value;
                Invalidate();
                InvalidateParent();
            }
        }

        /// <summary>
        /// Current margin - outer spacing.
        /// </summary>
        public Margin Margin
        {
            get { return m_Margin; }
            set
            {
                if (m_Margin == value)
                    return;

                m_Margin = value;
                Invalidate();
                InvalidateParent();
            }
        }

        /// <summary>
        /// Indicates whether the control is on top of its parent's children.
        /// </summary>
        public virtual bool IsOnTop
        {
            get
            {
                //NET20 return this == Parent.m_Children.First();
                foreach (Base first in Parent.m_Children)
                {
                    return this == first;
                }
                return false;
            }
        } // todo: validate


        /// <summary>
        /// User data associated with the control.
        /// </summary>
        public object UserData { get { return m_UserData; } set { m_UserData = value; } }

        /// <summary>
        /// Indicates whether the control is hovered by mouse pointer.
        /// </summary>
        public virtual bool IsHovered { get { return InputHandler.HoveredControl == this; } }

        /// <summary>
        /// Indicates whether the control has focus.
        /// </summary>
        public bool HasFocus { get { return InputHandler.KeyboardFocus == this; } }

        /// <summary>
        /// Indicates whether the control is disabled.
        /// </summary>
        public bool IsDisabled { get { return m_Disabled; } set { m_Disabled = value; } }
        public bool Enabled { get { return !IsDisabled; } set { IsDisabled = !value; } }


        /// <summary>
        /// Indicates whether the control is hidden.
        /// </summary>
        public virtual bool IsHidden { get { return m_Hidden; } set { if (value == m_Hidden) return; m_Hidden = value; Invalidate(); } }

        /// <summary>
        /// Determines whether the control's position should be restricted to parent's bounds.
        /// </summary>
        public bool RestrictToParent { get { return m_RestrictToParent; } set { m_RestrictToParent = value; } }

        /// <summary>
        /// Determines whether the control receives mouse input events.
        /// </summary>
        public bool MouseInputEnabled { get { return m_MouseInputEnabled; } set { m_MouseInputEnabled = value; } }

        /// <summary>
        /// Determines whether the control receives keyboard input events.
        /// </summary>
        public bool KeyboardInputEnabled { get { return m_KeyboardInputEnabled; } set { m_KeyboardInputEnabled = value; } }

        /// <summary>
        /// Gets or sets the mouse cursor when the cursor is hovering the control.
        /// </summary>
        public Alt.GUI.Cursor Cursor { get { return m_Cursor; } set { m_Cursor = value; } }

        /// <summary>
        /// Indicates whether the control is tabable (can be focused by pressing Tab).
        /// </summary>
        public bool IsTabable { get { return m_Tabable; } set { m_Tabable = value; } }

        /// <summary>
        /// Indicates whether control's background should be drawn during rendering.
        /// </summary>
        public virtual bool ShouldDrawBackground { get { return m_DrawBackground; } set { m_DrawBackground = value; } }

        /// <summary>
        /// Indicates whether the renderer should cache drawing to a texture to improve performance (at the cost of memory).
        /// </summary>
        public bool ShouldCacheToTexture { get { return m_CacheToTexture; } set { m_CacheToTexture = value; /*Children.ForEach(x => x.ShouldCacheToTexture=value);*/ } }

        /// <summary>
        /// Gets or sets the control's internal name.
        /// </summary>
        public String Name { get { return m_Name; } set { m_Name = value; } }

        /// <summary>
        /// Control's size and position relative to the parent.
        /// </summary>
        public RectI Bounds { get { return m_Bounds; } }

        /// <summary>
        /// Bounds for the renderer.
        /// </summary>
        public RectI RenderBounds { get { return m_RenderBounds; } }


        /// <summary>
        /// Bounds adjusted by padding.
        /// </summary>
        public RectI InnerBounds { get { return m_InnerBounds; } }
        public RectI ClientRectangle
        {
            get
            {
                return new RectI(PointI.Zero, InnerBounds.Size);
            }
        }

        public SizeI ClientSize
        {
            get
            {
                return ClientRectangle.Size;
            }
        }

        public int ClientWidth
        {
            get
            {
                return ClientSize.Width;
            }
        }

        public int ClientHeight
        {
            get
            {
                return ClientSize.Height;
            }
        }


        /// <summary>
        /// Size restriction.
        /// </summary>
        public virtual SizeI MinimumSize { get { return m_MinimumSize; } set { m_MinimumSize = value; } }

        /// <summary>
        /// Size restriction.
        /// </summary>
        public virtual SizeI MaximumSize { get { return m_MaximumSize; } set { m_MaximumSize = value; } }

        private SizeI m_MinimumSize = new SizeI(1, 1);
        private SizeI m_MaximumSize = new SizeI(MaxCoord, MaxCoord);

        /// <summary>
        /// Determines whether hover should be drawn during rendering.
        /// </summary>
        protected bool ShouldDrawHover { get { return InputHandler.MouseFocus == this || InputHandler.MouseFocus == null; } }

        protected virtual bool AccelOnlyFocus { get { return false; } }
        protected virtual bool NeedsInputChars { get { return false; } }


        /// <summary>
        /// Indicates whether the control and its parents are visible.
        /// </summary>
        public bool IsVisible
        {
            get
            {
                if (IsHidden)
                    return false;

                if (Parent != null)
                    return Parent.IsVisible;

                return true;
            }
        }


        /*public bool Visible
        {
            get
            {
                return IsVisible;
            }
        }*/


        /// <summary>
        /// Leftmost coordinate of the control.
        /// </summary>
        public int X { get { return m_Bounds.X; } set { SetPosition(value, Y); } }
        public int Left { get { return X; } set { X = value; } }
        /// <summary>
        /// Topmost coordinate of the control.
        /// </summary>
        public int Y { get { return m_Bounds.Y; } set { SetPosition(X, value); } }
        public int Top { get { return Y; } set { Y = value; } }
        public PointI Location
        {
            get
            {
                return new PointI(X, Y);
            }
            set
            {
                SetPosition(value.X, value.Y);
            }
        }


        // todo: Bottom/Right includes margin but X/Y not?

        public int Width { get { return m_Bounds.Width; } set { SetSize(value, Height); } }
        public int Height { get { return m_Bounds.Height; } set { SetSize(Width, value); } }
        public SizeI Size
        {
            get
            {
                return new SizeI(Width, Height);
            }
            set
            {
                SetSize(value.Width, value.Height);
            }
        }


        public int Bottom { get { return m_Bounds.Bottom + m_Margin.Bottom; } }
        public int Right { get { return m_Bounds.Right + m_Margin.Right; } }


        /// <summary>
        /// Determines whether margin, padding and bounds outlines for the control will be drawn. Applied recursively to all children.
        /// </summary>
        public bool DrawDebugOutlines
        {
            get { return m_DrawDebugOutlines; }
            set
            {
                if (m_DrawDebugOutlines == value)
                    return;
                m_DrawDebugOutlines = value;
                foreach (Base child in Children)
                {
                    child.DrawDebugOutlines = value;
                }
            }
        }


		Color m_PaddingOutlineColor = Color.Empty;
        public Color PaddingOutlineColor
		{
			get
			{
				return m_PaddingOutlineColor;
			}
			set
			{
				m_PaddingOutlineColor = value;
			}
		}

		Color m_MarginOutlineColor = Color.Empty;
        public Color MarginOutlineColor
		{
			get
			{
				return m_MarginOutlineColor;
			}
			set
			{
				m_MarginOutlineColor = value;
			}
		}

		Color m_BoundsOutlineColor = Color.Empty;
        public Color BoundsOutlineColor
		{
			get
			{
				return m_BoundsOutlineColor;
			}
			set
			{
				m_BoundsOutlineColor = value;
			}
		}


        /// <summary>
        /// Initializes a new instance of the <see cref="Base"/> class.
        /// </summary>
        /// <param name="parent">Parent control.</param>
        public Base()//Base parent = null)
            : this(null)
        {
        }


        public Base(Base parent)// = null)
        {
            m_Children = new List<Base>();
            m_Accelerators = new Dictionary<string, GwenEventHandler>();

            Parent = parent;

            m_Hidden = false;
            m_Bounds = new RectI(0, 0, 10, 10);
            m_Padding = Padding.Zero;
            m_Margin = Margin.Zero;

            RestrictToParent = false;

            MouseInputEnabled = true;
            KeyboardInputEnabled = false;

            Invalidate();
            Cursor = Alt.GUI.Cursors.Default;
            //ToolTip = null;
            IsTabable = false;
            ShouldDrawBackground = true;
            m_Disabled = false;
            m_CacheTextureDirty = true;
            m_CacheToTexture = false;

            BoundsOutlineColor = Color.Yellow;// Red * 0.9;
            MarginOutlineColor = Color.LightGreen;// Green * 0.9;
            PaddingOutlineColor = Color.Cyan;// Blue * 0.9;
        }


        public event EventHandler Disposed;

        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public virtual void Dispose()
        {
            //Debug.Print("Control.Base: Disposing {0} {1:X}", this, GetHashCode());
            if (m_Disposed)
            {
#if DEBUG
                throw new ObjectDisposedException(String.Format("Control.Base [{1:X}] disposed twice: {0}", this, GetHashCode()));
#else
                return;
#endif
            }

            if (InputHandler.HoveredControl == this)
                InputHandler.HoveredControl = null;
            if (InputHandler.KeyboardFocus == this)
                InputHandler.KeyboardFocus = null;
            if (InputHandler.MouseFocus == this)
                InputHandler.MouseFocus = null;

            DragAndDrop.ControlDeleted(this);
            ToolTipHandler.ControlDeleted(this);
            Animation.Cancel(this);

            foreach (Base child in m_Children)
                child.Dispose();

            m_Children.Clear();


            m_Disposed = true;
            GC.SuppressFinalize(this);


            if (Disposed != null)
            {
                Disposed(this, EventArgs.Empty);
            }
        }


#if DEBUG
        ~Base()
        {
            //TEMP  throw new InvalidOperationException(String.Format("IDisposable object finalized [{1:X}]: {0}", this, GetHashCode()));
            //Debug.Print(String.Format("IDisposable object finalized: {0}", GetType()));
        }
#endif


        /// <summary>
        /// Detaches the control from canvas and adds to the deletion queue (processed in Canvas.DoThink).
        /// </summary>
        public void DelayedDelete()
        {
            Canvas canvas = GetCanvas();
            //if (canvas != null)
            {
                canvas.AddDelayedDelete(this);
            }
        }


        public override string ToString()
        {
            if (this is MenuItem)
                return "[MenuItem: " + (this as MenuItem).Text + "]";
            if (this is Label)
                return "[Label: " + (this as Label).Text + "]";
            if (this is ControlInternal.Text)
                return "[Text: " + (this as ControlInternal.Text).String + "]";
            return GetType().ToString();
        }


        /// <summary>
        /// Gets the canvas (root parent) of the control.
        /// </summary>
        /// <returns></returns>
        public virtual Canvas GetCanvas()
        {
            Base canvas = m_Parent;
            if (canvas == null)
            {
                return null;
            }

            return canvas.GetCanvas();
        }

        public virtual Canvas GetCurrentCanvas()
        {
            Base canvas = m_Parent;
            if (canvas == null)
            {
                return null;
            }

            return canvas.GetCurrentCanvas();
        }


        /// <summary>
        /// Enables the control.
        /// </summary>
        public void Enable()
        {
            IsDisabled = false;
        }


        /// <summary>
        /// Disables the control.
        /// </summary>
        public void Disable()
        {
            IsDisabled = true;
        }


        /// <summary>
        /// Default accelerator handler.
        /// </summary>
        /// <param name="control">Event source.</param>
        private void DefaultAcceleratorHandler(Base control)
        {
            OnAccelerator();
        }


        /// <summary>
        /// Default accelerator handler.
        /// </summary>
        protected virtual void OnAccelerator()
        {

        }


        /// <summary>
        /// Hides the control.
        /// </summary>
        public virtual void Hide()
        {
            IsHidden = true;
        }


        /// <summary>
        /// Shows the control.
        /// </summary>
        public virtual void Show()
        {
            IsHidden = false;
        }


        /// <summary>
        /// Creates a tooltip for the control.
        /// </summary>
        /// <param name="text">Tooltip text.</param>
        public virtual void SetToolTipText(String text)
        {
            SetToolTipText(text, this);
        }

        internal virtual void SetToolTipText(String text, Base control)
        {
            if (control == null)
            {
                return;
            }

            Label tooltip = control.ToolTip as Label;
            if (tooltip == null)
            {
                tooltip = new Label(control);
                tooltip.AutoSizeToContents = true;
                tooltip.TextColor = Color.Gray * 0.5;
                tooltip.UseCurrentColorAsNormal = true;

                tooltip.TextColorOverride = Skin.Colors.TooltipText;
                tooltip.Padding = new Padding(5, 3, 5, 3);

                control.ToolTip = tooltip;
            }

            tooltip.Text = text;
            tooltip.SizeToContents();
        }


        /// <summary>
        /// Invalidates the control's children (relayout/repaint).
        /// </summary>
        /// <param name="recursive">Determines whether the operation should be carried recursively.</param>
        protected void InvalidateChildren()//bool recursive = false)
        {
            InvalidateChildren(false);
        }

        protected virtual void InvalidateChildren(bool recursive)// = false)
        {
            foreach (Base child in m_Children)
            {
                child.Invalidate();
                if (recursive)
                    child.InvalidateChildren(true);
            }

            if (m_InnerPanel != null)
            {
                foreach (Base child in m_InnerPanel.m_Children)
                {
                    child.Invalidate();
                    if (recursive)
                        child.InvalidateChildren(true);
                }
            }
        }


        /// <summary>
        /// Invalidates the control.
        /// </summary>
        /// <remarks>
        /// Causes layout, repaint, invalidates cached texture.
        /// </remarks>
        public virtual void Invalidate()
        {
            m_NeedsLayout = true;
            m_CacheTextureDirty = true;
        }


        /// <summary>
        /// Sends the control to the bottom of paren't visibility stack.
        /// </summary>
        public virtual void SendToBack()
        {
            if (m_ActualParent == null)
                return;
            if (m_ActualParent.m_Children.Count == 0)
                return;

            //NET20 if (m_ActualParent.m_Children.First() == this) return;
            foreach (Base first in m_ActualParent.m_Children)
            {
                if (first == this)
                {
                    return;
                }

                break;
            }

            m_ActualParent.m_Children.Remove(this);
            m_ActualParent.m_Children.Insert(0, this);

            InvalidateParent();
        }


        /// <summary>
        /// Brings the control to the top of paren't visibility stack.
        /// </summary>
        public virtual void BringToFront()
        {
            if (m_ActualParent == null)
                return;

            //NET20 if (m_ActualParent.m_Children.Last() == this) return;
            Base last = null;
            /*foreach (Base child in m_ActualParent.m_Children)
            {
                last = child;
            }*/
            int count = m_ActualParent.m_Children.Count;
            if (count > 0)
            {
                last = m_ActualParent.m_Children[count - 1];
            }
            if (last == this) return;

            m_ActualParent.m_Children.Remove(this);
            m_ActualParent.m_Children.Add(this);
            InvalidateParent();
            Redraw();
        }


        public virtual void BringNextToControl(Base child, bool behind)
        {
            if (null == m_ActualParent)
                return;

            m_ActualParent.m_Children.Remove(this);

            // todo: validate
            int idx = m_ActualParent.m_Children.IndexOf(child);
            if (idx == m_ActualParent.m_Children.Count - 1)
            {
                BringToFront();
                return;
            }

            if (behind)
            {
                ++idx;

                if (idx == m_ActualParent.m_Children.Count - 1)
                {
                    BringToFront();
                    return;
                }
            }

            m_ActualParent.m_Children.Insert(idx, this);
            InvalidateParent();
        }


        /// <summary>
        /// Finds a child by name.
        /// </summary>
        /// <param name="name">Child name.</param>
        /// <param name="recursive">Determines whether the search should be recursive.</param>
        /// <returns>Found control or null.</returns>
        public Base FindChildByName(String name)//, bool recursive = false)
        {
            return FindChildByName(name, false);
        }


        public virtual Base FindChildByName(String name, bool recursive)// = false)
        {
#if !SILVERLIGHT
            Base b = m_Children.Find(x => x.m_Name == name);
#else
            List<Base> list = m_Children;
            Base b = null;
            foreach (Base child in list)
            {
                if (child.m_Name == name)
                {
                    b = child;
                    break;
                }
            }
#endif
            
            if (b != null)
                return b;

            if (recursive)
            {
                foreach (Base child in m_Children)
                {
                    b = child.FindChildByName(name, true);
                    if (b != null)
                        return b;
                }
            }
            return null;
        }


        /// <summary>
        /// Attaches specified control as a child of this one.
        /// </summary>
        /// <remarks>
        /// If InnerPanel is not null, it will become the parent.
        /// </remarks>
        /// <param name="child">Control to be added as a child.</param>
        public virtual void AddChild(Base child)
        {
            if (m_InnerPanel != null)
            {
                m_InnerPanel.AddChild(child);
                return;
            }

            m_Children.Add(child);
            OnChildAdded(child);

            child.m_ActualParent = this;
        }


        /// <summary>
        /// Detaches specified control from this one.
        /// </summary>
        /// <param name="child">Child to be removed.</param>
        /// <param name="dispose">Determines whether the child should be disposed (added to delayed delete queue).</param>
        public virtual void RemoveChild(Base child, bool dispose)
        {
            // If we removed our innerpanel
            // remove our pointer to it
            if (m_InnerPanel == child)
            {
                m_Children.Remove(m_InnerPanel);
                m_InnerPanel.DelayedDelete();
                m_InnerPanel = null;
                return;
            }

            if (m_InnerPanel != null &&
                m_InnerPanel.Children.Contains(child))
            {
                m_InnerPanel.RemoveChild(child, dispose);
                return;
            }

            m_Children.Remove(child);
            OnChildRemoved(child);

            if (dispose)
            {
                child.DelayedDelete();
            }
            /*else
            {
                child.m_Parent = null;
                child.m_ActualParent = null;
            }*/
        }


        /// <summary>
        /// Removes all children (and disposes them).
        /// </summary>
        public virtual void DeleteAllChildren()
        {
            DeleteAllChildren(true);
        }


        public void DeleteAllChildren(bool dispose)
        {
            // todo: probably shouldn't invalidate after each removal
            while (m_Children.Count > 0)
            {
                RemoveChild(m_Children[0], dispose);
            }
        }


        /// <summary>
        /// Handler invoked when a child is added.
        /// </summary>
        /// <param name="child">Child added.</param>
        protected virtual void OnChildAdded(Base child)
        {
            Invalidate();
        }

        /// <summary>
        /// Handler invoked when a child is removed.
        /// </summary>
        /// <param name="child">Child removed.</param>
        protected virtual void OnChildRemoved(Base child)
        {
            Invalidate();
        }

        /// <summary>
        /// Moves the control by a specific amount.
        /// </summary>
        /// <param name="x">X-axis movement.</param>
        /// <param name="y">Y-axis movement.</param>
        public virtual void MoveBy(int x, int y)
        {
            SetBounds(X + x, Y + y, Width, Height);
        }

        /// <summary>
        /// Moves the control to a specific point.
        /// </summary>
        /// <param name="x">Target x coordinate.</param>
        /// <param name="y">Target y coordinate.</param>
        public virtual void MoveTo(float x, float y)
        {
            MoveTo((int)x, (int)y);
        }

        /// <summary>
        /// Moves the control to a specific point, clamping on paren't bounds if RestrictToParent is set.
        /// </summary>
        /// <param name="x">Target x coordinate.</param>
        /// <param name="y">Target y coordinate.</param>
        public virtual void MoveTo(int x, int y)
        {
            if (RestrictToParent && (Parent != null))
            {
                Base parent = Parent;
                if (x - Padding.Left < parent.Margin.Left)
                    x = parent.Margin.Left + Padding.Left;
                if (y - Padding.Top < parent.Margin.Top)
                    y = parent.Margin.Top + Padding.Top;
                if (x + Width + Padding.Right > parent.Width - parent.Margin.Right)
                    x = parent.Width - parent.Margin.Right - Width - Padding.Right;
                if (y + Height + Padding.Bottom > parent.Height - parent.Margin.Bottom)
                    y = parent.Height - parent.Margin.Bottom - Height - Padding.Bottom;
            }

            SetBounds(x, y, Width, Height);
        }


        /// <summary>
        /// Sets the control position.
        /// </summary>
        /// <param name="x">Target x coordinate.</param>
        /// <param name="y">Target y coordinate.</param>
        public virtual void SetPosition(float x, float y)
        {
            SetPosition((int)x, (int)y);
        }


        /// <summary>
        /// Sets the control position.
        /// </summary>
        /// <param name="x">Target x coordinate.</param>
        /// <param name="y">Target y coordinate.</param>
        public virtual void SetPosition(int x, int y)
        {
            SetBounds(x, y, Width, Height);
        }


        /// <summary>
        /// Sets the control size.
        /// </summary>
        /// <param name="width">New width.</param>
        /// <param name="height">New height.</param>
        /// <returns>True if bounds changed.</returns>
        public virtual bool SetSize(int width, int height)
        {
            return SetBounds(X, Y, width, height);
        }


        /// <summary>
        /// Sets the control bounds.
        /// </summary>
        /// <param name="bounds">New bounds.</param>
        /// <returns>True if bounds changed.</returns>
        public virtual bool SetBounds(RectI bounds)
        {
            return SetBounds(bounds.X, bounds.Y, bounds.Width, bounds.Height);
        }


        /// <summary>
        /// Sets the control bounds.
        /// </summary>
        /// <param name="x">X.</param>
        /// <param name="y">Y.</param>
        /// <param name="width">Width.</param>
        /// <param name="height">Height.</param>
        /// <returns>
        /// True if bounds changed.
        /// </returns>
        public virtual bool SetBounds(float x, float y, float width, float height)
        {
            return SetBounds((int)x, (int)y, (int)width, (int)height);
        }


        /// <summary>
        /// Sets the control bounds.
        /// </summary>
        /// <param name="x">X position.</param>
        /// <param name="y">Y position.</param>
        /// <param name="width">Width.</param>
        /// <param name="height">Height.</param>
        /// <returns>
        /// True if bounds changed.
        /// </returns>
        public virtual bool SetBounds(int x, int y, int width, int height)
        {
            if (m_Bounds.X == x &&
                m_Bounds.Y == y &&
                m_Bounds.Width == width &&
                m_Bounds.Height == height)
            {
                return false;
            }

            RectI oldBounds = Bounds;

            m_Bounds.X = x;
            m_Bounds.Y = y;

            m_Bounds.Width = width;
            m_Bounds.Height = height;

            OnBoundsChanged(oldBounds);

            if (BoundsChanged != null)
                BoundsChanged.Invoke(this);

            OnSizeChanged(EventArgs.Empty);

            return true;
        }

        protected virtual void OnSizeChanged(EventArgs e)
        {
        }


        /// <summary>
        /// Positions the control inside its parent.
        /// </summary>
        /// <param name="pos">Target position.</param>
        /// <param name="xpadding">X padding.</param>
        /// <param name="ypadding">Y padding.</param>
        public void Position(Pos pos)//, int xpadding = 0, int ypadding = 0) // todo: a bit ambiguous name
        {
            Position(pos, 0, 0);
        }

        public void Position(Pos pos, int xpadding)// = 0, int ypadding = 0) // todo: a bit ambiguous name
        {
            Position(pos, xpadding, 0);
        }

        public virtual void Position(Pos pos, int xpadding// = 0
            , int ypadding)// = 0) // todo: a bit ambiguous name
        {
            int w = Parent.Width;
            int h = Parent.Height;
            Padding padding = Parent.Padding;

            int x = X;
            int y = Y;
            if (0 != (pos & Pos.Left)) x = padding.Left + xpadding;
            if (0 != (pos & Pos.Right)) x = w - Width - padding.Right - xpadding;
            if (0 != (pos & Pos.CenterH))
                x = (int)(padding.Left + xpadding + (w - Width - padding.Left - padding.Right) * 0.5f);

            if (0 != (pos & Pos.Top)) y = padding.Top + ypadding;
            if (0 != (pos & Pos.Bottom)) y = h - Height - padding.Bottom - ypadding;
            if (0 != (pos & Pos.CenterV))
                y = (int)(padding.Top + ypadding + (h - Height - padding.Bottom - padding.Top) * 0.5f);

            SetPosition(x, y);
        }


        /// <summary>
        /// Handler invoked when control's bounds change.
        /// </summary>
        /// <param name="oldBounds">Old bounds.</param>
        protected virtual void OnBoundsChanged(RectI oldBounds)
        {
            //Anything that needs to update on size changes
            //Iterate my children and tell them I've changed
            //
            if (Parent != null)
            {
                Parent.OnChildBoundsChanged(oldBounds, this);
            }

            if (m_Bounds.Width != oldBounds.Width || m_Bounds.Height != oldBounds.Height)
            {
                Invalidate();
            }

            Redraw();
            UpdateRenderBounds();
        }


        /// <summary>
        /// Handler invoked when control's scale changes.
        /// </summary>
        protected virtual void OnScaleChanged()
        {
            foreach (Base child in m_Children)
            {
                child.OnScaleChanged();
            }
        }


        /// <summary>
        /// Handler invoked when control children's bounds change.
        /// </summary>
        protected virtual void OnChildBoundsChanged(RectI oldChildBounds, Base child)
        {
        }



        //TEMP  public
        void DrawToBitmap(Bitmap bitmap, RectI targetBounds)
        {
            // Logic copied from WmPaint

            /*Graphics graphics = Graphics.FromImage(bitmap);
            // Only draw within the target bouds, and up to the size of the control
            graphics.IntersectClip(targetBounds);
            graphics.IntersectClip(Bounds);

            if (graphics != null)
            {
                PaintEventArgs pea = new PaintEventArgs(graphics, targetBounds);


                if (!GetStyle(ControlStyles.Opaque))
                {
                    OnPaintBackground(pea);
                }
                OnPaintBackgroundInternal(pea);


                OnPaintInternal(pea);
                if (!pea.Handled)
                {
                    OnPaint(pea);
                }
            }

            graphics.Dispose();*/
        }



        /// <summary>
        /// Renders the control using specified skin.
        /// </summary>
        /// <param name="skin">Skin to use.</param>
        protected virtual void Render(Skin.Base skin)
        {
            if (skin == null ||
                skin.Renderer == null)
            {
                return;
            }

            Graphics graphics = skin.Renderer.Graphics;
            if (graphics == null)
            {
                return;
            }


            GraphicsState state = graphics.Save();

            //  Clipping
            PointI oldRenderOffset = skin.Renderer.RenderOffset;
            RectI oldRegion = skin.Renderer.ClipRegion;
            {
                skin.Renderer.AddRenderOffset(InnerBounds.Location);
                graphics.RenderOffset += skin.Renderer.RenderOffset;
                graphics.RenderSize = ClientRectangle.Size;

                skin.Renderer.AddClipRegion(InnerBounds);

                skin.Renderer.StartClip();
            }


            PaintEventArgs paint_event = new PaintEventArgs(graphics, new RectI(PointI.Zero, ClientRectangle.Size));
            DoPaint(paint_event);
            OnPostPaint(paint_event);


            graphics.Restore(state);


            //  Clipping
            {
                skin.Renderer.ClipRegion = oldRegion;
                skin.Renderer.StartClip();
                skin.Renderer.RenderOffset = oldRenderOffset;
            }
        }


        internal void DoPaint(PaintEventArgs paint_event)
        {
            Graphics graphics = paint_event.Graphics;

#if DEBUG
            try
            {
#endif
            GraphicsState state = graphics.Save();

            OnPaintBackground(paint_event);
            if (!paint_event.Handled)
            {
                OnPaint(paint_event);
            }

            graphics.Restore(state);


            if (DrawBorder)
            {
                if (BorderHasRoundedAngles)
                {
                    graphics.DrawRoundedRectangle(new Pen(BorderColor, m_BorderWidth), new Rect(Point.Zero, Bounds.Size) - Sketch.Size.One, 4);
                }
                else
                {
                    graphics.DrawRectangle(new Pen(BorderColor, m_BorderWidth), new Rect(Point.Zero, Bounds.Size) - Sketch.Size.One);
                }
            }

            if (DrawClientBorder)
            {
                if (ClientBorderHasRoundedAngles)
                {
                    graphics.DrawRoundedRectangle(new Pen(ClientBorderColor, m_BorderWidth), ClientRectangle - SizeI.One, 3);
                }
                else
                {
                    graphics.DrawRectangle(new Pen(ClientBorderColor, m_BorderWidth), ClientRectangle - SizeI.One);
                }
            }
#if DEBUG
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
#endif
        }


        protected virtual void OnPostPaint(PaintEventArgs e)
        {
        }


        PaintEventHandler m_Paint;
        public event PaintEventHandler Paint
        {
            add
            {
                m_Paint += value;
            }
            remove
            {
                m_Paint -= value;
            }
        }

        void RaisePaint(PaintEventArgs e)
        {
            if (//!e.Handled &&
                m_Paint != null)
            {
                m_Paint(this, e);
            }
        }


        protected virtual void OnPaint(PaintEventArgs e)
        {
            RaisePaint(e);
        }

        protected virtual void OnPaintBackground(PaintEventArgs e)
        {
            if (ClientBackColor.A != 0)//Color.Transparent)
            {
                SmoothingMode oldSmoothingMode = e.Graphics.SmoothingMode;
                e.Graphics.SmoothingMode = SmoothingMode.None;

                if (ClientBorderHasRoundedAngles)
                {
                    e.Graphics.FillRoundedRectangle(new SolidColorBrush(ClientBackColor), ClientRectangle, 3);
                }
                else
                {
                    if (BorderHasRoundedAngles ||
                        ClientBackColor.A != 255)
                    {
                        RectI rect = ClientRectangle;
                        if (DrawClientBorder ||
                            DrawBorder)
                        {
                            rect.Deflate(SizeI.One);
                        }

                        e.Graphics.FillRectangle(new SolidColorBrush(ClientBackColor), rect);
                    }
                    else
                    {
                        //  Can be faster
                        e.Graphics.Clear(ClientBackColor);
                    }
                }

                e.Graphics.SmoothingMode = oldSmoothingMode;
            }
        }


        Color m_ClientBackColor = Color.Transparent;
        public Color ClientBackColor
        {
            get
            {
                return m_ClientBackColor;
            }
            set
            {
                m_ClientBackColor = value;

                Invalidate();
            }
        }


        bool m_DrawBorder = false;
        public bool DrawBorder
        {
            get
            {
                return m_DrawBorder;
            }
            set
            {
                m_DrawBorder = value;
            }
        }


        int m_BorderWidth = 1;
        public int BorderWidth
        {
            get
            {
                return m_BorderWidth;
            }
            set
            {
                m_BorderWidth = value;
            }
        }


        Color m_BorderColor = Color.FromArgb(255, 80, 80, 80);
        public Color BorderColor
        {
            get
            {
                return m_BorderColor;
            }
            set
            {
                m_BorderColor = value;
            }
        }


        bool m_DrawClientBorder = false;
        public bool DrawClientBorder
        {
            get
            {
                return m_DrawClientBorder;
            }
            set
            {
                m_DrawClientBorder = value;
            }
        }


        Color m_ClientBorderColor = Color.FromArgb(255, 80, 80, 80);
        public Color ClientBorderColor
        {
            get
            {
                return m_ClientBorderColor;
            }
            set
            {
                m_ClientBorderColor = value;
            }
        }


        bool m_BorderHasRoundedAngles = false;
        public bool BorderHasRoundedAngles
        {
            get
            {
                return m_BorderHasRoundedAngles;
            }
            set
            {
                m_BorderHasRoundedAngles = value;
            }
        }


        bool m_ClientBorderHasRoundedAngles = false;
        public bool ClientBorderHasRoundedAngles
        {
            get
            {
                return m_ClientBorderHasRoundedAngles;
            }
            set
            {
                m_ClientBorderHasRoundedAngles = value;
            }
        }


        /// <summary>
        /// Renders the control to a cache using specified skin.
        /// </summary>
        /// <param name="skin">Skin to use.</param>
        /// <param name="master">Root parent.</param>
        protected virtual void DoCacheRender(Skin.Base skin, Base master)
        {
            Renderer.Base render = skin.Renderer;
            Renderer.ICacheToTexture cache = render.CTT;

            if (cache == null)
                return;

            PointI oldRenderOffset = render.RenderOffset;
            RectI oldRegion = render.ClipRegion;

            if (this != master)
            {
                render.AddRenderOffset(Bounds.Location);
                render.AddClipRegion(Bounds);
            }
            else
            {
                render.RenderOffset = PointI.Empty;
                render.ClipRegion = new RectI(0, 0, Width, Height);
            }

            if (m_CacheTextureDirty && render.ClipRegionVisible)
            {
                render.StartClip();

                if (ShouldCacheToTexture)
                {
                    cache.SetupCacheTexture(this);
                }

                //Render myself first
                //var old = render.ClipRegion;
                //render.ClipRegion = Bounds;
                //var old = render.RenderOffset;
                //render.RenderOffset = new PointI(Bounds.X, Bounds.Y);
                Render(skin);
                //render.RenderOffset = old;
                //render.ClipRegion = old;

                if (m_Children.Count > 0)
                {
                    //Now render my kids
                    foreach (Base child in m_Children)
                    {
                        if (child.IsHidden)
                            continue;
                        child.DoCacheRender(skin, master);
                    }
                }

                if (ShouldCacheToTexture)
                {
                    cache.FinishCacheTexture(this);
                    m_CacheTextureDirty = false;
                }
            }

            render.ClipRegion = oldRegion;
            render.StartClip();
            render.RenderOffset = oldRenderOffset;

            if (ShouldCacheToTexture)
                cache.DrawCachedControlTexture(this);
        }


        bool m_fLoaded = false;

        public EventHandler Load;

        protected virtual void OnLoad(EventArgs e)
        {
            if (Load != null)
            {
                Load(this, EventArgs.Empty);
            }
        }


        /// <summary>
        /// Rendering logic implementation.
        /// </summary>
        /// <param name="skin">Skin to use.</param>
        internal virtual void DoRender(Skin.Base skin)
        {
            // If this control has a different skin, 
            // then so does its children.
            if (m_Skin != null)
            {
                skin = m_Skin;
            }

            // Do think
            Think();

            Renderer.Base render = skin.Renderer;

            if (!m_fLoaded)
            {
                try
                {
                    OnLoad(EventArgs.Empty);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
                m_fLoaded = true;
                
                RecurseLayout(Skin);
            }

            if (render.CTT != null && ShouldCacheToTexture)
            {
                DoCacheRender(skin, this);
                return;
            }

            RenderRecursive(skin, Bounds);

            if (DrawDebugOutlines)
            {
                skin.DrawDebugOutlines(this);
            }
        }

        /// <summary>
        /// Recursive rendering logic.
        /// </summary>
        /// <param name="skin">Skin to use.</param>
        /// <param name="clipRect">Clipping rectangle.</param>
        protected virtual void RenderRecursive(Skin.Base skin, RectI clipRect)
        {
            Renderer.Base render = skin.Renderer;
            PointI oldRenderOffset = render.RenderOffset;

            render.AddRenderOffset(clipRect.Location);

            RenderUnder(skin);

            RectI oldRegion = render.ClipRegion;

            if (ShouldClip)
            {
                render.AddClipRegion(clipRect);

                if (!render.ClipRegionVisible)
                {
                    render.RenderOffset = oldRenderOffset;
                    render.ClipRegion = oldRegion;
                    return;
                }

                render.StartClip();
            }

            //Render myself first
            Render(skin);

            if (m_Children.Count > 0)
            {
                //Now render my kids
                Base[] children_clone = m_Children.ToArray();
                foreach (Base child in children_clone)//m_Children)
                {
                    if (child.IsHidden)
                    {
                        continue;
                    }

                    child.DoRender(skin);
                }
            }

            render.ClipRegion = oldRegion;
            render.StartClip();
            RenderOver(skin);

            RenderFocus(skin);

            render.RenderOffset = oldRenderOffset;
        }

        /// <summary>
        /// Sets the control's skin.
        /// </summary>
        /// <param name="skin">New skin.</param>
        /// <param name="doChildren">Deterines whether to change children skin.</param>
        public void SetSkin(Skin.Base skin)//, bool doChildren = false)
        {
            SetSkin(skin, false);
        }

        public virtual void SetSkin(Skin.Base skin, bool doChildren)// = false)
        {
            if (m_Skin == skin)
                return;
            m_Skin = skin;
            Invalidate();
            Redraw();
            OnSkinChanged(skin);

            if (doChildren)
            {
                foreach (Base child in m_Children)
                {
                    child.SetSkin(skin, true);
                }
            }
        }

        /// <summary>
        /// Handler invoked when control's skin changes.
        /// </summary>
        /// <param name="newSkin">New skin.</param>
        protected virtual void OnSkinChanged(Skin.Base newSkin)
        {
        }


        /// <summary>
        /// Handler invoked on mouse wheel event.
        /// </summary>
        /// <param name="delta">Scroll delta.</param>
        protected virtual bool OnMouseWheeled(int delta)
        {
            if (m_ActualParent != null)
            {
                return m_ActualParent.OnMouseWheeled(delta);
            }

            return false;
        }

        protected virtual void OnMouseWheel(MouseEventArgs e)
        {
            if (MouseWheel != null)
            {
                MouseWheel(this, e);
            }
        }

        /// <summary>
        /// Invokes mouse wheeled event (used by input system).
        /// </summary>
        internal bool InputMouseWheeled(int delta)
        {
            if (IsDisabled)
            {
                return false;
            }

            OnMouseWheel(new MouseEventArgs(MouseButtons, PointToClient(MousePosition), delta));

            return OnMouseWheeled(delta);
        }


        /// <summary>
        /// Handler invoked on mouse moved event.
        /// </summary>
        /// <param name="x">X coordinate.</param>
        /// <param name="y">Y coordinate.</param>
        /// <param name="dx">X change.</param>
        /// <param name="dy">Y change.</param>
        protected virtual void OnMouseMoved(int x, int y, int dx, int dy)
        {

        }

        protected virtual void OnMouseMove(MouseEventArgs e)
        {
            if (MouseMove != null)
            {
                MouseMove(this, e);
            }
        }

        /// <summary>
        /// Invokes mouse moved event (used by input system).
        /// </summary>
        internal void InputMouseMoved(int x, int y, int dx, int dy)
        {
            if (IsDisabled)
            {
                return;
            }

            OnMouseMove(new MouseEventArgs(MouseButtons, PointToClient(MousePosition)));//x, y));

            OnMouseMoved(x, y, dx, dy);
        }



        protected virtual void OnMouseDown(MouseEventArgs e)
        {
            if (MouseDown != null)
            {
                MouseDown(this, e);
            }
        }

        protected virtual void OnMouseClick(MouseEventArgs e)
        {
            if (MouseClick != null)
            {
                MouseClick(this, e);
            }
        }

        protected virtual void OnMouseDoubleClick(MouseEventArgs e)
        {
            if (MouseDoubleClick != null)
            {
                MouseDoubleClick(this, e);
            }
        }

        protected virtual void OnMouseUp(MouseEventArgs e)
        {
            if (MouseUp != null)
            {
                MouseUp(this, e);
            }
        }


        protected virtual void OnMouseEnter(EventArgs e)
        {
            if (MouseEnter != null)
            {
                MouseEnter(this, e);
            }
        }

        protected virtual void OnMouseLeave(EventArgs e)
        {
            if (MouseLeave != null)
            {
                MouseLeave(this, e);
            }
        }



        void OnInputMouseClicked(MouseEventArgs mea, bool down)
        {
            if (down)
            {
                OnMouseDown(mea);
            }
            else
            {
                OnClick(mea);
                OnMouseClick(mea);
                OnMouseUp(mea);
            }
        }


        void OnInputMouseDoubleClicked(MouseEventArgs mea)
        {
            OnDoubleClick(mea);
            OnMouseDoubleClick(mea);
            OnMouseUp(mea);
        }


        /// <summary>
        /// Handler invoked on mouse click (left) event.
        /// </summary>
        /// <param name="x">X coordinate.</param>
        /// <param name="y">Y coordinate.</param>
        /// <param name="down">If set to <c>true</c> mouse button is down.</param>
        protected virtual void OnMouseClickedLeft(int x, int y, bool down)
        {
        }

        /// <summary>
        /// Invokes left mouse click event (used by input system).
        /// </summary>
        internal void InputMouseClickedLeft(int x, int y, bool down)
        {
            if (IsDisabled)
            {
                return;
            }

            OnInputMouseClicked(new MouseEventArgs(MouseButtons.Left, PointToClient(MousePosition)//x, y
                ), down);

            OnMouseClickedLeft(x, y, down);
        }


        /// <summary>
        /// Handler invoked on mouse click (right) event.
        /// </summary>
        /// <param name="x">X coordinate.</param>
        /// <param name="y">Y coordinate.</param>
        /// <param name="down">If set to <c>true</c> mouse button is down.</param>
        protected virtual void OnMouseClickedRight(int x, int y, bool down)
        {
        }

        /// <summary>
        /// Invokes right mouse click event (used by input system).
        /// </summary>
        internal void InputMouseClickedRight(int x, int y, bool down)
        {
            if (IsDisabled)
            {
                return;
            }

            OnInputMouseClicked(new MouseEventArgs(MouseButtons.Right, PointToClient(MousePosition)//x, y
                ), down);

            OnMouseClickedRight(x, y, down);

            if (!down &&
                m_ContextMenu != null)
            {
                m_ContextMenu.Parent = GetCanvas();
                m_ContextMenu.Open(Pos.Right | Pos.Top);
            }
        }


        /// <summary>
        /// Handler invoked on mouse click (middle) event.
        /// </summary>
        /// <param name="x">X coordinate.</param>
        /// <param name="y">Y coordinate.</param>
        /// <param name="down">If set to <c>true</c> mouse button is down.</param>
        protected virtual void OnMouseClickedMiddle(int x, int y, bool down)
        {
        }

        /// <summary>
        /// Invokes middle mouse click event (used by input system).
        /// </summary>
        internal void InputMouseClickedMiddle(int x, int y, bool down)
        {
            if (IsDisabled)
            {
                return;
            }

            OnInputMouseClicked(new MouseEventArgs(MouseButtons.Middle, PointToClient(MousePosition)//x, y
                ), down);

            OnMouseClickedMiddle(x, y, down);
        }


        /// <summary>
        /// Handler invoked on mouse double click (left) event.
        /// </summary>
        /// <param name="x">X coordinate.</param>
        /// <param name="y">Y coordinate.</param>
        protected virtual void OnMouseDoubleClickedLeft(int x, int y)
        {
            OnMouseClickedLeft(x, y, true); // [omeg] should this be called?
        }

        /// <summary>
        /// Invokes left double mouse click event (used by input system).
        /// </summary>
        internal void InputMouseDoubleClickedLeft(int x, int y)
        {
            if (IsDisabled)
            {
                return;
            }

            OnInputMouseDoubleClicked(new MouseEventArgs(MouseButtons.Left, PointToClient(MousePosition)));//x, y));

            OnMouseDoubleClickedLeft(x, y);
        }


        /// <summary>
        /// Handler invoked on mouse double click (right) event.
        /// </summary>
        /// <param name="x">X coordinate.</param>
        /// <param name="y">Y coordinate.</param>
        protected virtual void OnMouseDoubleClickedRight(int x, int y)
        {
            OnMouseClickedRight(x, y, true); // [omeg] should this be called?
        }

        /// <summary>
        /// Invokes right double mouse click event (used by input system).
        /// </summary>
        internal void InputMouseDoubleClickedRight(int x, int y)
        {
            if (IsDisabled)
            {
                return;
            }

            OnInputMouseDoubleClicked(new MouseEventArgs(MouseButtons.Right, PointToClient(MousePosition)));//x, y));

            OnMouseDoubleClickedRight(x, y);
        }


        /// <summary>
        /// Handler invoked on mouse double click (middle) event.
        /// </summary>
        /// <param name="x">X coordinate.</param>
        /// <param name="y">Y coordinate.</param>
        protected virtual void OnMouseDoubleClickedMiddle(int x, int y)
        {
            OnMouseClickedMiddle(x, y, true); // [omeg] should this be called?
        }

        /// <summary>
        /// Invokes middle double mouse click event (used by input system).
        /// </summary>
        internal void InputMouseDoubleClickedMiddle(int x, int y)
        {
            if (IsDisabled)
            {
                return;
            }

            OnInputMouseDoubleClicked(new MouseEventArgs(MouseButtons.Middle, PointToClient(MousePosition)));//x, y));

            OnMouseDoubleClickedMiddle(x, y);
        }


        /// <summary>
        /// Handler invoked on mouse cursor entering control's bounds.
        /// </summary>
        protected virtual void OnMouseEntered()
        {
            if (HoverEnter != null)
            {
                HoverEnter.Invoke(this);
            }

            if (ToolTip != null)
            {
                ToolTipHandler.Enable(this);
            }
            else if (Parent != null &&
                Parent.ToolTip != null)
            {
                ToolTipHandler.Enable(Parent);
            }

            Redraw();
        }


        /// <summary>
        /// Invokes mouse enter event (used by input system).
        /// </summary>
        internal void InputMouseEntered()
        {
            OnMouseEnter(EventArgs.Empty);

            OnMouseEntered();
        }


        /// <summary>
        /// Handler invoked on mouse cursor leaving control's bounds.
        /// </summary>
        protected virtual void OnMouseLeft()
        {
            if (HoverLeave != null)
            {
                HoverLeave.Invoke(this);
            }

            if (ToolTip != null)
            {
                ToolTipHandler.Disable(this);
            }
            else if (Parent != null &&
                Parent.ToolTip != null)
            {
                ToolTipHandler.Disable(Parent);
            }

            Redraw();
        }


        /// <summary>
        /// Invokes mouse leave event (used by input system).
        /// </summary>
        internal void InputMouseLeft()
        {
            OnMouseLeave(EventArgs.Empty);

            OnMouseLeft();
        }


        /// <summary>
        /// Focuses the control.
        /// </summary>
        public virtual void Focus()
        {
            if (IsDisabled)
            {
                return;
            }

            if (InputHandler.KeyboardFocus == this)
                return;

            if (InputHandler.KeyboardFocus != null)
                InputHandler.KeyboardFocus.OnLostKeyboardFocus();

            InputHandler.KeyboardFocus = this;
            OnKeyboardFocus();
            Redraw();
        }


        public bool Focused
        {
            get
            {
                return InputHandler.KeyboardFocus == this;
            }
        }


        /// <summary>
        /// Unfocuses the control.
        /// </summary>
        public virtual void Blur()
        {
            if (InputHandler.KeyboardFocus != this)
                return;

            InputHandler.KeyboardFocus = null;
            OnLostKeyboardFocus();
            Redraw();
        }


        /// <summary>
        /// Control has been clicked - invoked by input system. Windows use it to propagate activation.
        /// </summary>
        public virtual void Touch()
        {
            if (Parent != null)
                Parent.OnChildTouched(this);
        }

        protected virtual void OnChildTouched(Base control)
        {
            Touch();
        }


        /// <summary>
        /// Gets a child by its coordinates.
        /// </summary>
        /// <param name="x">Child X.</param>
        /// <param name="y">Child Y.</param>
        /// <returns>Control or null if not found.</returns>
        public virtual Base GetControlAt(int x, int y)
        {
            if (IsHidden)
                return null;

            if (x < 0 || y < 0 || x >= Width || y >= Height)
                return null;

            // todo: convert to linq FindLast
            //NET20 var rev = ((IList<Base>)m_Children).Reverse(); // IList.Reverse creates new list, List.Reverse works in place.. go figure
            List<Base> rev = new List<Base>();
            foreach (Base child in m_Children)
            {
                rev.Insert(0, child);
            }

            foreach (Base child in rev)
            {
                Base found = child.GetControlAt(x - child.X, y - child.Y);
                if (found != null)
                    return found;
            }

            if (!MouseInputEnabled)
            {
                return null;
            }

            return this;
        }


        /// <summary>
        /// Lays out the control's interior according to alignment, padding, dock etc.
        /// </summary>
        /// <param name="skin">Skin to use.</param>
        protected virtual void Layout(Skin.Base skin)
        {
            if (skin.Renderer.CTT != null &&
                ShouldCacheToTexture)
            {
                skin.Renderer.CTT.CreateControlCacheTexture(this);
            }
        }


        internal void ToolTipLayout(Skin.Base skin)
        {
            bool oldHidden = m_Hidden;
            m_Hidden = false;

            RecurseLayout(skin);

            m_Hidden = oldHidden;
        }


        /// <summary>
        /// Recursively lays out the control's interior according to alignment, margin, padding, dock etc.
        /// </summary>
        /// <param name="skin">Skin to use.</param>
        protected virtual void RecurseLayout(Skin.Base skin)
        {
            if (m_Skin != null)
                skin = m_Skin;
            if (IsHidden)
                return;

            if (m_NeedsLayout)
            {
                m_NeedsLayout = false;
                Layout(skin);
            }

            RectI bounds = RenderBounds;

            // Adjust bounds for padding
            bounds.X += m_Padding.Left;
            bounds.Width -= m_Padding.Left + m_Padding.Right;
            bounds.Y += m_Padding.Top;
            bounds.Height -= m_Padding.Top + m_Padding.Bottom;

            foreach (Base child in m_Children)
            {
                if (child.IsHidden)
                    continue;

                Pos dock = child.Dock;

                if (0 != (dock & Pos.Fill))
                    continue;

                if (0 != (dock & Pos.Top))
                {
                    Margin margin = child.Margin;

                    child.SetBounds(bounds.X + margin.Left, bounds.Y + margin.Top,
                                    bounds.Width - margin.Left - margin.Right, child.Height);

                    int height = margin.Top + margin.Bottom + child.Height;
                    bounds.Y += height;
                    bounds.Height -= height;
                }

                if (0 != (dock & Pos.Left))
                {
                    Margin margin = child.Margin;

                    child.SetBounds(bounds.X + margin.Left, bounds.Y + margin.Top, child.Width,
                                      bounds.Height - margin.Top - margin.Bottom);

                    int width = margin.Left + margin.Right + child.Width;
                    bounds.X += width;
                    bounds.Width -= width;
                }

                if (0 != (dock & Pos.Right))
                {
                    // TODO: THIS MARGIN CODE MIGHT NOT BE FULLY FUNCTIONAL
                    Margin margin = child.Margin;

                    child.SetBounds((bounds.X + bounds.Width) - child.Width - margin.Right, bounds.Y + margin.Top,
                                      child.Width, bounds.Height - margin.Top - margin.Bottom);

                    int width = margin.Left + margin.Right + child.Width;
                    bounds.Width -= width;
                }

                if (0 != (dock & Pos.Bottom))
                {
                    // TODO: THIS MARGIN CODE MIGHT NOT BE FULLY FUNCTIONAL
                    Margin margin = child.Margin;

                    child.SetBounds(bounds.X + margin.Left,
                                      (bounds.Y + bounds.Height) - child.Height - margin.Bottom,
                                      bounds.Width - margin.Left - margin.Right, child.Height);
                    bounds.Height -= child.Height + margin.Bottom + margin.Top;
                }

                child.RecurseLayout(skin);
            }

            m_InnerBounds = bounds;

            //
            // Fill uses the left over space, so do that now.
            //
            foreach (Base child in m_Children)
            {
                Pos dock = child.Dock;

                if (!(0 != (dock & Pos.Fill)))
                    continue;

                Margin margin = child.Margin;

                child.SetBounds(bounds.X + margin.Left, bounds.Y + margin.Top,
                                  bounds.Width - margin.Left - margin.Right, bounds.Height - margin.Top - margin.Bottom);
                child.RecurseLayout(skin);
            }

            PostLayout(skin);
            if (m_LastBounds != Bounds)
            {
                m_LastBounds = Bounds;
                OnResize(EventArgs.Empty);
            }

            if (IsTabable)
            {
                if (GetCanvas().FirstTab == null)
                    GetCanvas().FirstTab = this;
                if (GetCanvas().NextTab == null)
                    GetCanvas().NextTab = this;
            }

            if (InputHandler.KeyboardFocus == this)
            {
                GetCanvas().NextTab = null;
            }
        }

        /// <summary>
        /// Checks if the given control is a child of this instance.
        /// </summary>
        /// <param name="child">Control to examine.</param>
        /// <returns>True if the control is out child.</returns>
        public bool IsChild(Base child)
        {
            return m_Children.Contains(child);
        }

        /// <summary>
        /// Converts local coordinates to canvas coordinates.
        /// </summary>
        /// <param name="pnt">Local coordinates.</param>
        /// <returns>Canvas coordinates.</returns>
        public virtual PointI LocalPosToCanvas(PointI pnt)
        {
            if (m_Parent != null)
            {
                int x = pnt.X + X;
                int y = pnt.Y + Y;

                // If our parent has an innerpanel and we're a child of it
                // add its offset onto us.
                //
                if (m_Parent.m_InnerPanel != null && m_Parent.m_InnerPanel.IsChild(this))
                {
                    x += m_Parent.m_InnerPanel.X;
                    y += m_Parent.m_InnerPanel.Y;
                }

                return m_Parent.LocalPosToCanvas(new PointI(x, y));
            }

            return pnt;
        }


        /// <summary>
        /// Converts canvas coordinates to local coordinates.
        /// </summary>
        /// <param name="pnt">Canvas coordinates.</param>
        /// <returns>Local coordinates.</returns>
        public virtual PointI CanvasPosToLocal(PointI pnt)
        {
            if (m_Parent != null)
            {
                int x = pnt.X - X;
                int y = pnt.Y - Y;

                // If our parent has an innerpanel and we're a child of it
                // add its offset onto us.
                //
                if (m_Parent.m_InnerPanel != null && m_Parent.m_InnerPanel.IsChild(this))
                {
                    x -= m_Parent.m_InnerPanel.X;
                    y -= m_Parent.m_InnerPanel.Y;
                }


                return m_Parent.CanvasPosToLocal(new PointI(x, y));
            }

            return pnt;
        }


        /// <summary>
        /// Closes all menus recursively.
        /// </summary>
        public virtual void CloseMenus()
        {
            //Debug.Print("Base.CloseMenus: {0}", this);

            // todo: not very efficient with the copying and recursive closing, maybe store currently open menus somewhere (canvas)?
#if !SILVERLIGHT
            List<Base> childrenCopy = m_Children.FindAll(x => true);
#else
            Base[] childrenCopy = m_Children.ToArray();
#endif
            foreach (Base child in childrenCopy)
            {
                child.CloseMenus();
            }
        }


        /// <summary>
        /// Copies Bounds to RenderBounds.
        /// </summary>
        protected virtual void UpdateRenderBounds()
        {
            m_RenderBounds.X = 0;
            m_RenderBounds.Y = 0;

            m_RenderBounds.Width = m_Bounds.Width;
            m_RenderBounds.Height = m_Bounds.Height;
        }


        /// <summary>
        /// Sets mouse cursor to current cursor.
        /// </summary>
        public virtual void UpdateCursor()
        {
            //Platform.Neutral.SetCursor(m_Cursor);
            GetCanvas().SetCursor(m_Cursor);
        }

        // giver
        public virtual Package DragAndDrop_GetPackage(int x, int y)
        {
            return m_DragAndDrop_Package;
        }

        // giver
        public virtual bool DragAndDrop_Draggable()
        {
            if (m_DragAndDrop_Package == null)
                return false;

            return m_DragAndDrop_Package.IsDraggable;
        }

        // giver
        public void DragAndDrop_SetPackage(bool draggable)//, String name = "", object userData = null)
        {
            DragAndDrop_SetPackage(draggable, "", null);
        }

        public void DragAndDrop_SetPackage(bool draggable, String name)// = "", object userData = null)
        {
            DragAndDrop_SetPackage(draggable, name, null);
        }

        public virtual void DragAndDrop_SetPackage(bool draggable, String name// = ""
            , object userData)// = null)
        {
            if (m_DragAndDrop_Package == null)
            {
                m_DragAndDrop_Package = new Package();
                m_DragAndDrop_Package.IsDraggable = draggable;
                m_DragAndDrop_Package.Name = name;
                m_DragAndDrop_Package.UserData = userData;
            }
        }

        // giver
        public virtual bool DragAndDrop_ShouldStartDrag()
        {
            return true;
        }

        // giver
        public virtual void DragAndDrop_StartDragging(Package package, int x, int y)
        {
            package.HoldOffset = CanvasPosToLocal(new PointI(x, y));
            package.DrawControl = this;
        }

        // giver
        public virtual void DragAndDrop_EndDragging(bool success, int x, int y)
        {
        }

        // receiver
        public virtual bool DragAndDrop_HandleDrop(Package p, int x, int y)
        {
            DragAndDrop.SourceControl.Parent = this;
            return true;
        }

        // receiver
        public virtual void DragAndDrop_HoverEnter(Package p, int x, int y)
        {

        }

        // receiver
        public virtual void DragAndDrop_HoverLeave(Package p)
        {

        }

        // receiver
        public virtual void DragAndDrop_Hover(Package p, int x, int y)
        {

        }

        // receiver
        public virtual bool DragAndDrop_CanAcceptPackage(Package p)
        {
            return false;
        }

        /// <summary>
        /// Resizes the control to fit its children.
        /// </summary>
        /// <param name="width">Determines whether to change control's width.</param>
        /// <param name="height">Determines whether to change control's height.</param>
        /// <returns>True if bounds changed.</returns>
        public bool SizeToChildren()//bool width = true, bool height = true)
        {
            return SizeToChildren(true, true);
        }

        public bool SizeToChildren(bool width)// = true, bool height = true)
        {
            return SizeToChildren(width, true);
        }

        public virtual bool SizeToChildren(bool width// = true
            , bool height)// = true)
        {
            SizeI size = GetChildrenSize();
            size.Width += Padding.Right;
            size.Height += Padding.Bottom;
            return SetSize(width ? size.Width : Width, height ? size.Height : Height);
        }

        /// <summary>
        /// Returns the total width and height of all children.
        /// </summary>
        /// <remarks>Default implementation returns maximum size of children since the layout is unknown.
        /// Implement this in derived compound controls to properly return their size.</remarks>
        /// <returns></returns>
        public virtual SizeI GetChildrenSize()
        {
            SizeI size = SizeI.Empty;

            foreach (Base child in m_Children)
            {
                if (child.IsHidden)
                    continue;

                size.Width = Math.Max(size.Width, child.Right);
                size.Height = Math.Max(size.Height, child.Bottom);
            }

            return size;
        }

        /// <summary>
        /// Handles keyboard accelerator.
        /// </summary>
        /// <param name="accelerator">Accelerator text.</param>
        /// <returns>True if handled.</returns>
        internal virtual bool HandleAccelerator(String accelerator)
        {
            if (InputHandler.KeyboardFocus == this || !AccelOnlyFocus)
            {
                if (m_Accelerators.ContainsKey(accelerator))
                {
                    m_Accelerators[accelerator].Invoke(this);
                    return true;
                }
            }

            //NET20 return m_Children.Any(child => child.HandleAccelerator(accelerator));
            foreach (Base child in m_Children)
            {
                if (child.HandleAccelerator(accelerator))
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Adds keyboard accelerator.
        /// </summary>
        /// <param name="accelerator">Accelerator text.</param>
        /// <param name="handler">Handler.</param>
        public void AddAccelerator(String accelerator, GwenEventHandler handler)
        {
            accelerator = accelerator.Trim().
#if !SILVERLIGHT3
                ToUpperInvariant();
#else
                ToUpper(System.Globalization.CultureInfo.InvariantCulture);
#endif

            m_Accelerators[accelerator] = handler;
        }

        /// <summary>
        /// Adds keyboard accelerator with a default handler.
        /// </summary>
        /// <param name="accelerator">Accelerator text.</param>
        public void AddAccelerator(String accelerator)
        {
            m_Accelerators[accelerator] = DefaultAcceleratorHandler;
        }


        /// <summary>
        /// Function invoked after layout.
        /// </summary>
        /// <param name="skin">Skin to use.</param>
        protected virtual void PostLayout(Skin.Base skin)
        {
        }

        EventHandler m_Resize;
        public event EventHandler Resize
        {
            add
            {
                m_Resize += value;
            }
            remove
            {
                m_Resize -= value;
            }
        }

        void RaiseResize(EventArgs e)
        {
            if (m_Resize != null)
            {
                m_Resize(this, e);
            }
        }

        RectI m_LastBounds = RectI.Empty;
        protected virtual void OnResize(EventArgs e)
        {
            RaiseResize(e);
        }


        /// <summary>
        /// Re-renders the control, invalidates cached texture.
        /// </summary>
        public virtual void Redraw()
        {
            UpdateColors();
            m_CacheTextureDirty = true;
            if (m_Parent != null)
                m_Parent.Redraw();
        }


        /// <summary>
        /// Updates control colors.
        /// </summary>
        /// <remarks>
        /// Used in composite controls like lists to differentiate row colors etc.
        /// </remarks>
        public virtual void UpdateColors()
        {
        }


        /// <summary>
        /// Invalidates control's parent.
        /// </summary>
        public void InvalidateParent()
        {
            if (m_Parent != null)
            {
                m_Parent.Invalidate();
            }
        }



        protected virtual bool IsInputKey(Keys keyData)
        {
            return false;
        }


        protected virtual void OnPreviewKeyDown(PreviewKeyDownEventArgs e)
        {
            if (PreviewKeyDown != null)
            {
                PreviewKeyDown(this, e);
            }
        }

        protected virtual void OnKeyDown(KeyEventArgs e)
        {
            if (KeyDown != null)
            {
                KeyDown(this, e);
            }
        }

        protected virtual void OnKeyUp(KeyEventArgs e)
        {
            if (KeyUp != null)
            {
                KeyUp(this, e);
            }
        }

        protected virtual void OnKeyPress(KeyPressEventArgs e)
        {
            if (KeyPress != null)
            {
                KeyPress(this, e);
            }
        }



        /// <summary>
        /// Handler for keyboard events.
        /// </summary>
        /// <param name="key">Key pressed.</param>
        /// <param name="down">Indicates whether the key was pressed or released.</param>
        /// <returns>True if handled.</returns>
        protected bool OnKeyPressed(Keys key)//, bool down = true)
        {
            return OnKeyPressed(key, true);
        }

        protected virtual bool OnKeyPressed(Keys key, bool down)// = true)
        {
            bool handled = false;
            switch (key)
            {
                case Keys.Tab: handled = OnKeyTab(down); break;
                case Keys.Space: handled = OnKeySpace(down); break;
                case Keys.Home: handled = OnKeyHome(down); break;
                case Keys.End: handled = OnKeyEnd(down); break;
                case Keys.Return: handled = OnKeyReturn(down); break;
                case Keys.Backspace: handled = OnKeyBackspace(down); break;
                case Keys.Delete: handled = OnKeyDelete(down); break;
                case Keys.Right: handled = OnKeyRight(down); break;
                case Keys.Left: handled = OnKeyLeft(down); break;
                case Keys.Up: handled = OnKeyUp(down); break;
                case Keys.Down: handled = OnKeyDown(down); break;
                case Keys.Escape: handled = OnKeyEscape(down); break;
                default: break;
            }

            if (!handled && Parent != null)
                Parent.OnKeyPressed(key, down);

            return handled;
        }

        /// <summary>
        /// Invokes key press event (used by input system).
        /// </summary>
        internal bool InputKeyPressed(Keys key)//, bool down = true)
        {
            return InputKeyPressed(key, true);
        }

        internal bool InputKeyPressed(Keys key, bool down)// = true)
        {
            if (IsDisabled)
            {
                return false;
            }

            if (down)
            {
                OnPreviewKeyDown(new PreviewKeyDownEventArgs(key | ModifierKeys));
                OnKeyDown(new KeyEventArgs(key));
            }
            else
            {
                OnKeyUp(new KeyEventArgs(key));
            }

            return OnKeyPressed(key, down);
        }

        /// <summary>
        /// Handler for keyboard events.
        /// </summary>
        /// <param name="key">Key pressed.</param>
        /// <returns>True if handled.</returns>
        protected virtual bool OnKeyReleaseed(Keys key)
        {
            return OnKeyPressed(key, false);
        }

        /// <summary>
        /// Handler for Tab keyboard event.
        /// </summary>
        /// <param name="down">Indicates whether the key was pressed or released.</param>
        /// <returns>True if handled.</returns>
        protected virtual bool OnKeyTab(bool down)
        {
            if (!down)
                return true;

            if (GetCanvas().NextTab != null)
            {
                GetCanvas().NextTab.Focus();
                Redraw();
            }

            return true;
        }


        /// <summary>
        /// Handler for Space keyboard event.
        /// </summary>
        /// <param name="down">Indicates whether the key was pressed or released.</param>
        /// <returns>True if handled.</returns>
        protected virtual bool OnKeySpace(bool down)
        {
            return false;
        }


        /// <summary>
        /// Handler for Return keyboard event.
        /// </summary>
        /// <param name="down">Indicates whether the key was pressed or released.</param>
        /// <returns>True if handled.</returns>
        protected virtual bool OnKeyReturn(bool down) { return false; }

        /// <summary>
        /// Handler for Backspace keyboard event.
        /// </summary>
        /// <param name="down">Indicates whether the key was pressed or released.</param>
        /// <returns>True if handled.</returns>
        protected virtual bool OnKeyBackspace(bool down) { return false; }

        /// <summary>
        /// Handler for Delete keyboard event.
        /// </summary>
        /// <param name="down">Indicates whether the key was pressed or released.</param>
        /// <returns>True if handled.</returns>
        protected virtual bool OnKeyDelete(bool down) { return false; }

        /// <summary>
        /// Handler for Right Arrow keyboard event.
        /// </summary>
        /// <param name="down">Indicates whether the key was pressed or released.</param>
        /// <returns>True if handled.</returns>
        protected virtual bool OnKeyRight(bool down) { return false; }

        /// <summary>
        /// Handler for Left Arrow keyboard event.
        /// </summary>
        /// <param name="down">Indicates whether the key was pressed or released.</param>
        /// <returns>True if handled.</returns>
        protected virtual bool OnKeyLeft(bool down) { return false; }

        /// <summary>
        /// Handler for Home keyboard event.
        /// </summary>
        /// <param name="down">Indicates whether the key was pressed or released.</param>
        /// <returns>True if handled.</returns>
        protected virtual bool OnKeyHome(bool down) { return false; }

        /// <summary>
        /// Handler for End keyboard event.
        /// </summary>
        /// <param name="down">Indicates whether the key was pressed or released.</param>
        /// <returns>True if handled.</returns>
        protected virtual bool OnKeyEnd(bool down) { return false; }

        /// <summary>
        /// Handler for Up Arrow keyboard event.
        /// </summary>
        /// <param name="down">Indicates whether the key was pressed or released.</param>
        /// <returns>True if handled.</returns>
        protected virtual bool OnKeyUp(bool down) { return false; }

        /// <summary>
        /// Handler for Down Arrow keyboard event.
        /// </summary>
        /// <param name="down">Indicates whether the key was pressed or released.</param>
        /// <returns>True if handled.</returns>
        protected virtual bool OnKeyDown(bool down) { return false; }

        /// <summary>
        /// Handler for Escape keyboard event.
        /// </summary>
        /// <param name="down">Indicates whether the key was pressed or released.</param>
        /// <returns>True if handled.</returns>
        protected virtual bool OnKeyEscape(bool down) { return false; }

        /// <summary>
        /// Handler for Paste event.
        /// </summary>
        /// <param name="from">Source control.</param>
        protected virtual void OnPaste(Base from)
        {
        }

        /// <summary>
        /// Handler for Copy event.
        /// </summary>
        /// <param name="from">Source control.</param>
        protected virtual void OnCopy(Base from)
        {
        }

        /// <summary>
        /// Handler for Cut event.
        /// </summary>
        /// <param name="from">Source control.</param>
        protected virtual void OnCut(Base from)
        {
        }

        /// <summary>
        /// Handler for Select All event.
        /// </summary>
        /// <param name="from">Source control.</param>
        protected virtual void OnSelectAll(Base from)
        {
        }

        internal void InputCopy(Base from)
        {
            OnCopy(from);
        }

        internal void InputPaste(Base from)
        {
            OnPaste(from);
        }

        internal void InputCut(Base from)
        {
            OnCut(from);
        }

        internal void InputSelectAll(Base from)
        {
            OnSelectAll(from);
        }

        /// <summary>
        /// Renders the focus overlay.
        /// </summary>
        /// <param name="skin">Skin to use.</param>
        protected virtual void RenderFocus(Skin.Base skin)
        {
            if (InputHandler.KeyboardFocus != this)
                return;
            if (!IsTabable)
                return;

            skin.DrawKeyboardHighlight(this, RenderBounds, 3);
        }

        /// <summary>
        /// Renders under the actual control (shadows etc).
        /// </summary>
        /// <param name="skin">Skin to use.</param>
        protected virtual void RenderUnder(Skin.Base skin)
        {

        }

        /// <summary>
        /// Renders over the actual control (overlays).
        /// </summary>
        /// <param name="skin">Skin to use.</param>
        protected virtual void RenderOver(Skin.Base skin)
        {

        }

        /// <summary>
        /// Called during rendering.
        /// </summary>
        public virtual void Think()
        {

        }

        /// <summary>
        /// Handler for gaining keyboard focus.
        /// </summary>
        protected virtual void OnKeyboardFocus()
        {

        }

        /// <summary>
        /// Handler for losing keyboard focus.
        /// </summary>
        protected virtual void OnLostKeyboardFocus()
        {

        }

        /// <summary>
        /// Handler for character input event.
        /// </summary>
        /// <param name="chr">Character typed.</param>
        /// <returns>True if handled.</returns>
        protected virtual bool OnChar(Char chr)
        {
            return false;
        }

        internal bool InputChar(Char chr)
        {
            if (IsDisabled)
            {
                return false;
            }

            OnKeyPress(new KeyPressEventArgs(chr));

            return OnChar(chr);
        }


        public void Anim_WidthIn(float length)//, float delay = 0.0f, float ease = 1.0f)
        {
            Anim_WidthIn(length, 0.0f, 1.0f);
        }

        public void Anim_WidthIn(float length, float delay)// = 0.0f, float ease = 1.0f)
        {
            Anim_WidthIn(length, delay, 1.0f);
        }

        public virtual void Anim_WidthIn(float length, float delay// = 0.0f
            , float ease)// = 1.0f)
        {
            Animation.Add(this, new Anim.Size.Width(0, Width, length, false, delay, ease));
            Width = 0;
        }


        public virtual void Anim_HeightIn(float length, float delay, float ease)
        {
            Animation.Add(this, new Anim.Size.Height(0, Height, length, false, delay, ease));
            Height = 0;
        }

        public virtual void Anim_WidthOut(float length, bool hide, float delay, float ease)
        {
            Animation.Add(this, new Anim.Size.Width(Width, 0, length, hide, delay, ease));
        }

        public virtual void Anim_HeightOut(float length, bool hide, float delay, float ease)
        {
            Animation.Add(this, new Anim.Size.Height(Height, 0, length, hide, delay, ease));
        }



        public virtual void Refresh()
        {
            Invalidate();//or Redraw();
        }


        internal virtual void OnPopupAsToolTip(object sender, Alt.ComponentModel.CancelEventArgs e)
        {
        }
    }
}
