﻿//  Original source code has been modified by AltSoftLab Inc. 2012-2015
//  This source code is provided "as is" without express or implied warranty of any kind.

using System;

namespace Alt.GUI.Temporary.Gwen
{
    /// <summary>
    /// Represents inner spacing.
    /// </summary>
    public struct Padding : IEquatable<Padding>
    {
        public readonly int Top;
        public readonly int Bottom;
        public readonly int Left;
        public readonly int Right;

        // common values
        public static readonly Padding Zero = new Padding(0, 0, 0, 0);
        public static readonly Padding One = new Padding(1, 1, 1, 1);
        public static readonly Padding Two = new Padding(2, 2, 2, 2);
        public static readonly Padding Three = new Padding(3, 3, 3, 3);
        public static readonly Padding Four = new Padding(4, 4, 4, 4);
        public static readonly Padding Five = new Padding(5, 5, 5, 5);


        public Padding(int offset) :
            this(offset, offset, offset, offset)
        {
        }

        public Padding(int left, int top, int right, int bottom)
        {
            Top = top;
            Bottom = bottom;
            Left = left;
            Right = right;
        }

        public bool Equals(Padding other)
        {
            return other.Top == Top && other.Bottom == Bottom && other.Left == Left && other.Right == Right;
        }

        public static bool operator ==(Padding lhs, Padding rhs)
        {
            return lhs.Equals(rhs);
        }

        public static bool operator !=(Padding lhs, Padding rhs)
        {
            return !lhs.Equals(rhs);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (obj.GetType() != typeof(Padding)) return false;
            return Equals((Padding)obj);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                int result = Top;
                result = (result * 397) ^ Bottom;
                result = (result * 397) ^ Left;
                result = (result * 397) ^ Right;
                return result;
            }
        }


        public int Width
        {
            get
            {
                return Left + Right;
            }
        }


        public int Height
        {
            get
            {
                return Top + Bottom;
            }
        }


        public int Horizontal
        {
            get
            {
                return Left + Right;
            }
        }


        public int Vertical
        {
            get
            {
                return Top + Bottom;
            }
        }
    }
}
