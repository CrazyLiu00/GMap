﻿//  Original source code has been modified by AltSoftLab Inc. 2012-2015
//  This source code is provided "as is" without express or implied warranty of any kind.

using System;


namespace Alt.GUI.Temporary.Gwen.Control
{
    /// <summary>
    /// Group box (container).
    /// </summary>
    /// <remarks>Don't use autosize with docking.</remarks>
    public class GroupBox : Label
    {
        bool m_DrawFrame = true;
        public bool DrawFrame
        {
            get
            {
                return m_DrawFrame;
            }
            set
            {
                m_DrawFrame = value;
            }
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="GroupBox"/> class.
        /// </summary>
        /// <param name="parent">Parent control.</param>
        public GroupBox(Base parent)
            : base(parent)
        {
            // Set to true, because it's likely that our  
            // children will want mouse input, and they
            // can't get it without us..
            MouseInputEnabled = true;
            KeyboardInputEnabled = true;

            TextPadding = new Padding(10, 0, 10, 0);
            Alignment = Pos.Top | Pos.Left;
            Invalidate();

            m_InnerPanel = new Base(this);
            m_InnerPanel.Dock = Pos.Fill;
            m_InnerPanel.Margin = new Margin(5, TextHeight + 5, 5, 5);
            //Margin = new Margin(5, 5, 5, 5);
        }


        /// <summary>
        /// Lays out the control's interior according to alignment, padding, dock etc.
        /// </summary>
        /// <param name="skin">Skin to use.</param>
        protected override void Layout(Skin.Base skin)
        {
            base.Layout(skin);
            if (AutoSizeToContents)
            {
                DoSizeToContents();
            }
        }


        /// <summary>
        /// Renders the control using specified skin.
        /// </summary>
        /// <param name="skin">Skin to use.</param>
        protected override void Render(Skin.Base skin)
        {
            if (DrawFrame)
            {
                skin.DrawGroupBox(this, TextX, TextHeight, TextWidth);
            }
            else
            {
                base.Render(skin);
            }
        }


        /// <summary>
        /// Sizes to contents.
        /// </summary>
        public override void SizeToContents()
        {
            // we inherit from Label and shouldn't use its method.
            DoSizeToContents();
        }


        protected virtual void DoSizeToContents()
        {
            m_InnerPanel.SizeToChildren();
            SizeToChildren();
            if (Width < TextWidth + TextPadding.Right + TextPadding.Left)
                Width = TextWidth + TextPadding.Right + TextPadding.Left;
        }
    }
}
