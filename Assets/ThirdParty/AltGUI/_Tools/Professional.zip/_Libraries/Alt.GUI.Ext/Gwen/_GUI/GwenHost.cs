﻿//  Copyright (C) 2012-2015 AltSoftLab Inc.
//  This source code is provided "as is" without express or implied warranty of any kind.

using System;

using Alt.GUI;
using Alt.Sketch;


namespace Alt.GUI.Temporary.Gwen
{
    public class GwenHost : UserControl
    {
        Control.Base m_Child;
        public Control.Base Child
        {
            get
            {
                return m_Child;
            }
            set
            {
                if (m_Child == value)
                {
                    return;
                }

                if (m_Child != null)
                {
                    m_Canvas.RemoveChild(m_Child, false);
                }

                m_Child = value;

                if (m_Child != null)
                {
                    //m_Child.Dock = Pos.Fill;

                    if (!m_Canvas.IsChild(m_Child))
                    {
                        m_Canvas.AddChild(m_Child);
                    }
                }
            }
        }


        Alt.GUI.Temporary.Gwen.Control.Canvas m_Canvas;
        public Alt.GUI.Temporary.Gwen.Control.Canvas Canvas
        {
            get
            {
                return m_Canvas;
            }
        }


        Alt.GUI.Temporary.Gwen.Renderer.AltSketchRenderer m_Renderer;
        Alt.GUI.Temporary.Gwen.Skin.Base m_Skin;


        Timer m_InvalidateTimer;


        public GwenHost()
        {
            this.BackColor = Color.Transparent;

            m_Renderer = new Alt.GUI.Temporary.Gwen.Renderer.AltSketchRenderer(false);
            m_Skin = new Alt.GUI.Temporary.Gwen.Skin.Simple(m_Renderer);

            m_Canvas = new Alt.GUI.Temporary.Gwen.Control.Canvas(m_Skin);
            m_Canvas.BackgroundColor = Color.Transparent;
            m_Canvas.ClientBackColor = Color.Transparent;
            m_Canvas.PostDrawBackground += new PaintEventHandler(Canvas_PostDrawBackground);
            m_Canvas.ShouldDrawBackground = false;

            m_InvalidateTimer = new Timer(15);
            m_InvalidateTimer.Tick += InvalidateTimer_Tick;
            m_InvalidateTimer.Start();
        }

        void InvalidateTimer_Tick(object sender, EventArgs e)
        {
            Invalidate();
        }


        protected override void Dispose(bool disposing)
        {
            if (!this.IsDisposed)
            {
                //???   Shutdown();

                m_InvalidateTimer.Stop();

                if (m_Canvas != null)
                {
                    m_Canvas.Dispose();
                    m_Canvas = null;

                    m_Skin.Dispose();
                    m_Renderer.Dispose();
                }

                if (disposing)
                {
                }
            }

            base.Dispose(disposing);
        }


        protected virtual void OnCanvasPostDrawBackground(PaintEventArgs paint_event)
        {
        }
        void Canvas_PostDrawBackground(object sender, PaintEventArgs paint_event)
        {
            OnCanvasPostDrawBackground(paint_event);
        }


        protected override void OnPaintBackground(Alt.GUI.PaintEventArgs e)
        {
            base.OnPaintBackground(e);


            if (Size == Size.Empty)
            {
                return;
            }

            if (e.Graphics is SoftwareGraphics)
            {
                //  Canvas can draw background with optimizations in software render mode
                m_Canvas.ShouldDrawBackground = true;
                return;
            }

            e.Graphics.FillRectangle(m_Canvas.Background, new Rect(Point.Zero, Size));
            if (m_Canvas.Background2 != null)
            {
                e.Graphics.FillRectangle(m_Canvas.Background2, new Rect(Point.Zero, Size));//, Color.FromArgb(192, Color.White));
            }
        }

        
        protected override void OnPaint(Alt.GUI.PaintEventArgs e)
        {
            Graphics graphics = e.Graphics;

            if (Size != Size.Empty)
            {
                //  if (canvas.NeedsRedraw)
                {
                    try
                    {
                        SmoothingMode oldSmoothingMode = graphics.SmoothingMode;
                        graphics.SmoothingMode = SmoothingMode.None;

                        m_Canvas.RenderCanvas(graphics);

                        graphics.SmoothingMode = oldSmoothingMode;
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.ToString());
                    }
                }
                m_Canvas.ShouldDrawBackground = false;
            }


            //base.OnPaint(e);
        }


        protected override void OnKeyDown(Alt.GUI.KeyEventArgs e)
        {
            base.OnKeyDown(e);

            if (m_Canvas != null)
            {
                m_Canvas.Inject_KeyDown(e);
            }
        }

        protected override void OnKeyUp(Alt.GUI.KeyEventArgs e)
        {
            base.OnKeyUp(e);

            if (m_Canvas != null)
            {
                m_Canvas.Inject_KeyUp(e);
            }
        }

        protected override void OnKeyPress(Alt.GUI.KeyPressEventArgs e)
        {
            base.OnKeyPress(e);

            if (m_Canvas != null)
            {
                m_Canvas.Inject_KeyPress(e);
            }
        }


        protected override void OnMouseDown(Alt.GUI.MouseEventArgs e)
        {
            base.OnMouseDown(e);

            if (m_Canvas != null)
            {
                m_Canvas.Inject_MouseDown(e);
            }
        }

        protected override void OnMouseUp(Alt.GUI.MouseEventArgs e)
        {
            base.OnMouseUp(e);

            if (m_Canvas != null)
            {
                m_Canvas.Inject_MouseUp(e);
            }
        }

        protected override void OnMouseMove(Alt.GUI.MouseEventArgs e)
        {
            base.OnMouseMove(e);

            if (m_Canvas != null)
            {
                m_Canvas.Inject_MouseMove(e);
            }
        }

        protected override void OnMouseWheel(Alt.GUI.MouseEventArgs e)
        {
            base.OnMouseWheel(e);

            if (m_Canvas != null)
            {
                m_Canvas.Inject_MouseWheel(e);
            }
        }


        protected override void OnResize(Alt.GUI.ResizeEventArgs e)
        {
            base.OnResize(e);

            if (m_Canvas != null)
            {
                m_Canvas.SetSize((int)e.ClientWidth, (int)e.ClientHeight);
            }
        }
    }
}
