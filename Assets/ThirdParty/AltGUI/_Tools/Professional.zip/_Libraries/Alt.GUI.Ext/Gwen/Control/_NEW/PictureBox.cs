//  Copyright (C) 2012-2015 AltSoftLab Inc.
//  This source code is provided "as is" without express or implied warranty of any kind.

using System;
using System.Net;
using System.Runtime.InteropServices;

using Alt.ComponentModel;
using Alt.GUI;
using Alt.Sketch;


namespace Alt.GUI.Temporary.Gwen.Control
{
    public class PictureBox : Label
    {
        Bitmap image;
        PictureBoxSizeMode size_mode = PictureBoxSizeMode.Normal;
        Bitmap error_image;
        Bitmap initial_image;

#if USE_WebClient
#if !SILVERLIGHT
        string image_location = null;
        bool wait_on_load = false;
        WebClient image_download;
#endif
#endif

        bool image_from_url;
        EventHandler frame_handler;


        public PictureBox(Base parent) :
            base(parent)
        {
            MouseInputEnabled = true;
            KeyboardInputEnabled = true;
        }


        public PictureBoxSizeMode SizeMode
        {
            get
            {
                return size_mode;
            }
            set
            {
                if (size_mode == value)
                {
                    return;
                }
                size_mode = value;

                UpdateSize();

                OnSizeModeChanged(EventArgs.Empty);
            }
        }


        public Bitmap Image
        {
            get
            {
                return image;
            }
            set
            {
                ChangeImage(value, false);
            }
        }


        public Bitmap ErrorImage
        {
            get
            {
                return error_image;
            }
            set
            {
                error_image = value;
            }
        }


        public Bitmap InitialImage
        {
            get
            {
                return initial_image;
            }
            set
            {
                initial_image = value;
            }
        }


#if USE_WebClient
#if !SILVERLIGHT
        public string ImageLocation
        {
            get
            {
                return image_location;
            }
            set
            {
                image_location = value;

                if (!string.IsNullOrEmpty(value))
                {
                    if (WaitOnLoad)
                    {
                        Load(value);
                    }
                    else
                    {
                        LoadAsync(value);
                    }
                }
                else if (image_from_url)
                {
                    ChangeImage(null, true);
                }
            }
        }


        public bool WaitOnLoad
        {
            get
            {
                return wait_on_load;
            }
            set
            {
                wait_on_load = value;
            }
        }
#endif
#endif


        public override void Dispose()
        {
            if (image != null)
            {
                StopAnimation();
                image = null;
            }
            initial_image = null;

            base.Dispose();
        }


        protected override void OnPaint(PaintEventArgs pe)
        {
            //Theme.Current.DrawPictureBox(pe.Graphics, pe.ClipRectangle, this);
            Graphics dc = pe.Graphics;
            if (dc == null)
            {
                return;
            }

            RectI client = ClientRectangle;

            client = new RectI(client.Left + Padding.Left, client.Top + Padding.Top, client.Width - Padding.Horizontal, client.Height - Padding.Vertical);

            // FIXME - instead of drawing the whole picturebox every time
            // intersect the clip rectangle with the drawn picture and only draw what's needed,
            // Also, we only need a background fill where no image goes
            if (Image != null)
            {
                switch (this.SizeMode)
                {
                    case PictureBoxSizeMode.StretchImage:
                        dc.DrawImage(Image, client.Left, client.Top, client.Width, client.Height);
                        break;

                    case PictureBoxSizeMode.CenterImage:
                        dc.DrawImage(Image, (client.Width / 2) - (Image.PixelWidth / 2), (client.Height / 2) - (Image.PixelHeight / 2));
                        break;

                    case PictureBoxSizeMode.Zoom:
                        SizeI image_size;

                        if (((float)Image.PixelWidth / (float)Image.PixelHeight) >= ((float)client.Width / (float)client.Height))
                            image_size = new SizeI(client.Width, (Image.PixelHeight * client.Width) / Image.PixelWidth);
                        else
                            image_size = new SizeI((Image.PixelWidth * client.Height) / Image.PixelHeight, client.Height);

                        dc.DrawImage(Image, (client.Width / 2) - (image_size.Width / 2), (client.Height / 2) - (image_size.Height / 2), image_size.Width, image_size.Height);
                        break;

                    default:
                        // Normal, AutoSize
                        dc.DrawImage(Image, client.Left, client.Top, Image.PixelWidth, Image.PixelHeight);
                        break;
                }

                return;
            }

            base.OnPaint(pe);
        }


        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);

            Invalidate();
        }


#if USE_WebClient
#if !SILVERLIGHT
        WebClient ImageDownload
        {
            get
            {
                if (image_download == null)
                {
                    image_download = new WebClient();
                }

                return image_download;
            }
        }
#endif
#endif


        void ChangeImage(Bitmap value, bool from_url)
        {
            StopAnimation();

            image_from_url = from_url;
            image = value;

            UpdateSize();

            if (image != null && ImageAnimator.CanAnimate(image))
            {
                frame_handler = new EventHandler(OnAnimateImage);
                ImageAnimator.Animate(image, frame_handler);
            }
        }


        void StopAnimation()
        {
            if (frame_handler == null)
            {
                return;
            }

            ImageAnimator.StopAnimate(image, frame_handler);
            frame_handler = null;
        }


        void UpdateSize()
        {
            if (image == null)
            {
                return;
            }

            //  Need Resize
        }


        void OnAnimateImage(object sender, EventArgs e)
        {
            // This is called from a worker thread,BeginInvoke is used
            // so the control is updated from the correct thread

            //BeginInvoke(new EventHandler(UpdateAnimatedImage), new object[] { this, e });
            MethodInvoker m = delegate()
            {
                UpdateAnimatedImage(this, e);
            };
            BeginInvoke(m);
        }


        void UpdateAnimatedImage(object sender, EventArgs e)
        {
            ImageAnimator.UpdateFrames(image);
            Refresh();
        }


        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            UpdateSize();

            if (image != null && ImageAnimator.CanAnimate(image))
            {
                frame_handler = new EventHandler(OnAnimateImage);
                ImageAnimator.Animate(image, frame_handler);
            }
        }


#if USE_WebClient
#if !SILVERLIGHT
        void ImageDownload_DownloadDataCompleted(object sender, DownloadDataCompletedEventArgs e)
        {
            if (e.Error != null &&
                !e.Cancelled)
            {
                Image = error_image;
            }
            else if (e.Error == null &&
                !e.Cancelled)
            {
                using (System.IO.MemoryStream ms = new System.IO.MemoryStream(e.Result))
                {
                    Image = Bitmap.FromStream(ms);
                }
            }

            ImageDownload.DownloadProgressChanged -= new DownloadProgressChangedEventHandler(ImageDownload_DownloadProgressChanged);
            ImageDownload.DownloadDataCompleted -= new DownloadDataCompletedEventHandler(ImageDownload_DownloadDataCompleted);
            image_download = null;

            OnLoadCompleted(e);
        }


        void ImageDownload_DownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
        {
            OnLoadProgressChanged(new ProgressChangedEventArgs(e.ProgressPercentage, e.UserState));
        }


        public void CancelAsync()
        {
            if (image_download != null)
            {
                image_download.CancelAsync();
            }
        }


        public void Load()
        {
            Load(image_location);
        }


        public void Load(string url)
        {
            if (string.IsNullOrEmpty(url))
            {
                if (Config.GenerateExceptions)
                {
                    throw new InvalidOperationException("ImageLocation not specified.");
                }

                return;
            }

            image_location = url;

            if (url.Contains("://"))
            {
                using (Stream s = ImageDownload.OpenRead(url))
                {
                    ChangeImage(Bitmap.FromStream(s), true);
                }
            }
            else
            {
                ChangeImage(Bitmap.FromFile(url), true);
            }
        }


        public void LoadAsync()
        {
            LoadAsync(image_location);
        }


        public void LoadAsync(string url)
        {
            // If WaitOnLoad is true, do not do async
            if (wait_on_load)
            {
                Load(url);
                return;
            }

            if (string.IsNullOrEmpty(url))
            {
                throw new InvalidOperationException("ImageLocation not specified.");
            }

            image_location = url;
            ChangeImage(InitialImage, true);

            if (ImageDownload.IsBusy)
            {
                ImageDownload.CancelAsync();
            }

            Uri uri = null;
            try
            {
                uri = new Uri(url);
            }
            catch (UriFormatException)
            {
                uri = new Uri(IO.Path.GetFullPath(url));
            }

            ImageDownload.DownloadProgressChanged += new DownloadProgressChangedEventHandler(ImageDownload_DownloadProgressChanged);
            ImageDownload.DownloadDataCompleted += new DownloadDataCompletedEventHandler(ImageDownload_DownloadDataCompleted);
            ImageDownload.DownloadDataAsync(uri);
        }
#endif
#endif


        public override string ToString()
        {
            return String.Format("{0}, SizeMode: {1}", base.ToString(), SizeMode);
        }


        public event EventHandler SizeModeChanged;
        
        protected virtual void OnSizeModeChanged(EventArgs e)
        {
            if (SizeModeChanged != null)
            {
                SizeModeChanged(this, e);
            }
        }


#if !SILVERLIGHT
        public event AsyncCompletedEventHandler LoadCompleted;
        public event ProgressChangedEventHandler LoadProgressChanged;

        protected virtual void OnLoadCompleted(AsyncCompletedEventArgs e)
        {
            if (LoadCompleted != null)
            {
                LoadCompleted(this, e);
            }
        }

        protected virtual void OnLoadProgressChanged(ProgressChangedEventArgs e)
        {
            if (LoadProgressChanged != null)
            {
                LoadProgressChanged(this, e);
            }
        }
#endif
    }
}
