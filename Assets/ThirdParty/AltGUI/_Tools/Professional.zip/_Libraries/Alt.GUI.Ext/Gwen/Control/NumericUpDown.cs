﻿//  Original source code has been modified by AltSoftLab Inc. 2012-2015
//  This source code is provided "as is" without express or implied warranty of any kind.

using System;
using Alt.GUI.Temporary.Gwen.Control.Layout;
using Alt.GUI.Temporary.Gwen.ControlInternal;

namespace Alt.GUI.Temporary.Gwen.Control
{
    /// <summary>
    /// Numeric up/down.
    /// </summary>
    public class NumericUpDown : TextBoxNumeric
    {
        float m_Max;
        float m_Min;
        int m_DecimalPlaces;

        readonly Gwen.Control.Layout.Splitter m_Splitter;
        readonly UpDownButton_Up m_Up;
        readonly UpDownButton_Down m_Down;


        /// <summary>
        /// Minimum value.
        /// </summary>
        public float Min { get { return m_Min; } set { m_Min = value; } }
        public float Minimum { get { return Min; } set { Min = value; } }


        /// <summary>
        /// Maximum value.
        /// </summary>
        public float Max { get { return m_Max; } set { m_Max = value; } }
        public float Maximum { get { return Max; } set { Max = value; } }


        public int DecimalPlaces
        {
            get { return m_DecimalPlaces; }
            set
            {
                m_DecimalPlaces = value;
                UpdateInterval();
            }
        }

        
        float m_Interval = 1;
        public float Increment
        {
            get
            {
                return m_Interval;
            }
            set
            {
                m_Interval = value;
            }
        }

        
        void UpdateInterval()
        {
            m_Interval = (float)(1.0 / System.Math.Pow(10, m_DecimalPlaces));
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="NumericUpDown"/> class.
        /// </summary>
        /// <param name="parent">Parent control.</param>
        public NumericUpDown(Base parent)
            : base(parent)
        {
            SetSize(100, 20);

            m_Splitter = new Gwen.Control.Layout.Splitter(this);
            m_Splitter.Dock = Pos.Right;
            m_Splitter.SetSize(13, 13);

            m_Up = new UpDownButton_Up(m_Splitter);
            m_Up.Clicked += OnButtonUp;
            m_Up.IsTabable = false;
            m_Splitter.SetPanel(0, m_Up, false);

            m_Down = new UpDownButton_Down(m_Splitter);
            m_Down.Clicked += OnButtonDown;
            m_Down.IsTabable = false;
            m_Down.Padding = new Padding(0, 1, 1, 0);
            m_Splitter.SetPanel(1, m_Down, false);

            m_Max = 100;
            m_Min = 0;
            m_DecimalPlaces = 0;
            m_Value = 0f;
            Text = "0";
        }


        /// <summary>
        /// Invoked when the value has been changed.
        /// </summary>
        public event GwenEventHandler ValueChanged;


        /// <summary>
        /// Handler for Up Arrow keyboard event.
        /// </summary>
        /// <param name="down">Indicates whether the key was pressed or released.</param>
        /// <returns>
        /// True if handled.
        /// </returns>
        protected override bool OnKeyUp(bool down)
        {
            if (down) OnButtonUp(null);
            return true;
        }


        /// <summary>
        /// Handler for Down Arrow keyboard event.
        /// </summary>
        /// <param name="down">Indicates whether the key was pressed or released.</param>
        /// <returns>
        /// True if handled.
        /// </returns>
        protected override bool OnKeyDown(bool down)
        {
            if (down) OnButtonDown(null);
            return true;
        }


        /// <summary>
        /// Handler for the button up event.
        /// </summary>
        /// <param name="control">Event source.</param>
        protected virtual void OnButtonUp(Base control)
        {
            Value = m_Value + m_Interval;
        }


        /// <summary>
        /// Handler for the button down event.
        /// </summary>
        /// <param name="control">Event source.</param>
        protected virtual void OnButtonDown(Base control)
        {
            Value = m_Value - m_Interval;
        }


        /// <summary>
        /// Determines whether the text can be assighed to the control.
        /// </summary>
        /// <param name="str">Text to evaluate.</param>
        /// <returns>True if the text is allowed.</returns>
        protected override bool IsTextAllowed(string str)
        {
            float d;
            if (!float.TryParse(str, out d))
                return false;
            if (d < m_Min) return false;
            if (d > m_Max) return false;
            return true;
        }


        /// <summary>
        /// Numeric value of the control.
        /// </summary>
        public override float Value
        {
            get
            {
                return base.Value;
            }
            set
            {
                if (value < m_Min) value = m_Min;
                if (value > m_Max) value = m_Max;
                if (value == m_Value) return;

                base.Value = value;
            }
        }


        /// <summary>
        /// Handler for the text changed event.
        /// </summary>
        protected override void OnTextChanged()
        {
            base.OnTextChanged();
            if (ValueChanged != null)
                ValueChanged.Invoke(this);
        }
    }
}
