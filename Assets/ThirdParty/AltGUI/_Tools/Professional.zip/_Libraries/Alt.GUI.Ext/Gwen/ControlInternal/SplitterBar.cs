﻿//  Original source code has been modified by AltSoftLab Inc. 2012-2015
//  This source code is provided "as is" without express or implied warranty of any kind.

using System;

using Alt.GUI.Temporary.Gwen.Control;

using Alt.Sketch;


namespace Alt.GUI.Temporary.Gwen.ControlInternal
{
    /// <summary>
    /// Splitter bar.
    /// </summary>
    public class SplitterBar : Dragger
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SplitterBar"/> class.
        /// </summary>
        /// <param name="parent">Parent control.</param>
        public SplitterBar(Base parent)
            : base(parent)
        {
            Target = this;
            RestrictToParent = true;
        }

        /// <summary>
        /// Renders the control using specified skin.
        /// </summary>
        /// <param name="skin">Skin to use.</param>
        protected override void Render(Skin.Base skin)
        {
            //if (ShouldDrawBackground || MouseHoverSplittersVisible && IsHovered)
            double k = (ShouldDrawBackground || MouseHoverSplittersVisible && IsHovered) ? 1.0 :
                (skin.Renderer.Graphics.RenderSystemName == Graphics.RSN_Unity ? 0.2 : 0.1);
            {
                double opacity = skin.Renderer.Graphics.Opacity;

                skin.Renderer.Graphics.Opacity = opacity * k;
                skin.DrawButton(this, true, false, IsDisabled);

                skin.Renderer.Graphics.Opacity = opacity;
            }
        }

        /// <summary>
        /// Lays out the control's interior according to alignment, padding, dock etc.
        /// </summary>
        /// <param name="skin">Skin to use.</param>
        protected override void Layout(Skin.Base skin)
        {
            MoveTo(X, Y);
        }


        bool m_MouseHoverSplittersVisible = true;
        public bool MouseHoverSplittersVisible
        {
            get
            {
                return m_MouseHoverSplittersVisible;
            }
            set
            {
                m_MouseHoverSplittersVisible = value;
            }
        }
    }
}
