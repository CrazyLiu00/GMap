﻿//  Original source code has been modified by AltSoftLab Inc. 2012-2015
//  This source code is provided "as is" without express or implied warranty of any kind.

using System;
using System.Collections.Generic;

using Alt.GUI.Temporary.Gwen.Anim;
using Alt.GUI.Temporary.Gwen.DragDrop;
using Alt.GUI.Temporary.Gwen.Input;
using Alt.GUI;
using Alt.Sketch;


namespace Alt.GUI.Temporary.Gwen.Control
{
    /// <summary>
    /// Canvas control. It should be the root parent for all other controls.
    /// </summary>
    public class Canvas : Base
    {
        Cursor m_CurrentCursor;
        public Cursor CurrentCursor
        {
            get
            {
                return m_CurrentCursor;
            }
        }
        internal void SetCursor(Cursor cursor)
        {
            m_CurrentCursor = cursor;
        }

        
        InputHandler m_InputHandler;
        public InputHandler InputHandler
        {
            get
            {
                return m_InputHandler;
            }
        }


        DragAndDrop m_DragAndDrop;
        public DragAndDrop DragAndDrop
        {
            get
            {
                return m_DragAndDrop;
            }
        }


        ToolTipHandler m_ToolTipHandler;
        public ToolTipHandler ToolTipHandler
        {
            get
            {
                return m_ToolTipHandler;
            }
        }


        bool m_NeedsRedraw;
        float m_Scale = 1;

        Color m_BackgroundColor;


        Brush m_Background = null;
        public Brush Background
        {
            get
            {
                return m_Background;
            }
            set
            {
                m_Background = value;

                m_NeedRefresh = true;
            }
        }
        
        Brush m_Background2 = null;
        public Brush Background2
        {
            get
            {
                return m_Background2;
            }
            set
            {
                m_Background2 = value;

                m_NeedRefresh = true;
            }
        }

        Bitmap m_BackgroundBuffer;
        Bitmap GetBackgroundBuffer(PixelFormat pixelFormat)
        {
            if (m_Background == null ||
                Size.IsEmpty)
            {
                return null;
            }

            if (m_BackgroundBuffer == null ||
                m_BackgroundBuffer.PixelSize != Size)
            {
                if (m_BackgroundBuffer != null)
                {
                    m_BackgroundBuffer.Dispose();
                }

                m_BackgroundBuffer = new Bitmap(Size, pixelFormat);//PixelFormat.//Format24bppRgb);Format32bppArgb);
                
                m_NeedRefresh = true;
            }

            return m_BackgroundBuffer;
        }
        bool m_NeedRefresh = true;
        bool NeedRefresh
        {
            get
            {
                return
                    m_Background != null &&
                    (m_NeedRefresh ||
                    m_BackgroundBuffer == null ||
                    m_BackgroundBuffer.PixelSize != Size) && !Size.IsEmpty;
            }
        }


        // [omeg] these are not created by us, so no disposing
        internal Base FirstTab;
        internal Base NextTab;


        private readonly List<IDisposable> m_DisposeQueue; // dictionary for faster access?


        /// <summary>
        /// Scale for rendering.
        /// </summary>
        internal float Scale
        {
            get { return m_Scale; }
            set
            {
                if (m_Scale == value)
                    return;

                m_Scale = value;

                if (Skin != null && Skin.Renderer != null)
                    Skin.Renderer.Scale = m_Scale;

                OnScaleChanged();
                Redraw();
            }
        }


        /// <summary>
        /// Background color.
        /// </summary>
        public Color BackgroundColor { get { return m_BackgroundColor; } set { m_BackgroundColor = value; } }


        /// <summary>
        /// In most situations you will be rendering the canvas every frame. 
        /// But in some situations you will only want to render when there have been changes. 
        /// You can do this by checking NeedsRedraw.
        /// </summary>
        public bool NeedsRedraw { get { return m_NeedsRedraw; } set { m_NeedsRedraw = value; } }


        /// <summary>
        /// Initializes a new instance of the <see cref="Canvas"/> class.
        /// </summary>
        /// <param name="skin">Skin to use.</param>
        public Canvas(Skin.Base skin)
        {
            m_InputHandler = new InputHandler(this);
            m_DragAndDrop = new DragAndDrop(this);
            m_ToolTipHandler = new ToolTipHandler(this);

            //SetBounds(0, 0, 10000, 10000);
            SetBounds(0, 0, 1000, 1000);

            SetSkin(skin);
            Scale = 1.0f;
            BackgroundColor = Color.Parse("#FF1254A3") * 1.3;
            ShouldDrawBackground = false;

            m_DisposeQueue = new List<IDisposable>();
        }

        public override void Dispose()
        {
            ProcessDelayedDeletes();
            
            base.Dispose();

            m_InputHandler = null;
        }


        /// <summary>
        /// Re-renders the control, invalidates cached texture.
        /// </summary>
        public override void Redraw()
        {
            NeedsRedraw = true;
            base.Redraw();
        }


        // Children call parent.GetCanvas() until they get to 
        // this top level function.
        public override Canvas GetCanvas()
        {
            if (Parent == null)
            {
                return this;
            }

            return Parent.GetCanvas();
        }

        public override Canvas GetCurrentCanvas()
        {
            return this;
        }


        /// <summary>
        /// Additional initialization (which is sometimes not appropriate in the constructor)
        /// </summary>
        protected void Initialize()
        {

        }


        /// <summary>
        /// Renders the canvas. Call in your rendering loop.
        /// </summary>
        public void RenderCanvas()
        {
            RenderCanvas(null);
        }


        PaintEventHandler m_PostDrawBackground;
        public event PaintEventHandler PostDrawBackground
        {
            add
            {
                m_PostDrawBackground += value;
            }
            remove
            {
                m_PostDrawBackground -= value;
            }
        }


        public void RenderCanvas(Graphics graphics)
        {
            if (graphics != null)
            {
                Skin.Renderer.GraphicsInitialRenderOffset = graphics.RenderOffset;
            }

            DoThink();

            Renderer.Base render = Skin.Renderer;
            render.Graphics = graphics;

            render.Begin();

            RecurseLayout(Skin);

            render.ClipRegion = Bounds;
            render.RenderOffset = PointI.Empty;
            render.Scale = Scale;

            if (ShouldDrawBackground)
            {
                if (m_Background != null &&
                    graphics != null)
                {
                    if (graphics is SoftwareGraphics)
                    {
                        Bitmap TargetBitmap = (graphics as SoftwareGraphics).TargetBitmap;

                        Bitmap backgroundBuffer = GetBackgroundBuffer(TargetBitmap != null ? TargetBitmap.PixelFormat : PixelFormat.Format32bppArgb);
                        if (backgroundBuffer != null)
                        {
                            if (NeedRefresh)
                            {
                                Graphics g = Graphics.FromImage(backgroundBuffer);
                                g.FillRectangle(m_Background, new RectI(PointI.Zero, backgroundBuffer.PixelSize));

                                if (m_Background2 != null)
                                {
                                    g.FillRectangle(m_Background2, new RectI(PointI.Zero, backgroundBuffer.PixelSize));
                                }

                                m_NeedRefresh = false;
                            }

                            if (TargetBitmap != null &&
                                TargetBitmap.PixelSize == backgroundBuffer.PixelSize &&
                                TargetBitmap.PixelFormat == backgroundBuffer.PixelFormat)
                            {
                                byte[] src = backgroundBuffer.LockBits(ImageLockMode.ReadOnly).Scan0;
                                byte[] dest = TargetBitmap.LockBits(ImageLockMode.WriteOnly).Scan0;
                                Array.Copy(src, dest, src.Length);
                            }
                            else
                            {
                                graphics.DrawImage(backgroundBuffer, PointI.Zero);
                            }
                        }
                    }
                    else
                    {
                        graphics.FillRectangle(m_Background, new RectI(PointI.Zero, Size));
                        
                        if (m_Background2 != null)
                        {
                            graphics.FillRectangle(m_Background2, new RectI(PointI.Zero, Size));
                        }
                    }
                }
                else
                {
                    if (m_BackgroundColor.A != 0)
                    {
                        render.DrawColor = m_BackgroundColor;
                        render.DrawFilledRect(RenderBounds);
                    }
                }

                if (m_PostDrawBackground != null)
                {
                    GraphicsState state = graphics.Save();
                    try
                    {
                        m_PostDrawBackground(this, new PaintEventArgs(graphics, ClientRectangle));
                    }
                    finally
                    {
                        graphics.Restore(state);
                    }
                }
            }

            DoRender(Skin);

            DragAndDrop.RenderOverlay(this, Skin);

            ToolTipHandler.RenderToolTip(Skin);

            render.EndClip();

            render.End();
        }


        /// <summary>
        /// Renders the control using specified skin.
        /// </summary>
        /// <param name="skin">Skin to use.</param>
        protected override void Render(Skin.Base skin)
        {
            //skin.Renderer.rnd = new Random(1);
            base.Render(skin);
            m_NeedsRedraw = false;
        }


        /// <summary>
        /// Handler invoked when control's bounds change.
        /// </summary>
        /// <param name="oldBounds">Old bounds.</param>
        protected override void OnBoundsChanged(RectI oldBounds)
        {
            base.OnBoundsChanged(oldBounds);
            InvalidateChildren(true);
        }


        /// <summary>
        /// Processes input and layout. Also purges delayed delete queue.
        /// </summary>
        private void DoThink()
        {
            if (IsHidden)
                return;

            Animation.GlobalThink();

            // Reset tabbing
            NextTab = null;
            FirstTab = null;

            ProcessDelayedDeletes();

            // Check has focus etc..
            RecurseLayout(Skin);

            // If we didn't have a next tab, cycle to the start.
            if (NextTab == null)
                NextTab = FirstTab;

            InputHandler.OnCanvasThink(this);
        }


        /// <summary>
        /// Adds given control to the delete queue and detaches it from canvas. Don't call from Dispose, it modifies child list.
        /// </summary>
        /// <param name="control">Control to delete.</param>
        public void AddDelayedDelete(Base control)
        {
            if (!m_DisposeQueue.Contains(control))
            {
                m_DisposeQueue.Add(control);
                RemoveChild(control, false);
            }
#if DEBUG
            else
                throw new InvalidOperationException("Control deleted twice");
#endif
        }


        private void ProcessDelayedDeletes()
        {
            //if (m_DisposeQueue.Count > 0)
            //    System.Diagnostics.Debug.Print("Canvas.ProcessDelayedDeletes: {0} items", m_DisposeQueue.Count);
            foreach (IDisposable control in m_DisposeQueue)
            {
                control.Dispose();
            }
            m_DisposeQueue.Clear();
        }


        /// <summary>
        /// Handles mouse movement events. Called from Input subsystems.
        /// </summary>
        /// <returns>True if handled.</returns>
        public bool Input_MouseMoved(int x, int y, int dx, int dy)
        {
            if (IsHidden)
                return false;

            // Todo: Handle scaling here..
            //float fScale = 1.0f / Scale();

            InputHandler.OnMouseMoved(this, x, y, dx, dy);

            if (InputHandler.HoveredControl == null) return false;
            if (InputHandler.HoveredControl == this) return false;
            if (InputHandler.HoveredControl.GetCanvas() != this) return false;

            InputHandler.HoveredControl.InputMouseMoved(x, y, dx, dy);
            InputHandler.HoveredControl.UpdateCursor();

            DragAndDrop.OnMouseMoved(InputHandler.HoveredControl, x, y);

            return true;
        }


        /// <summary>
        /// Handles mouse button events. Called from Input subsystems.
        /// </summary>
        /// <returns>True if handled.</returns>
        public bool Input_MouseButton(Alt.GUI.MouseButtons button, bool down)
        {
            if (IsHidden)
            {
                return false;
            }

            return InputHandler.OnMouseClicked(this, button, down);
        }


        int m_MouseX = 0;
        int m_MouseY = 0;

        void UpdateMouseXY(int x, int y, out int dx, out int dy)
        {
            dx = x - m_MouseX;
            dy = y - m_MouseY;

            m_MouseX = x;
            m_MouseY = y;
        }

        public bool Inject_MouseDown(MouseEventArgs e)
        {
            UpdateMouseMove(e);

            return Input_MouseButton(e.Button, true);
        }

        public bool Inject_MouseUp(MouseEventArgs e)
        {
            UpdateMouseMove(e);

            return Input_MouseButton(e.Button, false);
        }

        public bool Inject_MouseMove(MouseEventArgs e)
        {
            int dx, dy;
            UpdateMouseXY(e.X, e.Y, out dx, out dy);

            return Input_MouseMoved(m_MouseX, m_MouseY, dx, dy);
        }
        void UpdateMouseMove(MouseEventArgs e)
        {
            //TEST  if (m_MouseX != e.X || m_MouseY != e.Y)
            {
                Inject_MouseMove(new MouseEventArgs(e.Location));
            }
        }

        public bool Inject_MouseWheel(MouseEventArgs e)
        {
            UpdateMouseMove(e);

            return Input_MouseWheel(e.Delta);
        }


        /// <summary>
        /// Handles keyboard events. Called from Input subsystems.
        /// </summary>
        /// <returns>True if handled.</returns>
        public bool Input_Key(Keys key, bool down)
        {
            if (IsHidden)
            {
                return false;
            }

            if (key <= Keys.Invalid)
            {
                return false;
            }
            //  NoNeed  if (key >= Keys.Count) return false;

            return InputHandler.OnKeyEvent(this, key, down);
        }


        /// <summary>
        /// Translates alphanumeric OpenTK key code to character value.
        /// </summary>
        /// <param name="key">OpenTK key code.</param>
        /// <returns>Translated character.</returns>
        static char TranslateChar(Keys key)
        {
            if (key >= Keys.A && key <= Keys.Z)
            {
                return (char)('a' + ((int)key - (int)Keys.A));
            }

            return ' ';
        }

        public bool Inject_KeyDown(KeyEventArgs e)
        {
            char ch = TranslateChar(e.KeyCode);

            if (InputHandler.DoSpecialKeys(this, ch))
            {
                return false;
            }
            /*
            if (ch != ' ')
            {
                m_Canvas.Input_Character(ch);
            }
            */

            return Input_Key(e.KeyData, true);
        }

        public bool Inject_KeyUp(KeyEventArgs e)
        {
            return Input_Key(e.KeyData, false);
        }


        /// <summary>
        /// Handles keyboard events. Called from Input subsystems.
        /// </summary>
        /// <returns>True if handled.</returns>
        public bool Input_Character(char chr)
        {
            if (IsHidden) return false;
            if (char.IsControl(chr)) return false;

            //Handle Accelerators
            if (InputHandler.HandleAccelerator(this, chr))
                return true;

            //Handle characters
            if (InputHandler.KeyboardFocus == null) return false;
            if (InputHandler.KeyboardFocus.GetCanvas() != this) return false;
            if (!InputHandler.KeyboardFocus.IsVisible) return false;
            if (InputHandler.IsControlDown) return false;

            return InputHandler.KeyboardFocus.InputChar(chr);
        }


        public bool Inject_KeyPress(KeyPressEventArgs e)
        {
            return Input_Character(e.KeyChar);
        }


        /// <summary>
        /// Handles the mouse wheel events. Called from Input subsystems.
        /// </summary>
        /// <returns>True if handled.</returns>
        public bool Input_MouseWheel(int val)
        {
            if (IsHidden) return false;
            if (InputHandler.HoveredControl == null) return false;
            if (InputHandler.HoveredControl == this) return false;
            if (InputHandler.HoveredControl.GetCanvas() != this) return false;

            return InputHandler.HoveredControl.InputMouseWheeled(val);
        }
    }
}
