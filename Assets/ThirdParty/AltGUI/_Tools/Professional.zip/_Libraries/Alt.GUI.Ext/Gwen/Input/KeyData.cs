﻿//  Original source code has been modified by AltSoftLab Inc. 2012-2015
//  This source code is provided "as is" without express or implied warranty of any kind.

using System;
using System.Collections.Generic;
using Alt.GUI.Temporary.Gwen.Control;
using Alt.GUI;


namespace Alt.GUI.Temporary.Gwen.Input
{
    /// <summary>
    /// Keyboard state.
    /// </summary>
    public class KeyData
    {
        public readonly Dictionary<Keys, bool> KeyState;
        public readonly Dictionary<Keys, float> NextRepeat;
        public Base Target;
        public bool LeftMouseDown;
        public bool RightMouseDown;
        public bool MiddleMouseDown;


        public KeyData()
        {
            KeyState = new Dictionary<Keys, bool>();
            NextRepeat = new Dictionary<Keys, float>();

            // everything is initialized to 0 by default
            //foreach (Keys key in Enum.GetValues(typeof(Keys)))
            foreach (Keys key in EnumHelper.GetValues<Keys>())
            {
                if (!KeyState.ContainsKey(key))
                {
                    KeyState.Add(key, false);
                    NextRepeat.Add(key, 0);
                }
            }
        }
    }
}
