﻿//  Original source code has been modified by AltSoftLab Inc. 2012-2015
//  This source code is provided "as is" without express or implied warranty of any kind.

using System;

using Alt.Sketch;


namespace Alt.GUI.Temporary.Gwen.Renderer
{
    /// <summary>
    /// Base renderer.
    /// </summary>
    public class Base : IDisposable
    {
		Graphics m_Graphics;
        public Graphics Graphics
        {
            get
			{
				return m_Graphics;
			}
            protected internal set
			{
				m_Graphics = value;
			}
        }


        internal Point GraphicsInitialRenderOffset = Point.Zero;


        //public Random rnd;
        PointI m_RenderOffset;
        RectI m_ClipRegion;
        //protected ICacheToTexture m_RTT;

		float m_Scale;
        internal float Scale
		{
			get
			{
				return m_Scale;
			}
			set
			{
				m_Scale = value;
			}
		}


        /// <summary>
        /// Initializes a new instance of the <see cref="Base"/> class.
        /// </summary>
        internal Base(bool useCTT)
        {
            //rnd = new Random();
            m_RenderOffset = PointI.Empty;
            Scale = 1.0f;

            if (useCTT &&
                CTT != null)
            {
                CTT.Initialize();
            }
        }


        internal Base() :
            this(true)
        {
        }


        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        /// <filterpriority>2</filterpriority>
        public virtual void Dispose()
        {
            if (CTT != null)
                CTT.ShutDown();
            GC.SuppressFinalize(this);
        }


#if DEBUG
        ~Base()
        {
            //TEMP  throw new InvalidOperationException(String.Format("IDisposable object finalized: {0}", GetType()));
            //Debug.Print(String.Format("IDisposable object finalized: {0}", GetType()));
        }
#endif


        /// <summary>
        /// Starts rendering.
        /// </summary>
        public virtual void Begin()
        { }


        /// <summary>
        /// Stops rendering.
        /// </summary>
        public virtual void End()
        { }


		Color m_DrawColor;
        /// <summary>
        /// Gets or sets the current drawing color.
        /// </summary>
        public virtual Color DrawColor
		{
			get
			{
				return m_DrawColor;
			}
			set
			{
				m_DrawColor = value;
			}
		}


        /// <summary>
        /// Rendering offset. No need to touch it usually.
        /// </summary>
        public PointI RenderOffset { get { return m_RenderOffset; } set { m_RenderOffset = value; } }


        /// <summary>
        /// Clipping rectangle.
        /// </summary>
        public RectI ClipRegion { get { return m_ClipRegion; } set { m_ClipRegion = value; } }


        /// <summary>
        /// Indicates whether the clip region is visible.
        /// </summary>
        public bool ClipRegionVisible
        {
            get
            {
                if (m_ClipRegion.Width <= 0 || m_ClipRegion.Height <= 0)
                    return false;

                return true;
            }
        }

        /// <summary>
        /// Draws a line.
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <param name="a"></param>
        /// <param name="b"></param>
        public virtual void DrawLine(int x, int y, int a, int b)
        { }

        /// <summary>
        /// Draws a solid filled rectangle.
        /// </summary>
        /// <param name="rect"></param>
        public virtual void DrawFilledRect(RectI rect)
        { }

        /// <summary>
        /// Starts clipping to the current clipping rectangle.
        /// </summary>
        public virtual void StartClip()
        { }

        /// <summary>
        /// Stops clipping.
        /// </summary>
        public virtual void EndClip()
        { }

        /// <summary>
        /// Loads the specified texture.
        /// </summary>
        /// <param name="t"></param>
        public virtual void LoadTexture(Texture t)
        { }

        /// <summary>
        /// Initializes texture from raw pixel data.
        /// </summary>
        /// <param name="t">Texture to initialize. Dimensions need to be set.</param>
        /// <param name="pixelData">Pixel data in RGBA format.</param>
        public virtual void LoadTextureRaw(Texture t, byte[] pixelData)
        { }

        /// <summary>
        /// Initializes texture from image file data.
        /// </summary>
        /// <param name="t">Texture to initialize.</param>
        /// <param name="data">Image file as stream.</param>
        public virtual void LoadTextureStream(Texture t, System.IO.Stream data)
        { }

        /// <summary>
        /// Frees the specified texture.
        /// </summary>
        /// <param name="t">Texture to free.</param>
        public virtual void FreeTexture(Texture t)
        { }

        /// <summary>
        /// Draws textured rectangle.
        /// </summary>
        /// <param name="t">Texture to use.</param>
        /// <param name="targetRect">Rectangle bounds.</param>
        /// <param name="u1">Texture coordinate u1.</param>
        /// <param name="v1">Texture coordinate v1.</param>
        /// <param name="u2">Texture coordinate u2.</param>
        /// <param name="v2">Texture coordinate v2.</param>
        public void DrawTexturedRect(Texture t, RectI targetRect)//, float u1=0, float v1=0, float u2=1, float v2=1)
        {
            DrawTexturedRect(t, targetRect, 0, 0, 1, 1);
        }

        public void DrawTexturedRect(Texture t, RectI targetRect, float u1)//=0, float v1=0, float u2=1, float v2=1)
        {
            DrawTexturedRect(t, targetRect, u1, 0, 1, 1);
        }

        public void DrawTexturedRect(Texture t, RectI targetRect, float u1//=0
            , float v1)//=0, float u2=1, float v2=1)
        {
            DrawTexturedRect(t, targetRect, u1, v1, 1, 1);
        }

        public void DrawTexturedRect(Texture t, RectI targetRect, float u1//=0
            , float v1//=0
            , float u2)//=1, float v2=1)
        {
            DrawTexturedRect(t, targetRect, u1, v1, u2, 1);
        }

        public virtual void DrawTexturedRect(Texture t, RectI targetRect, float u1//=0
            , float v1//=0
            , float u2//=1
            , float v2)//=1)
        {
        }


        /// <summary>
        /// Draws "missing image" default texture.
        /// </summary>
        /// <param name="rect">Target rectangle.</param>
        public virtual void DrawMissingImage(RectI rect)
        {
            //DrawColor = Color.FromArgb(255, rnd.Next(0,255), rnd.Next(0,255), rnd.Next(0, 255));
            DrawColor = Color.Red;
            DrawFilledRect(rect);
        }


        /// <summary>
        /// Cache to texture provider.
        /// </summary>
        public virtual ICacheToTexture CTT { get { return null; } }


        /// <summary>
        /// Returns dimensions of the text using specified font.
        /// </summary>
        /// <param name="font">Font to use.</param>
        /// <param name="text">Text to measure.</param>
        /// <returns>Width and height of the rendered text.</returns>
        public virtual SizeI MeasureText(Font font, String text)
        {
            SizeI p = new SizeI((int)(font.Size * Scale * text.Length * 0.4f), (int)(font.Size * Scale));

            return p;
        }


        /// <summary>
        /// Renders text using specified font.
        /// </summary>
        /// <param name="font">Font to use.</param>
        /// <param name="position">Top-left corner of the text.</param>
        /// <param name="text">Text to render.</param>
        public virtual void RenderText(Font font, PointI position, String text)
        {
            double size = font.Size * Scale;

            for (int i = 0; i < text.Length; i++)
            {
                char chr = text[i];

                if (chr == ' ')
                    continue;

                RectI r = Util.FloatRect(position.X + i * size * 0.4f, position.Y, size * 0.4f - 1, size);

                /*
                    This isn't important, it's just me messing around changing the
                    shape of the rect based on the letter.. just for fun.
                */
                if (chr == 'l' || chr == 'i' || chr == '!' || chr == 't')
                {
                    r.Width = 1;
                }
                else if (chr >= 'a' && chr <= 'z')
                {
                    r.Y = (int)(r.Y + size * 0.5f);
                    r.Height = (int)(r.Height - size * 0.4f);
                }
                else if (chr == '.' || chr == ',')
                {
                    r.X += 2;
                    r.Y += r.Height - 2;
                    r.Width = 2;
                    r.Height = 2;
                }
                else if (chr == '\'' || chr == '`' || chr == '"')
                {
                    r.X += 3;
                    r.Width = 2;
                    r.Height = 2;
                }

                if (chr == 'o' || chr == 'O' || chr == '0')
                    DrawLinedRect(r);
                else
                    DrawFilledRect(r);
            }
        }


        // No need to implement these functions in your derived class, but if 
        // you can do them faster than the default implementation it's a good idea to.


        /// <summary>
        /// Draws a lined rectangle. Used for keyboard focus overlay.
        /// </summary>
        /// <param name="rect">Target rectangle.</param>
        public virtual void DrawLinedRect(RectI rect)
        {
            DrawFilledRect(new RectI(rect.X, rect.Y, rect.Width, 1));
            DrawFilledRect(new RectI(rect.X, rect.Y + rect.Height - 1, rect.Width, 1));

            DrawFilledRect(new RectI(rect.X, rect.Y, 1, rect.Height));
            DrawFilledRect(new RectI(rect.X + rect.Width - 1, rect.Y, 1, rect.Height));
        }


        /// <summary>
        /// Draws a single pixel. Very slow, do not use. :P
        /// </summary>
        /// <param name="x">X.</param>
        /// <param name="y">Y.</param>
        public virtual void DrawPixel(int x, int y)
        {
            // [omeg] amazing ;)
            DrawFilledRect(new RectI(x, y, 1, 1));
        }


        /// <summary>
        /// Gets pixel color of a specified texture. Slow.
        /// </summary>
        /// <param name="texture">Texture.</param>
        /// <param name="x">X.</param>
        /// <param name="y">Y.</param>
        /// <returns>Pixel color.</returns>
        public virtual Color PixelColor(Texture texture, int x, int y)
        {
            return PixelColor(texture, x, y, Color.White);
        }


        /// <summary>
        /// Gets pixel color of a specified texture, returning default if otherwise failed. Slow.
        /// </summary>
        /// <param name="texture">Texture.</param>
        /// <param name="x">X.</param>
        /// <param name="y">Y.</param>
        /// <param name="defaultColor">Color to return on failure.</param>
        /// <returns>Pixel color.</returns>
        public virtual Color PixelColor(Texture texture, int x, int y, Color defaultColor)
        {
            return defaultColor;
        }


        /// <summary>
        /// Draws a round-corner rectangle.
        /// </summary>
        /// <param name="rect">Target rectangle.</param>
        /// <param name="slight"></param>
        public void DrawShavedCornerRect(RectI rect)//, bool slight = false)
        {
            DrawShavedCornerRect(rect, false);
        }


        public virtual void DrawShavedCornerRect(RectI rect, bool slight)// = false)
        {
            // Draw INSIDE the w/h.
            rect.Width -= 1;
            rect.Height -= 1;

            if (slight)
            {
                DrawFilledRect(new RectI(rect.X + 1, rect.Y, rect.Width - 1, 1));
                DrawFilledRect(new RectI(rect.X + 1, rect.Y + rect.Height, rect.Width - 1, 1));

                DrawFilledRect(new RectI(rect.X, rect.Y + 1, 1, rect.Height - 1));
                DrawFilledRect(new RectI(rect.X + rect.Width, rect.Y + 1, 1, rect.Height - 1));
                return;
            }

            DrawPixel(rect.X + 1, rect.Y + 1);
            DrawPixel(rect.X + rect.Width - 1, rect.Y + 1);

            DrawPixel(rect.X + 1, rect.Y + rect.Height - 1);
            DrawPixel(rect.X + rect.Width - 1, rect.Y + rect.Height - 1);

            DrawFilledRect(new RectI(rect.X + 2, rect.Y, rect.Width - 3, 1));
            DrawFilledRect(new RectI(rect.X + 2, rect.Y + rect.Height, rect.Width - 3, 1));

            DrawFilledRect(new RectI(rect.X, rect.Y + 2, 1, rect.Height - 3));
            DrawFilledRect(new RectI(rect.X + rect.Width, rect.Y + 2, 1, rect.Height - 3));
        }


        private int TranslateX(int x)
        {
            int x1 = x + m_RenderOffset.X;
            return Util.Ceil(x1 * Scale);
        }


        private int TranslateY(int y)
        {
            int y1 = y + m_RenderOffset.Y;
            return Util.Ceil(y1 * Scale);
        }


        /// <summary>
        /// Translates a panel's local drawing coordinate into view space, taking offsets into account.
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        public void Translate(ref int x, ref int y)
        {
            x += m_RenderOffset.X;
            y += m_RenderOffset.Y;

            x = Util.Ceil(x * Scale);
            y = Util.Ceil(y * Scale);
        }


        /// <summary>
        /// Translates a panel's local drawing coordinate into view space, taking offsets into account.
        /// </summary>
        public PointI Translate(PointI p)
        {
            int x = p.X;
            int y = p.Y;
            Translate(ref x, ref y);
            return new PointI(x, y);
        }


        /// <summary>
        /// Translates a panel's local drawing coordinate into view space, taking offsets into account.
        /// </summary>
        public RectI Translate(RectI rect)
        {
            return new RectI(TranslateX(rect.X), TranslateY(rect.Y), Util.Ceil(rect.Width * Scale), Util.Ceil(rect.Height * Scale));
        }


        /// <summary>
        /// Adds a point to the render offset.
        /// </summary>
        /// <param name="offset">PointI to add.</param>
        public void AddRenderOffset(PointI offset)
        {
            m_RenderOffset = new PointI(m_RenderOffset.X + offset.X, m_RenderOffset.Y + offset.Y);
        }


        /// <summary>
        /// Adds a rectangle to the clipping region.
        /// </summary>
        /// <param name="rect">Rectangle to add.</param>
        public void AddClipRegion(RectI rect)
        {
            rect.X = m_RenderOffset.X;
            rect.Y = m_RenderOffset.Y;

            RectI r = rect;
            if (rect.X < m_ClipRegion.X)
            {
                r.Width -= (m_ClipRegion.X - r.X);
                r.X = m_ClipRegion.X;
            }

            if (rect.Y < m_ClipRegion.Y)
            {
                r.Height -= (m_ClipRegion.Y - r.Y);
                r.Y = m_ClipRegion.Y;
            }

            if (rect.Right > m_ClipRegion.Right)
            {
                r.Width = m_ClipRegion.Right - r.X;
            }

            if (rect.Bottom > m_ClipRegion.Bottom)
            {
                r.Height = m_ClipRegion.Bottom - r.Y;
            }

            m_ClipRegion = r;
        }
    }
}
