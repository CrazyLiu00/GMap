﻿//  Original source code has been modified by AltSoftLab Inc. 2012-2015
//  This source code is provided "as is" without express or implied warranty of any kind.

using System;
using Alt.GUI.Temporary.Gwen.Control;


namespace Alt.GUI.Temporary.Gwen.ControlInternal
{
    /// <summary>
    /// Tree node label.
    /// </summary>
    public class TreeNodeLabel : Gwen.Control.Button
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TreeNodeLabel"/> class.
        /// </summary>
        /// <param name="parent">Parent control.</param>
        public TreeNodeLabel(Base parent)
            : base(parent)
        {
            Alignment = Pos.Left | Pos.CenterV;
            ShouldDrawBackground = false;
            Height = 16;
            TextPadding = new Padding(3, 0, 3, 0);

            IsToggle = true;
        }


        /// <summary>
        /// Updates control colors.
        /// </summary>
        public override void UpdateColors()
        {
            if (IsDisabled)
            {
                if (DisabledTextColor.HasValue)
                {
                    TextColor = DisabledTextColor.Value;
                }
                else
                {
                    TextColor = Skin.Colors.Button.Disabled;
                }

                return;
            }

            if (IsDepressed || ToggleState)
            {
                if (DownTextColor.HasValue)
                {
                    TextColor = DownTextColor.Value;
                }
                else
                {
                    TextColor = Skin.Colors.Tree.Selected;
                }

                return;
            }

            if (IsHovered)
            {
                if (HoverTextColor.HasValue)
                {
                    TextColor = HoverTextColor.Value;
                }
                else
                {
                    TextColor = Skin.Colors.Tree.Hover;
                }

                return;
            }

            if (UseCurrentColorAsNormal)
            {
                TextColor = ColorAsNormal;
            }
            else
            {
                if (NormalTextColor.HasValue)
                {
                    TextColor = NormalTextColor.Value;
                }
                else
                {
                    TextColor = Skin.Colors.Tree.Normal;
                }
            }
        }
    }
}
