﻿//  Original source code has been modified by AltSoftLab Inc. 2012-2015
//  This source code is provided "as is" without express or implied warranty of any kind.

using System;


namespace Alt.GUI.Temporary.Gwen.Control.Property
{
    /// <summary>
    /// Base control for property entry.
    /// </summary>
    public class Base : Control.Base
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Base"/> class.
        /// </summary>
        /// <param name="parent">Parent control.</param>
        public Base(Control.Base parent)
            : base(parent)
        {
            Height = 17;
        }


        /// <summary>
        /// Invoked when the property value has been changed.
        /// </summary>
        public event GwenEventHandler ValueChanged;


        /// <summary>
        /// Property value (todo: always string, which is ugly. do something about it).
        /// </summary>
        public virtual String Value { get { return null; } set { SetValue(value, false); } }


        /// <summary>
        /// Indicates whether the property value is being edited.
        /// </summary>
        public virtual bool IsEditing { get { return false; } }


        protected virtual void DoChanged()
        {
            if (ValueChanged != null)
                ValueChanged.Invoke(this);
        }


        protected virtual void OnValueChanged(Control.Base control)
        {
            DoChanged();
        }


        /// <summary>
        /// Sets the property value.
        /// </summary>
        /// <param name="value">Value to set.</param>
        /// <param name="fireEvents">Determines whether to fire "value changed" event.</param>
        public void SetValue(String value)//, bool fireEvents = false)
        {
            SetValue(value, false);
        }


        public virtual void SetValue(String value, bool fireEvents)// = false)
        {
        }
    }
}
