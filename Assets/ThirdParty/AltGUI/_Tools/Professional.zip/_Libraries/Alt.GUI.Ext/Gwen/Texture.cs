﻿//  Original source code has been modified by AltSoftLab Inc. 2012-2015
//  This source code is provided "as is" without express or implied warranty of any kind.

using System;


namespace Alt.GUI.Temporary.Gwen
{
    /// <summary>
    /// Represents a texture.
    /// </summary>
    public class Texture : IDisposable
    {
		String m_Name;
        /// <summary>
        /// Texture name. Usually file name, but exact meaning depends on renderer.
        /// </summary>
        public String Name
		{
			get
			{
				return m_Name;
			}
			set
			{
				m_Name = value;
			}
		}

		object m_RendererData;
        /// <summary>
        /// Renderer data.
        /// </summary>
        public object RendererData
		{
			get
			{
				return m_RendererData;
			}
			set
			{
				m_RendererData = value;
			}
		}

		bool m_Failed;
        /// <summary>
        /// Indicates that the texture failed to load.
        /// </summary>
        public bool Failed
		{
			get
			{
				return m_Failed;
			}
			set
			{
				m_Failed = value;
			}
		}

		int m_Width;
        /// <summary>
        /// Texture width.
        /// </summary>
        public int Width
		{
			get
			{
				return m_Width;
			}
			set
			{
				m_Width = value;
			}
		}

		int m_Height;
        /// <summary>
        /// Texture height.
        /// </summary>
        public int Height
		{
			get
			{
				return m_Height;
			}
			set
			{
				m_Height = value;
			}
		}


        readonly Renderer.Base m_Renderer;


        /// <summary>
        /// Initializes a new instance of the <see cref="Texture"/> class.
        /// </summary>
        /// <param name="renderer">Renderer to use.</param>
        public Texture(Renderer.Base renderer)
        {
            m_Renderer = renderer;
            Width = 4;
            Height = 4;
            Failed = false;
        }


        /// <summary>
        /// Loads the specified texture.
        /// </summary>
        /// <param name="name">Texture name.</param>
        public void Load(String name)
        {
            Name = name;
            m_Renderer.LoadTexture(this);
        }


        /// <summary>
        /// Initializes the texture from raw pixel data.
        /// </summary>
        /// <param name="width">Texture width.</param>
        /// <param name="height">Texture height.</param>
        /// <param name="pixelData">Color array in RGBA format.</param>
        public void LoadRaw(int width, int height, byte[] pixelData)
        {
            Width = width;
            Height = height;
            m_Renderer.LoadTextureRaw(this, pixelData);
        }

        public void LoadStream(System.IO.Stream data)
        {
            m_Renderer.LoadTextureStream(this, data);
        }


        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            m_Renderer.FreeTexture(this);
            GC.SuppressFinalize(this);
        }


#if DEBUG
        ~Texture()
        {
            //TEMP  throw new InvalidOperationException(String.Format("IDisposable object finalized: {0}", GetType()));
            //Debug.Print(String.Format("IDisposable object finalized: {0}", GetType()));
        }
#endif

    }
}
