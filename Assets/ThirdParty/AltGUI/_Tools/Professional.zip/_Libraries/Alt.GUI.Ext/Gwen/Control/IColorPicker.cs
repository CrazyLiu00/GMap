﻿//  Original source code has been modified by AltSoftLab Inc. 2012-2015
//  This source code is provided "as is" without express or implied warranty of any kind.

using System;

using Alt.Sketch;


namespace Alt.GUI.Temporary.Gwen.Control
{
    public interface IColorPicker
    {
        Color SelectedColor { get; }
    }
}
