﻿
namespace GMap.NET
{
    using System;
    using Alt.IO;

    /// <summary>
    /// image abstraction proxy
    /// </summary>
    public abstract class PureImageProxy
    {
        abstract public PureImage FromStream(System.IO.Stream stream);
        abstract public bool Save(System.IO.Stream stream, PureImage image);

        public PureImage FromArray(byte[] data)
        {
            System.IO.MemoryStream m = new System.IO.MemoryStream(data, 0, data.Length, false, true);
            PureImage pi = FromStream(m);
            if (pi != null)
            {
                m.Position = 0;
                pi.Data = m;
            }
            else
            {
                m.Dispose();
            }
            m = null;

            return pi;
        }
    }

    /// <summary>
    /// image abstraction
    /// </summary>
    public abstract class PureImage : IDisposable
    {
        public System.IO.MemoryStream Data;

        internal bool IsParent;
        internal long Ix;
        internal long Xoff;
        internal long Yoff;

        #region IDisposable Members

        public abstract void Dispose();

        #endregion
    }
}
