﻿//  Original source code has been modified by AltSoftLab Inc. 2012-2015
//  This source code is provided "as is" without express or implied warranty of any kind.

using System;
using Alt.Runtime.Serialization;

using GMap.NET;

using Alt.Sketch.GMap.NET;
using Alt.Sketch.GMap.NET.Markers;


namespace Alt.Sketch.Demo.GMap.NET.CustomMarkers
{
    [Serializable]
    public class GMapMarkerRect : GMapMarker, ISerializable
    {
        [NonSerialized]
        public Pen Pen;

        [NonSerialized]
        public GMarkerGoogle InnerMarker;

        public GMapMarkerRect(PointLatLng p)
            : base(p)
        {
            Pen = new Pen(Brushes.Blue, 5);

            // do not forget set Size of the marker
            // if so, you shall have no event on it ;}
            Size = new SizeI(111, 111);
            Offset = new PointI(-Size.Width / 2, -Size.Height / 2);
        }

        public override void OnRender(Graphics g)
        {
            g.DrawRectangle(Pen, new RectI(LocalPosition.X, LocalPosition.Y, Size.Width, Size.Height));
        }

        public override void Dispose()
        {
            if (Pen != null)
            {
                Pen.Dispose();
                Pen = null;
            }

            if (InnerMarker != null)
            {
                InnerMarker.Dispose();
                InnerMarker = null;
            }

            base.Dispose();
        }

        //  ISerializable Members

        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            base.GetObjectData(info, context);
        }

        protected GMapMarkerRect(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        // 
    }
}
