﻿//  Original source code has been modified by AltSoftLab Inc. 2012-2015
//  This source code is provided "as is" without express or implied warranty of any kind.

using System.Collections.Generic;

#if !PocketPC
using Alt.Sketch.GMap.NET.Properties;
using System;
using Alt.Runtime.Serialization;
#else
   using GMap.NET.WindowsMobile.Properties;
#endif

using GMap.NET;
using Alt.Sketch;


namespace Alt.Sketch.GMap.NET.Markers
{
    public enum GMarkerGoogleType
    {
        none = 0,
        arrow,
        blue,
        blue_small,
        blue_dot,
        blue_pushpin,
        brown_small,
        gray_small,
        green,
        green_small,
        green_dot,
        green_pushpin,
        green_big_go,
        yellow,
        yellow_small,
        yellow_dot,
        yellow_big_pause,
        yellow_pushpin,
        lightblue,
        lightblue_dot,
        lightblue_pushpin,
        orange,
        orange_small,
        orange_dot,
        pink,
        pink_dot,
        pink_pushpin,
        purple,
        purple_small,
        purple_dot,
        purple_pushpin,
        red,
        red_small,
        red_dot,
        red_pushpin,
        red_big_stop,
        black_small,
        white_small,
    }


#if !PocketPC
    [Serializable]
    public class GMarkerGoogle : GMapMarker, ISerializable, IDeserializationCallback
#else
   public class GMarkerGoogle : GMapMarker
#endif
    {
        public float? Bearing;
        Bitmap Bitmap;
        Bitmap BitmapShadow;

        static Bitmap arrowshadow;
        static Bitmap msmarker_shadow;
        static Bitmap shadow_small;
        static Bitmap pushpin_shadow;

        GMarkerGoogleType type;

        public GMarkerGoogle(PointLatLng p, GMarkerGoogleType type)
            : base(p)
        {
            this.type = type;

            if (type != GMarkerGoogleType.none)
            {
                LoadBitmap();
            }
        }

        void LoadBitmap()
        {
            Bitmap = GetIcon(type.ToString());
            Size = new SizeI(Bitmap.PixelWidth, Bitmap.PixelHeight);

            switch (type)
            {
                case GMarkerGoogleType.arrow:
                    {
                        Offset = new PointI(-11, -Size.Height);

                        if (arrowshadow == null)
                        {
                            arrowshadow = GMap.NET.Properties.Resources.arrowshadow;
                        }
                        BitmapShadow = arrowshadow;
                    }
                    break;

                case GMarkerGoogleType.blue:
                case GMarkerGoogleType.blue_dot:
                case GMarkerGoogleType.green:
                case GMarkerGoogleType.green_dot:
                case GMarkerGoogleType.yellow:
                case GMarkerGoogleType.yellow_dot:
                case GMarkerGoogleType.lightblue:
                case GMarkerGoogleType.lightblue_dot:
                case GMarkerGoogleType.orange:
                case GMarkerGoogleType.orange_dot:
                case GMarkerGoogleType.pink:
                case GMarkerGoogleType.pink_dot:
                case GMarkerGoogleType.purple:
                case GMarkerGoogleType.purple_dot:
                case GMarkerGoogleType.red:
                case GMarkerGoogleType.red_dot:
                    {
                        Offset = new PointI(-Size.Width / 2 + 1, -Size.Height + 1);

                        if (msmarker_shadow == null)
                        {
                            msmarker_shadow = GMap.NET.Properties.Resources.msmarker_shadow;
                        }
                        BitmapShadow = msmarker_shadow;
                    }
                    break;

                case GMarkerGoogleType.black_small:
                case GMarkerGoogleType.blue_small:
                case GMarkerGoogleType.brown_small:
                case GMarkerGoogleType.gray_small:
                case GMarkerGoogleType.green_small:
                case GMarkerGoogleType.yellow_small:
                case GMarkerGoogleType.orange_small:
                case GMarkerGoogleType.purple_small:
                case GMarkerGoogleType.red_small:
                case GMarkerGoogleType.white_small:
                    {
                        Offset = new PointI(-Size.Width / 2, -Size.Height + 1);

                        if (shadow_small == null)
                        {
                            shadow_small = GMap.NET.Properties.Resources.shadow_small;
                        }
                        BitmapShadow = shadow_small;
                    }
                    break;

                case GMarkerGoogleType.green_big_go:
                case GMarkerGoogleType.yellow_big_pause:
                case GMarkerGoogleType.red_big_stop:
                    {
                        Offset = new PointI(-Size.Width / 2, -Size.Height + 1);
                        if (msmarker_shadow == null)
                        {
                            msmarker_shadow = GMap.NET.Properties.Resources.msmarker_shadow;
                        }
                        BitmapShadow = msmarker_shadow;
                    }
                    break;

                case GMarkerGoogleType.blue_pushpin:
                case GMarkerGoogleType.green_pushpin:
                case GMarkerGoogleType.yellow_pushpin:
                case GMarkerGoogleType.lightblue_pushpin:
                case GMarkerGoogleType.pink_pushpin:
                case GMarkerGoogleType.purple_pushpin:
                case GMarkerGoogleType.red_pushpin:
                    {
                        Offset = new PointI(-9, -Size.Height + 1);

                        if (pushpin_shadow == null)
                        {
                            pushpin_shadow = GMap.NET.Properties.Resources.pushpin_shadow;
                        }
                        BitmapShadow = pushpin_shadow;
                    }
                    break;
            }
        }

        /// <summary>
        /// marker using manual bitmap, NonSerialized
        /// </summary>
        /// <param name="p"></param>
        /// <param name="Bitmap"></param>
        public GMarkerGoogle(PointLatLng p, Bitmap Bitmap)
            : base(p)
        {
            this.Bitmap = Bitmap;
            Size = new SizeI(Bitmap.PixelWidth, Bitmap.PixelHeight);
            Offset = new PointI(-Size.Width / 2, -Size.Height);
        }

        static readonly Dictionary<string, Bitmap> iconCache = new Dictionary<string, Bitmap>();

        internal static Bitmap GetIcon(string name)
        {
            Bitmap ret;
            if (!iconCache.TryGetValue(name, out ret))
            {
                //ret = Resources.GetObject(name, Resources.Culture) as Bitmap;
                ret = GMap.NET.Properties.Resources.GetBitmap(name);
                iconCache.Add(name, ret);
            }
            return ret;
        }

        static readonly PointI[] Arrow = new PointI[] { new PointI(-7, 7), new PointI(0, -22), new PointI(7, 7), new PointI(0, 2) };

        public override void OnRender(Graphics g)
        {
#if !PocketPC
            //if(!Bearing.HasValue)
            {
                if (BitmapShadow != null)
                {
                    g.DrawImage(BitmapShadow, LocalPosition.X, LocalPosition.Y, BitmapShadow.PixelWidth, BitmapShadow.PixelHeight);
                }
            }

            //if(Bearing.HasValue)
            //{
            //   g.RotateTransform(Bearing.Value - Overlay.Control.Bearing);
            //   g.FillPolygon(Brushes.Red, Arrow);
            //}

            //if(!Bearing.HasValue)
            {
                g.DrawImage(Bitmap, LocalPosition.X, LocalPosition.Y, Size.Width, Size.Height);
            }
#else
         if(BitmapShadow != null)
         {
            DrawImageUnscaled(g, BitmapShadow, LocalPosition.X, LocalPosition.Y);
         }
         DrawImageUnscaled(g, Bitmap, LocalPosition.X, LocalPosition.Y);
#endif
        }

        public override void Dispose()
        {
            if (Bitmap != null)
            {
                if (!iconCache.ContainsValue(Bitmap))
                {
                    Bitmap.Dispose();
                    Bitmap = null;
                }
            }

            base.Dispose();
        }

#if !PocketPC

        // ISerializable Members

        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("type", this.type);
            info.AddValue("Bearing", this.Bearing);

            base.GetObjectData(info, context);
        }

        protected GMarkerGoogle(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
            this.type = Extensions.GetStruct<GMarkerGoogleType>(info, "type", GMarkerGoogleType.none);
            this.Bearing = Extensions.GetStruct<float>(info, "Bearing", null);
        }


        // IDeserializationCallback Members

        public void OnDeserialization(object sender)
        {
            if (type != GMarkerGoogleType.none)
            {
                LoadBitmap();
            }
        }

#endif
    }
}
