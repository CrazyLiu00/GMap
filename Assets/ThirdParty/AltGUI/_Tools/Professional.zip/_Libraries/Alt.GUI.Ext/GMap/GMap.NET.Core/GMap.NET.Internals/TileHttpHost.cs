﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Net.Sockets;
using Alt.Threading;
using System.Diagnostics;
using Alt.IO;
using GMap.NET.MapProviders;

namespace GMap.NET.Internals
{
    internal class TileHttpHost
    {
        volatile bool listen = false;
        TcpListener server;
        int port;

        readonly byte[] responseHeaderBytes;

        public TileHttpHost()
        {
            string response = "HTTP/1.0 200 OK\r\nContent-Type: image\r\nConnection: close\r\n\r\n";
            responseHeaderBytes = Encoding.ASCII.GetBytes(response);
        }

        public void Stop()
        {
            if (listen)
            {
                listen = false;
                if (server != null)
                {
                    server.Stop();
                }
            }
        }

        public void Start(int port)
        {
            if (server == null)
            {
                this.port = port;
                server = new TcpListener(IPAddress.Any, port);
            }
            else
            {
                if (this.port != port)
                {
                    Stop();
                    this.port = port;
                    server = null;
                    server = new TcpListener(IPAddress.Any, port);
                }
                else
                {
                    if (listen)
                    {
                        return;
                    }
                }
            }

            server.Start();
            listen = true;

            Thread t = new Thread(
                () =>
                {
                    Debug.WriteLine("TileHttpHost: " + server.LocalEndpoint);

                    while (listen)
                    {
                        try
                        {
                            if (!server.Pending())
                            {
                                Thread.Sleep(111);
                            }
                            else
                            {
                                System.Threading.ThreadPool.QueueUserWorkItem(new System.Threading.WaitCallback(ProcessRequest), server.AcceptTcpClient());
                            }
                        }
                        catch (Exception ex)
                        {
                            Debug.WriteLine("TileHttpHost: " + ex);
                        }
                    }

                    Debug.WriteLine("TileHttpHost: stoped");
                }
            );

            t.Name = "TileHost";
            t.IsBackground = true;
            t.Start();
        }

        void ProcessRequest(object p)
        {
            try
            {
                using (TcpClient c = p as TcpClient)
                {
                    using (NetworkStream s = c.GetStream())
                    {
                        using (System.IO.StreamReader r = new System.IO.StreamReader(s, Encoding.UTF8))
                        {
                            string request = r.ReadLine();

                            if (!string.IsNullOrEmpty(request) && request.StartsWith("GET"))
                            {
                                //Debug.WriteLine("TileHttpHost: " + request);

                                // http://localhost:88/88888/5/15/11
                                // GET /8888888888/5/15/11 HTTP/1.1

                                string[] rq = request.Split(' ');
                                if (rq.Length >= 2)
                                {
                                    string[] ids = rq[1].Split(new char[] { '/' }, StringSplitOptions.RemoveEmptyEntries);
                                    if (ids.Length == 4)
                                    {
                                        int dbId = int.Parse(ids[0]);
                                        int zoom = int.Parse(ids[1]);
                                        int x = int.Parse(ids[2]);
                                        int y = int.Parse(ids[3]);

                                        GMapProvider pr = GMapProviders.TryGetProvider(dbId);
                                        if (pr != null)
                                        {
                                            Exception ex;
                                            PureImage img = GMaps.Instance.GetImageFrom(pr, new GPoint(x, y), zoom, out ex);
                                            if (img != null)
                                            {
                                                using (img)
                                                {
                                                    s.Write(responseHeaderBytes, 0, responseHeaderBytes.Length);
                                                    img.Data.WriteTo(s);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    c.Close();
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("TileHttpHost, ProcessRequest: " + ex);
            }
            //Debug.WriteLine("disconnected");
        }
    }
}
