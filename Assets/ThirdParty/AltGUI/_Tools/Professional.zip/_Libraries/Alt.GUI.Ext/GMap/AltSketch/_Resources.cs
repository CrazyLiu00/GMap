﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

using Alt.Sketch;


namespace Alt.Sketch.GMap.NET.Properties
{
    class Resources
    {
        //  Maybe need dictionary

        public static Bitmap GetBitmap(string name)
        {
			//Assembly a = Assembly.GetExecutingAssembly();
            name = name.Replace('-', '_').Replace('.', '_');
            System.IO.Stream file = //a.GetManifestResourceStream("Alt.Sketch.Ext.GMap.NET.AltSketch.Resources." + name + ".png");
                IO.VirtualFile.OpenRead("AltData/GMap/" + name + ".png");
            if (file != null)
            {
                return Bitmap.FromStream(file);
            }

            return null;
        }


        public static Bitmap arrowshadow
        {
            get
            {
                return GetBitmap("arrowshadow");
            }
        }


        public static Bitmap msmarker_shadow
        {
            get
            {
                return GetBitmap("msmarker_shadow");
            }
        }


        public static Bitmap shadow_small
        {
            get
            {
                return GetBitmap("shadow_small");
            }
        }


        public static Bitmap pushpin_shadow
        {
            get
            {
                return GetBitmap("pushpin_shadow");
            }
        }
    }
}
