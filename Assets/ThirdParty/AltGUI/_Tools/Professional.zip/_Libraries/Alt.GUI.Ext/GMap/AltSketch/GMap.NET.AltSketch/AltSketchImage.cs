﻿//  Original source code has been modified by AltSoftLab Inc. 2012-2015
//  This source code is provided "as is" without express or implied warranty of any kind.

using System;
using System.Diagnostics;

using GMap.NET;
using GMap.NET.Internals;
using GMap.NET.MapProviders;

using Alt.IO;
using Alt.Sketch;


namespace Alt.Sketch.GMap.NET
{
    /// <summary>
    /// image abstraction
    /// </summary>
    public class AltSketchImage : PureImage
    {
        public Bitmap Img;

        public override void Dispose()
        {
            if (Img != null)
            {
                Img.Dispose();
                Img = null;
            }

            if (Data != null)
            {
                Data.Dispose();
                Data = null;
            }
        }
    }


    /// <summary>
    /// image abstraction proxy
    /// </summary>
    public class AltSketchImageProxy : PureImageProxy
    {
        AltSketchImageProxy()
        {

        }

        public static void Enable()
        {
            GMapProvider.TileImageProxy = Instance;
        }


        public static readonly AltSketchImageProxy Instance = new AltSketchImageProxy();

#if !PocketPC
        internal ColorMatrix ColorMatrix;
#endif

        static readonly bool Win7OrLater = Stuff.IsRunningOnWin7orLater();

        public override PureImage FromStream(System.IO.Stream stream)
        {
            AltSketchImage ret = null;
            try
            {
#if !PocketPC
                Bitmap m = Bitmap.FromStream(stream, true, Win7OrLater ? false : true);
#else
            Image m = new Bitmap(stream);
#endif
                if (m != null)
                {
                    ret = new AltSketchImage();
#if !PocketPC
                    ret.Img = ColorMatrix != null ? ApplyColorMatrix(m, ColorMatrix) : m;
#else
               ret.Img = m;
#endif
                }

            }
            catch (Exception ex)
            {
                ret = null;
                Debug.WriteLine("FromStream: " + ex.ToString());
            }

            return ret;
        }


        public override bool Save(System.IO.Stream stream, PureImage image)
        {
            AltSketchImage ret = image as AltSketchImage;
            bool ok = true;

            if (ret.Img != null)
            {
                // try png
                try
                {
                    ret.Img.Save(stream, ImageFormat.Png);
                }
                catch
                {
                    // try jpeg
                    try
                    {
                        stream.Seek(0, System.IO.SeekOrigin.Begin);
                        ret.Img.Save(stream, ImageFormat.Jpeg);
                    }
                    catch
                    {
                        ok = false;
                    }
                }
            }
            else
            {
                ok = false;
            }

            return ok;
        }


#if !PocketPC
        Bitmap ApplyColorMatrix(Bitmap original, ColorMatrix matrix)
        {
            // create a blank bitmap the same size as original
            Bitmap newBitmap = new Bitmap(original.PixelWidth, original.PixelHeight);

            using (original) // destroy original
            {
                // get a graphics object from the new image
                using (Graphics g = Graphics.FromImage(newBitmap))
                {
                    // set the color matrix attribute
                    using (ImageAttributes attributes = new ImageAttributes())
                    {
                        attributes.SetColorMatrix(matrix);
                        g.DrawImage(original, new RectI(0, 0, original.PixelWidth, original.PixelHeight), 0, 0, original.PixelWidth, original.PixelHeight, GraphicsUnit.Pixel, attributes);
                    }
                }
            }

            return newBitmap;
        }
#endif
    }
}
