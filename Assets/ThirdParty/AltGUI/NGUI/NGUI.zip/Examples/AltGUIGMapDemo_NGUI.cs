﻿//  Copyright (C) 2012-2015 AltSoftLab Inc.
//  This source code is provided "as is" without express or implied warranty of any kind.

using UnityEngine;
using UnityEngine.NGUI;


[AddComponentMenu("AltGUI/NGUI/Examples/GMap Demo")]
public class AltGUIGMapDemo_NGUI : AltGUIGMapDemo
{	
	AltGUIGMapNGUI GMap
	{
		get
		{
			return gameObject.GetComponent<AltGUIGMapNGUI>();
		}
	}


	// Use this for initialization
	void Start ()
	{
		AltGUIGMapNGUI map = GMap;
		if (map != null)
		{
			return;
		}

		map.Position = StartPosition;
	}
}
