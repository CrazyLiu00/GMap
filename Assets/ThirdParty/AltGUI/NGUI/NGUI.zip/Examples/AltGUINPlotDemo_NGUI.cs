﻿//  Copyright (C) 2012-2015 AltSoftLab Inc.
//  This source code is provided "as is" without express or implied warranty of any kind.

using UnityEngine;
using UnityEngine.NGUI;


[AddComponentMenu("AltGUI/NGUI/Examples/NPlot Demo")]
public class AltGUINPlotDemo_NGUI : AltGUINPlotDemo
{	
	AltGUINPlotNGUI NPlot
	{
		get
		{
			return gameObject.GetComponent<AltGUINPlotNGUI>();
		}
	}


	// Use this for initialization
	void Start ()
	{
		AltGUINPlotNGUI nPlot = NPlot;
		if (nPlot == null)
		{
			return;
		}

		Start(nPlot.PlotSurface);
	}
}
