﻿//  Copyright (C) 2012-2015 AltSoftLab Inc.
//  This source code is provided "as is" without express or implied warranty of any kind.

using UnityEngine;
using UnityEngine.NGUI;


[AddComponentMenu("AltGUI/NGUI/Examples/Awesomium Demo")]
public class AltGUIAwesomiumDemo_NGUI : AltGUIAwesomiumDemo
{	
	AltGUIAwesomiumNGUI Awesomium
	{
		get
		{
			return gameObject.GetComponent<AltGUIAwesomiumNGUI>();
		}
	}


	// Use this for initialization
	void Start ()
	{
		AltGUIAwesomiumNGUI awesomium = Awesomium;
		if (awesomium != null)
		{
		}
	}
}
