﻿//  Copyright (C) 2012-2015 AltSoftLab Inc.
//  This source code is provided "as is" without express or implied warranty of any kind.

using UnityEngine;
using UnityEngine.NGUI;


[AddComponentMenu("AltGUI/NGUI/Examples/3DPie Chart Demo")]
public class AltGUI3DPieChartDemo_NGUI : AltGUI3DPieChartDemo
{	
	AltGUI3DPieChartNGUI PieChart
	{
		get
		{
			return gameObject.GetComponent<AltGUI3DPieChartNGUI>();
		}
	}


	// Use this for initialization
	void Start ()
	{
		AltGUI3DPieChartNGUI pieChart = PieChart;
		if (pieChart == null)
		{
			return;
		}

		Start(pieChart.PieChartControl);
	}
}
