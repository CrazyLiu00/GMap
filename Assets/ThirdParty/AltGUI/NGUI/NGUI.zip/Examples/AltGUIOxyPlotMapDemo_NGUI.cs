﻿//  Copyright (C) 2012-2015 AltSoftLab Inc.
//  This source code is provided "as is" without express or implied warranty of any kind.

using UnityEngine;
using UnityEngine.NGUI;

using OxyPlot;
using OxyPlot.Annotations;
using OxyPlot.Axes;
using OxyPlot.Series;


[AddComponentMenu("AltGUI/NGUI/Examples/OxyPlot Map Demo")]
public class AltGUIOxyPlotMapDemo_NGUI : AltGUIOxyPlotMapDemo
{	
	AltGUIOxyPlotNGUI OxyPlot
	{
		get
		{
			return gameObject.GetComponent<AltGUIOxyPlotNGUI>();
		}
	}


	// Use this for initialization
	void Start ()
	{
		AltGUIOxyPlotNGUI oxyPlot = OxyPlot;
		if (oxyPlot == null)
		{
			return;
		}

		PlotModel model =
			TileMapAnnotation_openstreetmap_org();
			//TileMapAnnotation_statkart_no();
		
		oxyPlot.PlotModel = model;
		oxyPlot.Plot.ClientBackColor = model.Background != null ?
			Alt.Sketch.Ext.OxyPlot.ConverterExtensions.ToColor(model.Background) : Alt.Sketch.Color.FromArgb(128, Alt.Sketch.Color.WhiteSmoke);
	}
}
