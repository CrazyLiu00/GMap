﻿//  Copyright (C) 2012-2015 AltSoftLab Inc.
//  This source code is provided "as is" without express or implied warranty of any kind.

using UnityEngine;
using UnityEngine.NGUI;


[AddComponentMenu("AltGUI/NGUI/Examples/RichTextBox Demo")]
public class AltGUIRichTextBoxDemo_NGUI : AltGUIRichTextBoxDemo
{	
	AltGUIRichTextBoxNGUI RichTextBox
	{
		get
		{
			return gameObject.GetComponent<AltGUIRichTextBoxNGUI>();
		}
	}


	// Use this for initialization
	void Start ()
	{
		AltGUIRichTextBoxNGUI richTextBox = RichTextBox;
		if (richTextBox == null)
		{
			return;
		}

		richTextBox.LoadRTF(FileName);
	}
}
