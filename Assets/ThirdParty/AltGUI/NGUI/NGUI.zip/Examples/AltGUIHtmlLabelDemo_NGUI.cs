﻿//  Copyright (C) 2012-2015 AltSoftLab Inc.
//  This source code is provided "as is" without express or implied warranty of any kind.

using UnityEngine;
using UnityEngine.NGUI;


[AddComponentMenu("AltGUI/NGUI/Examples/HtmlLabel Demo")]
public class AltGUIHtmlLabelDemo_NGUI : AltGUIHtmlLabelDemo
{	
	AltGUIHtmlLabelNGUI HtmlLabel
	{
		get
		{
			return gameObject.GetComponent<AltGUIHtmlLabelNGUI>();
		}
	}


	// Use this for initialization
	void Start ()
	{
		AltGUIHtmlLabelNGUI htmlLabel = HtmlLabel;
		if (htmlLabel == null)
		{
			return;
		}

		htmlLabel.Text = HTMLText;

		//	Just because source html has black text as main - and it seems not good
		if (htmlLabel.HtmlLabel != null)
		{
			htmlLabel.HtmlLabel.BackColor = Alt.Sketch.Color.FromArgb(128, Alt.Sketch.Color.White);
		}
	}
}
