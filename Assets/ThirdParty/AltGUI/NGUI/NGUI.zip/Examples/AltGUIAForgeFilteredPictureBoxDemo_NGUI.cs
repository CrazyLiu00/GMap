﻿//  Copyright (C) 2012-2015 AltSoftLab Inc.
//  This source code is provided "as is" without express or implied warranty of any kind.

using UnityEngine;
using UnityEngine.NGUI;


[AddComponentMenu("AltGUI/NGUI/Examples/AForge Filtered PictureBox Demo")]
public class AltGUIAForgeFilteredPictureBoxDemo_NGUI : AltGUIAForgeFilteredPictureBoxDemo
{	
	AltGUIAForgeFilteredPictureBoxNGUI AForgeFilteredPictureBox
	{
		get
		{
			return gameObject.GetComponent<AltGUIAForgeFilteredPictureBoxNGUI>();
		}
	}


	protected override Alt.Sketch.ImageSource Image
	{
		set
		{
			AltGUIAForgeFilteredPictureBoxNGUI pictureBox = AForgeFilteredPictureBox;
			if (pictureBox == null)
			{
				return;
			}

			pictureBox.Image = value;
		}
	}
	
	protected override Alt.GUI.PictureBoxSizeMode SizeMode
	{
		set
		{
			AltGUIAForgeFilteredPictureBoxNGUI pictureBox = AForgeFilteredPictureBox;
			if (pictureBox == null)
			{
				return;
			}

			pictureBox.SizeMode = value;
		}
	}
	
	protected override Alt.GUI.AForge.ImageFilterType ImageFilter
	{
		get
		{
			AltGUIAForgeFilteredPictureBoxNGUI pictureBox = AForgeFilteredPictureBox;
			if (pictureBox == null)
			{
				return Alt.GUI.AForge.ImageFilterType.None;
			}

			return pictureBox.ImageFilter;
		}
		set
		{
			AltGUIAForgeFilteredPictureBoxNGUI pictureBox = AForgeFilteredPictureBox;
			if (pictureBox == null)
			{
				return;
			}

			pictureBox.ImageFilter = value;
		}
	}
}
