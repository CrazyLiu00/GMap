﻿//  Copyright (C) 2012-2015 AltSoftLab Inc.
//  This source code is provided "as is" without express or implied warranty of any kind.

using UnityEngine;
using UnityEngine.NGUI;


[AddComponentMenu("AltGUI/NGUI/Examples/Farseer Physics Demo")]
public class AltGUIFarseerPhysicsDemo_NGUI : AltGUIFarseerPhysicsDemo
{	
	AltGUIFarseerPhysicsNGUI FarseerPhysics
	{
		get
		{
			return gameObject.GetComponent<AltGUIFarseerPhysicsNGUI>();
		}
	}
	
	
	protected override void Invalidate()
	{
		AltGUIFarseerPhysicsNGUI farseerPhysics = FarseerPhysics;
		if (farseerPhysics == null)
		{
			return;
		}
		
		farseerPhysics.Invalidate();
	}


	protected override Alt.Sketch.Size ClientSize
	{
		get
		{
			AltGUIFarseerPhysicsNGUI farseerPhysics = FarseerPhysics;
			if (farseerPhysics == null)
			{
				return Alt.Sketch.Size.One;
			}
			
			return farseerPhysics.ClientSize;
		}
	}


	// Use this for initialization
	void Start ()
	{
		AltGUIFarseerPhysicsNGUI farseerPhysics = FarseerPhysics;
		if (farseerPhysics == null)
		{
			return;
		}

		farseerPhysics.onPaint.AddListener(FarseerPhysics_onPaint);
		
		farseerPhysics.onFarseerPhysicsMouseDown.AddListener(FarseerPhysics_onMouseDown);
		farseerPhysics.onFarseerPhysicsMouseUp.AddListener(FarseerPhysics_onMouseUp);
		farseerPhysics.onFarseerPhysicsMouseMove.AddListener(FarseerPhysics_onMouseMove);
		farseerPhysics.onMouseWheel.AddListener(FarseerPhysics_onMouseWheel);

		farseerPhysics.onFarseerPhysicsKeyDown.AddListener(FarseerPhysics_onKeyDown);
		farseerPhysics.onFarseerPhysicsKeyDown.AddListener(FarseerPhysics_onKeyDown);

		farseerPhysics.onFarseerPhysicsEnableOrDisableFlag.AddListener(FarseerPhysics_onFarseerPhysicsEnableOrDisableFlag);

		farseerPhysics.onFarseerPhysicsRestartEvent.AddListener(FarseerPhysics_onRestart);

		Initialize ();
	}
}
