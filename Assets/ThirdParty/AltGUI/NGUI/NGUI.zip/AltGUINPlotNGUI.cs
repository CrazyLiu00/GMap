//  Copyright (C) 2012-2015 AltSoftLab Inc.
//  This source code is provided "as is" without express or implied warranty of any kind.

using System;
using System.Collections.Generic;
using System.Text;

using Alt.GUI;
using Alt.Sketch;


namespace UnityEngine.NGUI
{
    /// <summary>
	/// AltGUI NPlot Control.
    /// </summary>

	[AddComponentMenu(AltGUIIntegration.EditorComponentMenuPathNGUI + AltGUINPlotNGUI.EditorName, AltGUINPlotNGUI.EditorID)]
	public class AltGUINPlotNGUI
		: AltGUIControlHostNGUI
    {
		new public const string EditorName = UI.AltGUINPlot.EditorName;
		new public const int EditorID = UI.AltGUINPlot.EditorID;
		
		
		#if UNITY_EDITOR
		internal override string GetEditorName()
		{
			return EditorName;
		}
		#endif


		public Alt.GUI.NPlot.Temporary.Gwen.PlotSurface2DControl PlotSurface
		{
			get
			{
				return GwenChild as Alt.GUI.NPlot.Temporary.Gwen.PlotSurface2DControl;
			}
		}
		
		
		protected override void OnStart ()
		{
			base.OnStart ();

			GwenChild = AltGUIHelper.Create_NPlotSurface(GetOrCreateGwenCanvas());
		}
	
	
		public void SetPlotDefaultBackColor()
		{
			Alt.GUI.NPlot.Temporary.Gwen.PlotSurface2DControl plotSurface = PlotSurface;
			if (plotSurface == null)
			{
				return;
			}
			
			AltGUIHelper.SetNPlotSurfaceDefaultBackColor(plotSurface);
		}


		public void SetPlotBackColor(Alt.Sketch.Color color)
		{
			Alt.GUI.NPlot.Temporary.Gwen.PlotSurface2DControl plotSurface = PlotSurface;
			if (plotSurface == null)
			{
				return;
			}
			
			plotSurface.ClientBackColor = color;
		}
	}
}
