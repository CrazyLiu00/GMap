//  Copyright (C) 2012-2015 AltSoftLab Inc.
//  This source code is provided "as is" without express or implied warranty of any kind.

using System;
using System.Collections.Generic;
using System.Text;

using Alt.GUI;
using Alt.Sketch;


namespace UnityEngine.NGUI
{
    /// <summary>
	/// AltGUI SVG Viewer.
    /// </summary>

	[AddComponentMenu(AltGUIIntegration.EditorComponentMenuPathNGUI + AltGUISvgNGUI.EditorName, AltGUISvgNGUI.EditorID)]
	public class AltGUISvgNGUI
		: AltGUIControlHostNGUI
    {
		new public const string EditorName = UI.AltGUISvg.EditorName;
		new public const int EditorID = UI.AltGUISvg.EditorID;
		
		
		#if UNITY_EDITOR
		internal override string GetEditorName()
		{
			return EditorName;
		}
		#endif
		
		
		AltGUIHelper.SVGControl SVGControl
		{
			get
			{
				return Child as AltGUIHelper.SVGControl;
			}
		}

		
		protected override void OnStart ()
		{
			base.OnStart ();

			Child = AltGUIHelper.Create_SVGControl();
		}

				
		public void LoadSVG(string fileName)
		{
			AltGUIHelper.SVGControl svg = SVGControl;
			if (svg == null)
			{
				return;
			}

			svg.LoadSVG(fileName);
		}
	}
}
