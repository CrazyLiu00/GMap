//  Copyright (C) 2012-2015 AltSoftLab Inc.
//  This source code is provided "as is" without express or implied warranty of any kind.

#if !UNITY_EDITOR && (UNITY_IPHONE || UNITY_ANDROID || UNITY_WP8 || UNITY_WP_8_1 || UNITY_BLACKBERRY)
#define MOBILE
#endif

using System.Collections.Generic;
using System.Text;

using UnityEngine;
using UnityEngine.NGUI;

using Alt.GUI;


namespace UnityEngine.NGUI
{
	partial class AltGUIControlHostNGUI
	{
		bool m_fMouseIn = false;


		/// <summary>
		/// Currently active input field. Only valid during callbacks.
		/// </summary>

		public static AltGUIControlHostNGUI current;

		/// <summary>
		/// Currently selected input field, if any.
		/// </summary>

		public static AltGUIControlHostNGUI selection;

		/// <summary>
		/// Whether the input will be hidden on mobile platforms.
		/// </summary>

		public bool hideInput = false;


		static protected int mDrawStart = 0;
		static protected string mLastIME = "";

	#if MOBILE
		// Unity fails to compile if the touch screen keyboard is used on a non-mobile device
		static protected TouchScreenKeyboard mKeyboard;
		static bool mWaitForKeyboard = false;
	#endif
		[System.NonSerialized] protected int mSelectMe = -1;

		/// <summary>
		/// Whether the input is currently selected.
		/// </summary>

		public bool isSelected
		{
			get
			{
				return selection == this;
			}
			set
			{
				if (!value)
				{
					if (isSelected) UICamera.selectedObject = null;
				}
				else
				{
					UICamera.selectedObject = gameObject;
				}
			}
		}



		Alt.Sketch.Point ToLocation(Ray ray)
		{
			Vector3[] corners = worldCorners;
			Plane p = new Plane(corners[0], corners[1], corners[2]);
			
			float dist;
			Vector3 worldPos = p.Raycast(ray, out dist) ? ray.GetPoint(dist) : new Vector3();
			
			Vector2 localPos = cachedTransform.InverseTransformPoint(worldPos);
			
			corners = localCorners;
			return new Alt.Sketch.Point(localPos.x - corners[1].x, corners[1].y - localPos.y);
		}
		
		internal Alt.Sketch.Point TouchPosition
		{
			get
			{
				return ToLocation(UICamera.currentRay);
			}
		}
		
		internal Alt.Sketch.Point MousePosition
		{
			get
			{
				Camera currentCamera = UICamera.currentCamera;
				return ToLocation((currentCamera != null) ? currentCamera.ScreenPointToRay(Input.mousePosition) : new Ray());
			}
		}


		void OnScroll (float delta)
		{			
			#if UNITY_EDITOR
			if (!Application.isPlaying)
			{
				return;
			}
			#endif
			
			if (m_fMouseIn)
			{
				RaiseMouseWheel(new MouseEventArgs(MousePosition, delta * 120 * 6));
			}
		}


		void OnHover (bool isOver)
		{
			#if UNITY_EDITOR
			if (!Application.isPlaying)
			{
				return;
			}
			#endif

			if (isOver)
			{
				if (!m_fMouseIn)
				{
					m_fMouseIn = true;
					RaiseMouseEnter(new MouseEventArgs(MousePosition));
				}
			}
			else
			{
				if (m_fMouseIn)
				{
					m_fMouseIn = false;
					RaiseMouseLeave(new MouseEventArgs(MousePosition));
				}
			}
		}


	#if !MOBILE
		[System.NonSerialized] AltGUIControlHostNGUI_InputOnGUI mOnGUI;
	#endif
		/// <summary>
		/// Selection event, sent by the EventSystem.
		/// </summary>

		protected virtual void OnSelect (bool isSelected)
		{
			if (isSelected)
			{
	#if !MOBILE
				if (mOnGUI == null)
				{
					mOnGUI = gameObject.AddComponent<AltGUIControlHostNGUI_InputOnGUI>();
				}
	#endif
				OnSelectEvent();
			}
			else
			{
	#if !MOBILE
				if (mOnGUI != null)
				{
					Destroy(mOnGUI);
					mOnGUI = null;
				}
	#endif
				OnDeselectEvent();
			}
				
			if (enabled && (!isSelected || UICamera.currentScheme == UICamera.ControlScheme.Controller))
				OnHover(isSelected);
		}

		/// <summary>
		/// Notification of the input field gaining selection.
		/// </summary>

		protected void OnSelectEvent ()
		{
			selection = this;

			// Unity has issues bringing up the keyboard properly if it's in "hideInput" mode and you happen
			// to select one input in the same Update as de-selecting another.
			if (NGUITools.GetActive(this))
			{
				mSelectMe = Time.frameCount;
			}

			if (Child != null)
			{
				Child.Focus();
			}
		}


		/// <summary>
		/// Notification of the input field losing selection.
		/// </summary>

		protected void OnDeselectEvent ()
		{
			selection = null;
		}

		
		
		Vector2 m_PreviousMousePosition = new Vector2(-1, -1);

		/// <summary>
		/// Update the text based on input.
		/// </summary>
		
		void ProcessEvents()
		{
	#if UNITY_EDITOR
			if (!Application.isPlaying)
			{
				return;
			}
	#endif


			//	Mouse

			Vector2 mousePosition = Input.mousePosition;
			
			//	Move
			if (m_PreviousMousePosition != mousePosition)
			{
				if (m_PreviousMousePosition.x < 0 && m_PreviousMousePosition.y < 0)
				{
					m_PreviousMousePosition = mousePosition;
					return;
				}
				
				m_PreviousMousePosition = mousePosition;
				
				if (m_fMouseIn)
				{
					RaiseMouseMove(new MouseEventArgs(MousePosition));
				}
			}
			

			//	Keyboard
			
			if (isSelected)
			{
				UnityEngine.KeyCode[] oldKeys = m_OldKeyboardState;
				UnityEngine.KeyCode[] newKeys = Alt.GUI.UnityHelper.GetPressedKeys();
				
				// if no input, skip the rest
				if ((oldKeys.Length != 0) || (newKeys.Length != 0))
				{
					bool isShiftKeyDown = Alt.GUI.UnityHelper.IsShiftKeyDown();
					
					UnityEngine.KeyCode[] addedKeys = Alt.GUI.UnityHelper.FindAddedKeys(oldKeys, newKeys);
					if (addedKeys.Length != 0)
					{
						DoPressed(addedKeys, isShiftKeyDown);
					}
					else
					{
						DoAutoRepeat(isShiftKeyDown);
					}
					
					DoReleased(Alt.GUI.UnityHelper.FindAddedKeys(newKeys, oldKeys));
					
					m_OldKeyboardState = newKeys;
				}

				if (Input.anyKeyDown)
				{
					foreach (char ch in Input.inputString)
					{
						if (UnityHelper.IsInputChar(ch))
						{
							RaiseKeyPress(new Alt.GUI.KeyPressEventArgs(ch));
						}
					}
				}
			}
		}


	#if !MOBILE
		/// <summary>
		/// Handle the specified event.
		/// </summary>

		public virtual bool ProcessEvent (Event ev)
		{
			/*TEMP
			RuntimePlatform rp = Application.platform;

			bool isMac = (
				rp == RuntimePlatform.OSXEditor ||
				rp == RuntimePlatform.OSXPlayer ||
				rp == RuntimePlatform.OSXWebPlayer);

			bool ctrl = isMac ?
				((ev.modifiers & EventModifiers.Command) != 0) :
				((ev.modifiers & EventModifiers.Control) != 0);

			// http://www.tasharen.com/forum/index.php?topic=10780.0
			if ((ev.modifiers & EventModifiers.Alt) != 0) ctrl = false;

			bool shift = ((ev.modifiers & EventModifiers.Shift) != 0);*/

			return false;
		}
	#endif


		/// <summary>
		/// Move the caret on press.
		/// </summary>

		protected virtual void OnPress (bool isPressed)
		{
			#if UNITY_EDITOR
			if (!Application.isPlaying)
			{
				return;
			}
			#endif
			
			if (UICamera.currentScheme == UICamera.ControlScheme.Mouse)
			{
				//Vector2 pos = ScreenToLocalOatLeftTop(eventData.position);                
				//RaiseMouseDown(UnityHelper.ToMouseEventArgs(eventData, pos));
				
				if (isPressed)
				{
					//	Left
					if (Input.GetMouseButtonDown(0)) RaiseMouseDown(new Alt.GUI.MouseEventArgs(Alt.GUI.MouseButtons.Left, MousePosition));

					//	Right
					if (Input.GetMouseButtonDown(1)) RaiseMouseDown(new Alt.GUI.MouseEventArgs(Alt.GUI.MouseButtons.Right, MousePosition));

					//	Middle
					if (Input.GetMouseButtonDown(2)) RaiseMouseDown(new Alt.GUI.MouseEventArgs(Alt.GUI.MouseButtons.Middle, MousePosition));
				}
				else
				{
					//	Left
					if (Input.GetMouseButtonUp(0)) RaiseMouseUp(new Alt.GUI.MouseEventArgs(Alt.GUI.MouseButtons.Left, MousePosition));
					
					//	Right
					if (Input.GetMouseButtonUp(1)) RaiseMouseUp(new Alt.GUI.MouseEventArgs(Alt.GUI.MouseButtons.Right, MousePosition));
					
					//	Middle
					if (Input.GetMouseButtonUp(2)) RaiseMouseUp(new Alt.GUI.MouseEventArgs(Alt.GUI.MouseButtons.Middle, MousePosition));
				}
			}			
			else if (UICamera.currentScheme == UICamera.ControlScheme.Touch)
			{
				//Vector2 pos = ScreenToLocalOatLeftTop(eventData.position);                
				//RaiseMouseDown(UnityHelper.ToMouseEventArgs(eventData, pos));
				
				if (isPressed)
				{
					RaiseMouseDown(new MouseEventArgs(MouseButtons.Left, MousePosition));
				}
				else
				{
					RaiseMouseUp(new MouseEventArgs(MouseButtons.Left, MousePosition));
				}
			}
		}


		/// <summary>
		/// Convenience function to be used as a callback that will clear the input field's focus.
		/// </summary>

		public void RemoveFocus ()
		{
			isSelected = false;
		}



		protected UnityEngine.KeyCode[] m_OldKeyboardState = new KeyCode[0];
		int autoRepeatDelay = 20;//msec
		bool autoRepeatStarted = false;
		List<UnityEngine.KeyCode> autoRepeatKeys = new List<UnityEngine.KeyCode>();
		int autoRepeatTimeElapsed = 0;
		
		protected int AutoRepeatDelay
		{
			get
			{
				return autoRepeatDelay;
			}
			set
			{
				autoRepeatDelay = value;
			}
		}
		
		
		protected void DoPressed(UnityEngine.KeyCode[] pressed, bool shiftDown)
		{
			if (pressed.Length > 0)
			{
				ClearAutoRepeat();
				autoRepeatKeys.AddRange(pressed);
			}
			
			DoPress(pressed, shiftDown);
		}
		void DoPress(IEnumerable<UnityEngine.KeyCode> pressed, bool shiftDown)
		{
			foreach (UnityEngine.KeyCode k in pressed)
			{
				RaiseKeyDown(new Alt.GUI.KeyEventArgs(Alt.GUI.UnityHelper.TranslateKeyCode(k)));
				
				//InjectChar(k, shiftDown);
			}
		}
		
		protected void DoReleased(UnityEngine.KeyCode[] released)
		{
			if (released.Length > 0)
			{
				ClearAutoRepeat();
			}
			
			foreach (UnityEngine.KeyCode k in released)
			{
				RaiseKeyUp(new Alt.GUI.KeyEventArgs(Alt.GUI.UnityHelper.TranslateKeyCode(k)));
			}
		}
		
		Alt.IntervalTimer m_DoAutoRepeatIntervalTimer;
		Alt.IntervalTimer DoAutoRepeatIntervalTimer
		{
			get
			{
				if (m_DoAutoRepeatIntervalTimer == null)
				{
					m_DoAutoRepeatIntervalTimer = new Alt.IntervalTimer();
					m_DoAutoRepeatIntervalTimer.Start();
				}
				
				return m_DoAutoRepeatIntervalTimer;
			}
		}
		protected void DoAutoRepeat(bool shiftDown)
		{
			autoRepeatTimeElapsed += (int)DoAutoRepeatIntervalTimer.ElapsedTimeMSec;
			DoAutoRepeatIntervalTimer.Reset();
			
			bool repeat = false;
			if (autoRepeatStarted)
			{
				repeat = autoRepeatTimeElapsed >= AutoRepeatDelay;
			}
			else
			{
				repeat = autoRepeatTimeElapsed >= 500;
			}
			
			if (repeat)
			{
				autoRepeatStarted = true;
				autoRepeatTimeElapsed = 0;
				
				DoPress(autoRepeatKeys, shiftDown);
			}
		}
		
		protected void ClearAutoRepeat()
		{
			autoRepeatKeys.Clear();
			autoRepeatTimeElapsed = 0;
			DoAutoRepeatIntervalTimer.Reset();
			autoRepeatStarted = false;
		}
	}
}
