//  Copyright (C) 2012-2015 AltSoftLab Inc.
//  This source code is provided "as is" without express or implied warranty of any kind.

using System;
using System.Collections.Generic;

using Alt;
using Alt.Backend.Unity;
using Alt.GUI;
using Alt.Sketch;


namespace UnityEngine.NGUI
{
	/// <summary>
	/// AltSketch Painting Control.
	/// </summary>

	[ExecuteInEditMode]
	[AddComponentMenu(AltGUIIntegration.EditorComponentMenuPathNGUI + AltSketchPaintNGUI.EditorName, AltSketchPaintNGUI.EditorID)]
	public class AltSketchPaintNGUI : UIBasicSprite, IDisposable
	{
		public const string EditorName = UI.AltSketchPaint.EditorName;
		public const int EditorID = UI.AltSketchPaint.EditorID;
		
		
		#if UNITY_EDITOR
		internal virtual string GetEditorName()
		{
			return EditorName;
		}
		#endif


		class AltSketchPaintHandlerNGUI : AltSketchPaintHandler
		{
			AltSketchPaintNGUI m_Paint;


			internal AltSketchPaintHandlerNGUI(AltSketchPaintNGUI paint)
			{
				m_Paint = paint;
			}
			
			
			protected override Alt.Sketch.Rendering.RenderType RenderType
			{
				get
				{
					return m_Paint.RenderType;
				}
			}
			
			protected override Alt.Sketch.SizeI Size
			{
				get
				{
					return m_Paint.ClientSize.ToSizeI();
				}
			}
			
			
			protected override void RefreshMaterial()
			{
				m_Paint.mainTexture = mainTexture;//RefreshMaterial = true;
			}
			
			protected override void RefreshVertices()
			{
				m_Paint.MarkAsChanged();//RefreshVertices = true;
			}
			
			
			protected override void DoPaint(Alt.GUI.PaintEventArgs e)
			{
				m_Paint.DoPaint(e);
			}
		}
		
		
		AltSketchPaintHandler m_AltSketchPaintHandler;
		AltSketchPaintHandler AltSketchPaintHandler
		{
			get
			{
				if (m_AltSketchPaintHandler == null)
				{
					m_AltSketchPaintHandler = new AltSketchPaintHandlerNGUI(this);
					
					Invalidate();
				}
				
				return m_AltSketchPaintHandler;
			}
		}
		
		
		protected override void OnStart ()
		{
			AltGUIIntegration.Initialize();

			Invalidate();
			
			base.OnStart ();
		}
		
		
		/// <summary>
		/// Disposes the RenderBox.
		/// </summary>
		/// <param name="disposing">Whether Dispose has been called.</param>
		public virtual void Dispose()
		{
			if (m_AltSketchPaintHandler != null)
			{
				m_AltSketchPaintHandler.Dispose();
				m_AltSketchPaintHandler = null;
			}
		}
				
		protected virtual void OnDestroy()
		{
			if (m_AltSketchPaintHandler != null)
			{
				m_AltSketchPaintHandler.Dispose();
				m_AltSketchPaintHandler = null;
			}
		}

		
		[SerializeField]
		Alt.Sketch.Rendering.RenderType m_RenderType = Alt.Sketch.Rendering.RenderType.Software;
		public Alt.Sketch.Rendering.RenderType RenderType
		{
			get
			{
				return m_RenderType;
			}
			set
			{
				if (m_RenderType == value)
				{
					return;
				}
				
				m_RenderType = value;
				
				Invalidate();
			}
		}
		
		
		IntervalTimer m_RenderUpdateTimer = new IntervalTimer(1000 / UnityEngine.AltSketchPaintHandler.DefaultMaximumFPS);
		[SerializeField]
		int m_MaxFPS = UnityEngine.AltSketchPaintHandler.DefaultMaximumFPS;
		public int MaxFPS
		{
			get
			{
				return m_MaxFPS;
			}
			set
			{
				if (m_MaxFPS == value)
				{
					return;
				}
				
				m_MaxFPS = value;
				
				m_RenderUpdateTimer.Interval = 1000 / m_MaxFPS;
			}
		}
		
		
		public double RealFPS
		{
			get
			{
				return AltSketchPaintHandler.RealFPS;
			}
		}
		
		
		/// <summary>
		/// UV rectangle used by the texture.
		/// </summary>
		public UnityEngine.Rect UVRect
		{
			get
			{
				return AltSketchPaintHandler.UVRect;
			}
		}
		
		
		#if UNITY_EDITOR
		// This is Unity's own OnValidate method which is invoked when changing values in the Inspector.
		protected override void OnValidate()
		{
			base.OnValidate();
			
			m_RenderUpdateTimer.Interval = 1000 / m_MaxFPS;
			
			Invalidate();
		}		
		#endif
		


		[HideInInspector][SerializeField] Material mMat;
		[HideInInspector][SerializeField] Shader mShader;
		[HideInInspector][SerializeField] Vector4 mBorder = Vector4.zero;

		[System.NonSerialized] int mPMA = -1;


		/// <summary>
		/// Texture used by the AltSketchPaintNGUI. You can set it directly, without the need to specify a material.
		/// </summary>

		public override Texture mainTexture
		{
			get
			{
				DoRenderIfNeed();
				
				Texture mTexture = AltSketchPaintHandler.mainTexture;

				if (mTexture != null)
				{
					return mTexture;
				}

				if (mMat != null)
				{
					return mMat.mainTexture;
				}

				return null;
			}
			set
			{
				if (drawCall != null &&
				    drawCall.widgetCount == 1 &&
				    mMat == null)
				{
					drawCall.mainTexture = value;
				}
				else
				{
					RemoveFromPanel();
					mPMA = -1;
					MarkAsChanged();
				}
			}
		}


		/// <summary>
		/// Material used by the widget.
		/// </summary>

		public override Material material
		{
			get
			{
				return mMat;
			}
			set
			{
				if (mMat != value)
				{
					RemoveFromPanel();
					mShader = null;
					mMat = value;
					mPMA = -1;
					MarkAsChanged();
				}
			}
		}


		/// <summary>
		/// Shader used by the texture when creating a dynamic material (when the texture was specified, but the material was not).
		/// </summary>

		public override Shader shader
		{
			get
			{
				if (mMat != null)
				{
					return mMat.shader;
				}

				if (mShader == null)
				{
					mShader = Shader.Find("Unlit/Transparent Colored");
				}

				return mShader;
			}
			set
			{
				if (mShader != value)
				{
					if (drawCall != null && drawCall.widgetCount == 1 && mMat == null)
					{
						mShader = value;
						drawCall.shader = value;
					}
					else
					{
						RemoveFromPanel();
						mShader = value;
						mPMA = -1;
						mMat = null;
						MarkAsChanged();
					}
				}
			}
		}


		/// <summary>
		/// Whether the texture is using a premultiplied alpha material.
		/// </summary>

		public override bool premultipliedAlpha
		{
			get
			{
				if (mPMA == -1)
				{
					Material mat = material;
					mPMA = (mat != null && mat.shader != null && mat.shader.name.Contains("Premultiplied")) ? 1 : 0;
				}

				return (mPMA == 1);
			}
		}


		/// <summary>
		/// Sprite's border. X = left, Y = bottom, Z = right, W = top.
		/// </summary>

		public override Vector4 border
		{
			get
			{
				return mBorder;
			}
			set
			{
				if (mBorder != value)
				{
					mBorder = value;
					MarkAsChanged();
				}
			}
		}


		/// <summary>
		/// Widget's dimensions used for drawing. X = left, Y = bottom, Z = right, W = top.
		/// This function automatically adds 1 pixel on the edge if the texture's dimensions are not even.
		/// It's used to achieve pixel-perfect sprites even when an odd dimension widget happens to be centered.
		/// </summary>

		public override Vector4 drawingDimensions
		{
			get
			{
				Vector2 offset = pivotOffset;

				float x0 = -offset.x * mWidth;
				float y0 = -offset.y * mHeight;
				float x1 = x0 + mWidth;
				float y1 = y0 + mHeight;

				Texture mTexture = mainTexture;

				if (mTexture != null &&
				    mType != UISprite.Type.Tiled)
				{
					int w = mTexture.width;
					int h = mTexture.height;
					int padRight = 0;
					int padTop = 0;

					float px = 1f;
					float py = 1f;

					if (w > 0 && h > 0 && (mType == UISprite.Type.Simple || mType == UISprite.Type.Filled))
					{
						if ((w & 1) != 0) ++padRight;
						if ((h & 1) != 0) ++padTop;

						px = (1f / w) * mWidth;
						py = (1f / h) * mHeight;
					}

					if (mFlip == UISprite.Flip.Horizontally || mFlip == UISprite.Flip.Both)
					{
						x0 += padRight * px;
					}
					else
					{
						x1 -= padRight * px;
					}

					if (mFlip == UISprite.Flip.Vertically || mFlip == UISprite.Flip.Both)
					{
						y0 += padTop * py;
					}
					else
					{
						y1 -= padTop * py;
					}
				}

				Vector4 br = border;
				float fw = br.x + br.z;
				float fh = br.y + br.w;

				float vx = Mathf.Lerp(x0, x1 - fw, mDrawRegion.x);
				float vy = Mathf.Lerp(y0, y1 - fh, mDrawRegion.y);
				float vz = Mathf.Lerp(x0 + fw, x1, mDrawRegion.z);
				float vw = Mathf.Lerp(y0 + fh, y1, mDrawRegion.w);

				return new Vector4(vx, vy, vz, vw);
			}
		}


		/// <summary>
		/// Adjust the scale of the widget to make it pixel-perfect.
		/// </summary>

		public override void MakePixelPerfect ()
		{
			base.MakePixelPerfect();

			if (mType == Type.Tiled)
			{
				return;
			}

			Texture tex = mainTexture;
			if (tex == null)
			{
				return;
			}

			if (mType == Type.Simple || mType == Type.Filled || !hasBorder)
			{
				if (tex != null)
				{
					int w = tex.width;
					int h = tex.height;

					if ((w & 1) == 1) ++w;
					if ((h & 1) == 1) ++h;

					width = w;
					height = h;
				}
			}
		}


		/// <summary>
		/// Virtual function called by the UIPanel that fills the buffers.
		/// </summary>

		public override void OnFill (BetterList<Vector3> verts, BetterList<Vector2> uvs, BetterList<Color32> cols)
		{
			Texture tex = mainTexture;
			if (tex == null)
			{
				return;
			}

			Rect mRect = UVRect;

			Rect outer = new Rect(mRect.x * tex.width, mRect.y * tex.height, tex.width * mRect.width, tex.height * mRect.height);
			Rect inner = outer;
			Vector4 br = border;
			inner.xMin += br.x;
			inner.yMin += br.y;
			inner.xMax -= br.z;
			inner.yMax -= br.w;

			float w = 1f / tex.width;
			float h = 1f / tex.height;

			outer.xMin *= w;
			outer.xMax *= w;
			outer.yMin *= h;
			outer.yMax *= h;

			inner.xMin *= w;
			inner.xMax *= w;
			inner.yMin *= h;
			inner.yMax *= h;

			int offset = verts.size;
			Fill(verts, uvs, cols, outer, inner);

			if (onPostFill != null)
				onPostFill(this, offset, verts, uvs, cols);
		}
				
		
		bool m_ForceRender = true;
		protected override void OnUpdate()
		{
			base.OnUpdate();

			AltGUIIntegration.Tick();

			if (m_RenderUpdateTimer.IsTimeOver
			    //TEST - Prevent m_RenderUpdateTimer.IsTimeOver delay
			    || AltSketchPaintHandler.MSecSinceLastRender >= m_RenderUpdateTimer.Interval
			    || m_ForceRender)
			{
				DoRenderIfNeed();
			}
		}
		
		
		public void Invalidate()
		{
			AltSketchPaintHandler.Invalidate();
		
			/*
			//TEST - Prevent m_RenderUpdateTimer.IsTimeOver delay
			if (AltSketchPaintHandler.MSecSinceLastRender >= m_RenderUpdateTimer.Interval)
			{
				DoRenderIfNeed();
			}*/
		}
		
		
		//  Paint
		
		event Alt.GUI.PaintEventHandler m_Paint;
		public event Alt.GUI.PaintEventHandler Paint
		{
			add
			{
				m_Paint += value;
			}
			remove
			{
				m_Paint -= value;
			}
		}
		
		// Allow for delegate-based subscriptions for faster events than 'eventReceiver', and allowing for multiple receivers.
		[SerializeField]
		private PaintEvent m_onPaint = new PaintEvent();
		public PaintEvent onPaint
		{
			get
			{
				return m_onPaint;
			}
			set
			{
				m_onPaint = value;
			}
		}
		
		
		protected virtual void OnPaint(Alt.GUI.PaintEventArgs e)
		{
		}
		
		protected virtual void OnPaintBackground(Alt.GUI.PaintEventArgs e)
		{
		}
		
		
		#if UNITY_EDITOR
		protected void EditorPaint(PaintEventArgs e)
		{
			if (!Application.isPlaying)
			{
				AltSketchPaintHandler.DrawEditorText(e,
				                                     GetEditorName(),
				                                     gameObject != null ? gameObject.name : "Unknown",
				                                     ClientSize,
				                                     MaxFPS,
				                                     RenderType);
				return;
			}
		}
		#endif


		void DoRenderIfNeed()
		{
			if (m_ForceRender)
			{
				Invalidate();
				m_ForceRender = false;
			}

			if (AltSketchPaintHandler.DoRenderIfNeed(GetComponent<Camera>(), GetComponent<Renderer>()))
			{
				m_RenderUpdateTimer.Reset();
			}
		}
		
		internal virtual void DoPaint(Alt.GUI.PaintEventArgs e)
		{
			#if UNITY_EDITOR
			if (!Application.isPlaying)
			{
				EditorPaint(e);

				return;
			}
			#endif

			OnPaintBackground(e);
			
			OnPaint(e);

			if (!e.Handled)
			{
				RaisePaint(e);
			}
		}

		protected void RaisePaint(PaintEventArgs e)
		{
			if (m_Paint != null)
			{
				m_Paint(this, e);
			}
			
			m_onPaint.Invoke(e);
		}

				
		public double ClientWidth
		{
			get
			{
				return mWidth;
			}
		}
		
		public double ClientHeight
		{
			get
			{
				return mHeight;
			}
		}
		
		public Alt.Sketch.Size ClientSize
		{
			get
			{
				return new Alt.Sketch.Size(ClientWidth, ClientHeight);
			}
		}
		
		public Alt.Sketch.Rect ClientRectangle
		{
			get
			{
				return new Alt.Sketch.Rect(Point.Zero, ClientSize);
			}
		}
	}
}
