﻿//  Copyright (C) 2012-2015 AltSoftLab Inc.
//  This source code is provided "as is" without express or implied warranty of any kind.

using System.Collections.Generic;

using UnityEngine;
using UnityEngine.NGUI;


[AddComponentMenu("AltGUI/NGUI/Examples/_Main NGUI Demo")]
public class AltGUI_NGUI_Demo : MonoBehaviour
{
	static Color s_SavedTextColor = new Color(50f / 255f, 50f / 255f, 50f / 255f, 1f);
	static Color s_SelectedTextColor = new Color(0f / 255f, 128f / 255f, 255f / 255f, 1f);

	const string s_Color_LightCyan = "[80FFFF]";
	const string s_Color_White = "[FFFFFF]";
	const string s_Color_Yellow = "[FFFF00]";
	const string s_Color_STOP = "[-]";

	const string sDemoPrefix = "AltGUIDemo_";
	const string sMenuPanel = sDemoPrefix + "MenuPanel";
	const string sWorkPanel = sDemoPrefix + "WorkPanel";
	const string sCaptionText = sDemoPrefix + "CaptionText";
	const string sExamplesText = sDemoPrefix + "ExamplesText";

	UIButton[] m_MenuButtons;


	class Example
	{
		public string Name;
		public UIButton Button;
		public GameObject GameObject;

		//	deffered initialisation
		public delegate void ScriptInitActionDelegate();
		public ScriptInitActionDelegate ScriptInitAction;


		public Example(string name, UIButton button, GameObject gameObject, ScriptInitActionDelegate scriptInitAction)
		{
			Name = name;
			Button = button;
			GameObject = gameObject;
			ScriptInitAction = scriptInitAction;
		}
	}

	Dictionary<string, Example> m_Examples = new Dictionary<string, Example>();
	Example m_CurrentExample;


	UIWidget MenuPanel_Widget
	{
		get
		{
			GameObject goMenuPanel = GameObject.Find(sMenuPanel);
			if (goMenuPanel == null)
			{
				return null;
			}
			
			return goMenuPanel.GetComponent<UIWidget>();
		}
	}
	
	
	UIWidget WorkPanel_Widget
	{
		get
		{
			GameObject goWorkPanel = GameObject.Find(sWorkPanel);
			if (goWorkPanel == null)
			{
				return null;
			}
			
			return goWorkPanel.GetComponent<UIWidget>();
		}
	}
	
	
	string CaptionText
	{
		set
		{
			GameObject goCaptionText = GameObject.Find(sCaptionText);
			if (goCaptionText == null)
			{
				return;
			}
			
			UILabel text = goCaptionText.GetComponent<UILabel>();
			if (text == null)
			{
				return;
			}
			
			text.text = value ?? string.Empty;
		}
	}
	
	string ExamplesText
	{
		set
		{
			GameObject goExamplesText = GameObject.Find(sExamplesText);
			if (goExamplesText == null)
			{
				return;
			}
			
			UILabel text = goExamplesText.GetComponent<UILabel>();
			if (text == null)
			{
				return;
			}
			
			text.text = value ?? string.Empty;
		}
	}

	
	// Use this for initialization
	void Start ()
	{
		ExamplesText = "[b]" + s_Color_Yellow + "AltGUI" + s_Color_STOP + "[/b] " + s_Color_LightCyan + "Examples:" + s_Color_STOP;

		CreateBaseUI();
		{
			LoadExamples();
		}
		CreateBaseUI2();
	
		StartExample("Gwen Complex Demo");
	}
	
	void CreateBaseUI()
	{
		//	MenuPanel
		{
			GameObject goMenuPanel = GameObject.Find(sMenuPanel);
			if (goMenuPanel == null)
			{
				return;
			}
			
			m_MenuButtons = goMenuPanel.GetComponentsInChildren<UIButton>();
			if (m_MenuButtons == null)
			{
				return;
			}
			
			UIWidget menuPanelWidget = MenuPanel_Widget;
			int dxy = 3;
			int dy = 0;
			int w = (int)(menuPanelWidget.width - dxy * 2);
			int h = (int)(((menuPanelWidget.height - dxy * 2)) / (m_MenuButtons.Length != 0 ? m_MenuButtons.Length : 1) - dy);
			float x = 0;
			float y = menuPanelWidget.localCorners[2].y - dxy - h / 2 - 1;
			
			foreach (UIButton b in m_MenuButtons)
			{
				GameObject buttonGameObject = b.gameObject;
				buttonGameObject.SetActive(false);
				
				buttonGameObject.transform.localPosition = new Vector3(x, y);
				
				UIWidget widget = buttonGameObject.GetComponent<UIWidget>();
				widget.width = w;
				widget.height = h;
				
				y -= h + dy;
			}
		}
	}
	
	void CreateBaseUI2()
	{
		//	MenuPanel
		{
			UIWidget menuPanelWidget = MenuPanel_Widget;
			int dxy = 3;
			int dy = 0;
			int w = (int)(menuPanelWidget.width - dxy * 2);
			int h = (int)(((menuPanelWidget.height - dxy * 2)) / (m_Examples.Count != 0 ? m_Examples.Count : 1) - dy);
			float x = 0;
			float y = menuPanelWidget.localCorners[2].y - dxy - h / 2 - 1;
			
			foreach (UIButton b in m_MenuButtons)
			{
				GameObject buttonGameObject = b.gameObject;

				buttonGameObject.transform.localPosition = new Vector3(x, y);
				
				UIWidget widget = buttonGameObject.GetComponent<UIWidget>();
				widget.width = w;
				widget.height = h;
				
				y -= h + dy;
			}
		}
	}


	void LoadExamples()
	{
		AddExample<AltGUIGwenComplexDemo_NGUI>("Gwen Complex Demo", "AltGUIControlHost Gwen");
		AddExample<AltGUIGMapDemo_NGUI>("GMap", "AltGUIGMap", false);
		AddExample<AltGUIHtmlPanelDemo_NGUI>("Html Panel", "AltGUIHtmlPanel");
		AddExample<AltGUIHtmlLabelDemo_NGUI>("Html Label", "AltGUIHtmlLabel");
		AddExample<AltGUIICSharpCodeTextEditorDemo_NGUI>("ICSC TextEditor (Coming soon)", "AltGUIICSharpCodeTextEditor");
		AddExample<AltGUIRichTextBoxDemo_NGUI>("RichTextBox (Coming soon)", "AltGUIRichTextBox", false);
		AddExample<AltGUIOxyPlotDemo_NGUI>("OxyPlot", "AltGUIOxyPlot");
		AddExample<AltGUIOxyPlotMapDemo_NGUI>("OxyPlot Map", "AltGUIOxyPlot Map", false);
		AddExample<AltGUINPlotDemo_NGUI>("NPlot", "AltGUINPlot");
		AddExample<AltGUI3DPieChartDemo_NGUI>("3DPie Chart", "AltGUI3DPieChart");
		AddExample<AltGUIZedGraphDemo_NGUI>("ZedGraph", "AltGUIZedGraph");
		AddExample<AltGUISvgDemo_NGUI>("SVG", "AltGUISvg");
		
		AddExample<AltGUIQuickFontDemo_NGUI>("QuickFont", "AltGUIQuickFont");
		//	start long time background initialization
		AltGUIQuickFontDemo.Initialize();
		
		AddExample<AltGUIAForgeFilteredPictureBoxDemo_NGUI>("AForge Filtered PictureBox", "AltGUIAForgeFilteredPictureBox", false);
		AddExample<AltGUIPictureBoxDemo_NGUI>("PictureBox (GIF image)", "AltGUIPictureBox");
		AddExample<AltGUIBox2DDemo_NGUI>("Box2D", "AltGUIBox2D");
		AddExample<AltGUIFarseerPhysicsDemo_NGUI>("Farseer Physics", "AltGUIFarseerPhysics");
		AddExample<AltGUIControlHostDemo_NGUI>("AltGUI Control Host", "AltGUIControlHost");
		AddExample<AltSketchPaintDemo_NGUI>("AltSketch Paint", "AltSketchPaint Demo");
		AddExample<AltGUIAwesomiumDemo_NGUI>("Awesomium", "AltGUIAwesomium");
	}

	
	void AddExample<TScriptClass>(string name, string controlName) where TScriptClass : MonoBehaviour
	{
		AddExample<TScriptClass>(name, controlName, true);
	}
	
	void AddExample<TScriptClass>(string name, string controlName, bool useInWeb) where TScriptClass : MonoBehaviour
	{
		//	Button
		UIButton button = null;
		{
			if (m_MenuButtons == null ||
			    m_MenuButtons.Length <= m_Examples.Count)
			{
				return;
			}

			string buttonName = "Button " + m_Examples.Count.ToString();
			foreach (UIButton b in m_MenuButtons)
			{
				if (string.Compare(b.gameObject.name, buttonName) == 0)
				{
					button = b;
					break;
				}
			}

			if (button == null)
			{
				return;
			}
		}


		//	Control
		GameObject controlGameObject = null;
		{
			GameObject goWorkPanel = GameObject.Find(sWorkPanel);
			if (goWorkPanel == null)
			{
				return;
			}
			
			UIWidget[] uiWidgets = goWorkPanel.GetComponentsInChildren<UIWidget>();
			if (uiWidgets == null)
			{
				return;
			}

			UIWidget uiWidget = null;
			foreach (UIWidget b in uiWidgets)
			{
				if (string.Compare(b.gameObject.name, controlName) == 0)
				{
					uiWidget = b;
					break;
				}
			}
			
			if (uiWidget == null)
			{
				return;
			}

			controlGameObject = uiWidget.gameObject;
		}


		//
		controlGameObject.SetActive(false);
				
		#if UNITY_WEBPLAYER
		if (!useInWeb)
		{
			return;
		}
		#endif


		//
		button.gameObject.SetActive(true);
		
		UILabel text = button.GetComponentInChildren<UILabel>();
		text.fontSize = 16;
		text.text = name;

		button.onClick.Add(new EventDelegate(() => OnMenuButtonClick(name)));


		m_Examples.Add(name, new Example(
			name,
			button,
			controlGameObject,
			delegate(){controlGameObject.AddComponent<TScriptClass>();}));
	}


	// Update is called once per frame
	void Update ()
	{
		//UpdateSize();
	}

	void UpdateSize()
	{
		if (m_CurrentExample == null)
		{
			return;
		}

		GameObject controlGameObject = m_CurrentExample.GameObject;

		UIWidget workPanelWidget = WorkPanel_Widget;
		controlGameObject.transform.localPosition = new Vector3(0, 0);

		UIWidget widget = controlGameObject.GetComponent<UIWidget>();
		if (widget != null)
		{
			widget.autoResizeBoxCollider = true;
			widget.SetDimensions(workPanelWidget.width - 10, workPanelWidget.height - 10);
			widget.ResizeCollider();
		}
	}


	public void OnMenuButtonClick(string name)
	{
		StartExample(name);
	}


	void StartExample(string name)
	{
		if (m_CurrentExample != null)
		{
		    if (m_CurrentExample.Name == name)
			{
				return;
			}
		}
		
		Example prevExample = m_CurrentExample;
		m_CurrentExample = null;

		if (!m_Examples.TryGetValue(name, out m_CurrentExample) ||
		    m_CurrentExample == null)
		{
			CaptionText = "Example '" + name + "'not found...";

			HideExample(prevExample);

			return;
		}


		CaptionText = "[b]" + s_Color_Yellow + "AltGUI" + s_Color_STOP + "[/b]" + s_Color_LightCyan + " NGUI Example - " + s_Color_STOP +
			"[b][i]" + s_Color_White + name + s_Color_STOP + "[/i][/b]";

		SetMenuButtonTextColor(m_CurrentExample.Button, s_SelectedTextColor);

		UpdateSize();


		if (m_CurrentExample.ScriptInitAction != null)
		{
			m_CurrentExample.ScriptInitAction();
			m_CurrentExample.ScriptInitAction = null;
		}
		m_CurrentExample.GameObject.SetActive(true);

		UIWidget widget = m_CurrentExample.GameObject.GetComponent<UIWidget>();
		widget.ResizeCollider();
		
		
		HideExample(prevExample);


		UICamera.selectedObject = m_CurrentExample.GameObject;
	}
	
	void HideExample(Example example)
	{
		if (example != null)
		{
			SetMenuButtonTextColor(example.Button, s_SavedTextColor);
			example.GameObject.SetActive(false);
		}
	}
	
	
	
	void SetMenuButtonTextColor(UIButton button, Color color)
	{
		UILabel text = button.gameObject.GetComponentInChildren<UILabel>();
		if (text != null)
		{
			s_SavedTextColor = text.color;
			text.color = color;
		}
	}
}
