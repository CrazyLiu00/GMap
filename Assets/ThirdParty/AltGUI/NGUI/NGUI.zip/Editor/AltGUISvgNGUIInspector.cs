//  Copyright (C) 2012-2015 AltSoftLab Inc.
//  This source code is provided "as is" without express or implied warranty of any kind.

using UnityEngine;
using UnityEngine.NGUI;


namespace UnityEditor.NGUI
{
	/// <summary>
	/// Inspector class used to edit AltGUISvgNGUI.
	/// </summary>

	[CanEditMultipleObjects]
	[CustomEditor(typeof(AltGUISvgNGUI), true)]
	public class AltGUISvgNGUIInspector : AltGUIControlHostNGUIInspector
	{
	}
}
