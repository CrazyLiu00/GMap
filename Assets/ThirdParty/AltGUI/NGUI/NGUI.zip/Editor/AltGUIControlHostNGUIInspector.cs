//  Copyright (C) 2012-2015 AltSoftLab Inc.
//  This source code is provided "as is" without express or implied warranty of any kind.

using UnityEngine;
using UnityEngine.NGUI;


namespace UnityEditor.NGUI
{
	/// <summary>
	/// Inspector class used to edit AltGUIControlHostNGUI.
	/// </summary>

	[CanEditMultipleObjects]
	[CustomEditor(typeof(AltGUIControlHostNGUI), true)]
	public class AltGUIControlHostNGUIInspector : AltSketchPaintNGUIInspector
	{
	}
}
