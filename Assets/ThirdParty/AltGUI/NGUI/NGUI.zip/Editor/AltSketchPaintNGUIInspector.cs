//  Copyright (C) 2012-2015 AltSoftLab Inc.
//  This source code is provided "as is" without express or implied warranty of any kind.

using UnityEngine;
using UnityEngine.NGUI;


namespace UnityEditor.NGUI
{
	/// <summary>
	/// Inspector class used to edit AltSketchPaintNGUI.
	/// </summary>

	[CanEditMultipleObjects]
	[CustomEditor(typeof(AltSketchPaintNGUI), true)]
	public class AltSketchPaintNGUIInspector : UIBasicSpriteEditor
	{
		AltSketchPaintNGUI m_AltSketchPaint;


		protected override void OnEnable ()
		{
			base.OnEnable();

			m_AltSketchPaint = target as AltSketchPaintNGUI;
		}


		protected override bool ShouldDrawProperties ()
		{
			if (target == null)
			{
				return false;
			}

			NGUIEditorTools.DrawProperty("Material", serializedObject, "mMat");

			if (m_AltSketchPaint != null && (m_AltSketchPaint.material == null || serializedObject.isEditingMultipleObjects))
			{
				NGUIEditorTools.DrawProperty("Shader", serializedObject, "mShader");
			}


			//	Unity UI Editor adaptation:
			{
				EditorGUILayout.Space();
				//EditorGUILayout.PropertyField(m_MaxFPS);
				NGUIEditorTools.DrawProperty("Max FPS", serializedObject, "m_MaxFPS");
				//EditorGUILayout.PropertyField(m_RenderType);
				NGUIEditorTools.DrawProperty("Render Type", serializedObject, "m_RenderType");
				
				EditorGUILayout.Space();
				// Draw the event notification options
				//EditorGUILayout.PropertyField(m_onPaint);
				NGUIEditorTools.DrawProperty("onPaint", serializedObject, "m_onPaint");
			}


			return true;
		}


		/// <summary>
		/// Allow the texture to be previewed.
		/// </summary>

		public override bool HasPreviewGUI ()
		{
			return (Selection.activeGameObject == null || Selection.gameObjects.Length == 1) &&
				(m_AltSketchPaint != null) && (m_AltSketchPaint.mainTexture as Texture2D != null);
		}


		/// <summary>
		/// Draw the sprite preview.
		/// </summary>

		public override void OnPreviewGUI (Rect rect, GUIStyle background)
		{
			Texture2D tex = m_AltSketchPaint.mainTexture as Texture2D;

			if (tex != null)
			{
				Rect tc = m_AltSketchPaint.UVRect;
				tc.xMin *= tex.width;
				tc.xMax *= tex.width;
				tc.yMin *= tex.height;
				tc.yMax *= tex.height;
				NGUIEditorTools.DrawSprite(tex, rect, m_AltSketchPaint.color, tc, m_AltSketchPaint.border);
			}
		}
	}
}
