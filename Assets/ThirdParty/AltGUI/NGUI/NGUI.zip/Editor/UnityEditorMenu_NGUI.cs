//  Copyright (C) 2012-2015 AltSoftLab Inc.
//  This source code is provided "as is" without express or implied warranty of any kind.

using System;
using System.Collections.Generic;

using UnityEngine;
using UnityEngine.NGUI;
using UnityEditor.NGUI;


namespace UnityEditor
{
	/// <summary>
	/// This script adds the AltGUI menu options to the Unity Editor.
	/// </summary>

	static partial class AltGUIUnityEditorMenu
	{
		public const string EditorAltGUIPathNGUI = "AltGUI/NGUI/";
		public const string EditorNGUIPath = "GameObject/NGUI/AltGUI/";
		public const string EditorAssetsPathNGUI = "Assets/AltGUI/NGUI/Create ";
		public const string EditorNGUICreate = "NGUI/Create/AltGUI/";


		static string ClearTypeName(string name)
		{
			if (string.IsNullOrEmpty(name) ||
			    !name.EndsWith("NGUI"))
			{
				return name;
			}

			return name.Substring(0, name.Length - "NGUI".Length);
		}

		
		static AltSketchPaintNGUI CreateAltSketchPaintNGUI(GameObject go)
		{
			AltSketchPaintNGUI w = NGUITools.AddWidget<AltSketchPaintNGUI>(go);
			w.name = ClearTypeName(typeof(AltSketchPaintNGUI).Name);
			w.pivot = NGUISettings.pivot;
			w.width = 100;
			w.height = 100;

			return w;
		}

		[MenuItem(EditorAltGUIPathNGUI + AltSketchPaintNGUI.EditorName, false, AltSketchPaintNGUI.EditorID)]
		[MenuItem(EditorNGUIPath + AltSketchPaintNGUI.EditorName, false, AltSketchPaintNGUI.EditorID)]
		[MenuItem(EditorAssetsPathNGUI + AltSketchPaintNGUI.EditorName, false)]
		[MenuItem(EditorNGUICreate + AltSketchPaintNGUI.EditorName, false, AltSketchPaintNGUI.EditorID)]
		public static void Add_AltSketchPaintNGUI(MenuCommand menuCommand)
		{
			GameObject go = NGUIEditorTools.SelectedRoot(true);
			
			if (go != null)
			{
				Selection.activeGameObject = CreateAltSketchPaintNGUI(go).gameObject;
			}
			else
			{
				Debug.Log("You must select a game object first.");
			}
		}



		static T CreateAltGUIHostNGUIBasedObject<T>(GameObject go) where T : AltGUIControlHostNGUI
		{
			T w = NGUITools.AddWidget<T>(go);
			w.name = ClearTypeName(typeof(T).Name);
			w.pivot = NGUISettings.pivot;
			w.width = 100;
			w.height = 100;

			w.autoResizeBoxCollider = true;
			NGUITools.AddWidgetCollider(w.gameObject);

			return w;
		}
		
		static void CreateAltGUIHostNGUIBasedObject<T>() where T : AltGUIControlHostNGUI
		{
			GameObject go = NGUIEditorTools.SelectedRoot(true);
			
			if (go != null)
			{
				Selection.activeGameObject = CreateAltGUIHostNGUIBasedObject<T>(go).gameObject;
			}
			else
			{
				Debug.Log("You must select a game object first.");
			}
		}


		[MenuItem(EditorAltGUIPathNGUI + AltGUIControlHostNGUI.EditorName, false, AltGUIControlHostNGUI.EditorID)]
		[MenuItem(EditorNGUIPath + AltGUIControlHostNGUI.EditorName, false, AltGUIControlHostNGUI.EditorID)]
		[MenuItem(EditorAssetsPathNGUI + AltGUIControlHostNGUI.EditorName, false)]
		[MenuItem(EditorNGUICreate + AltGUIControlHostNGUI.EditorName, false, AltGUIControlHostNGUI.EditorID)]
		public static void Add_AltGUIControlHostNGUI(MenuCommand menuCommand)
		{
			CreateAltGUIHostNGUIBasedObject<AltGUIControlHostNGUI>();
		}



		[MenuItem(EditorAltGUIPathNGUI + AltGUI3DPieChartNGUI.EditorName, false, AltGUI3DPieChartNGUI.EditorID)]
		[MenuItem(EditorNGUIPath + AltGUI3DPieChartNGUI.EditorName, false, AltGUI3DPieChartNGUI.EditorID)]
		[MenuItem(EditorNGUICreate + AltGUI3DPieChartNGUI.EditorName, false, AltGUI3DPieChartNGUI.EditorID)]
		public static void Add_AltGUI3DPieChartNGUI(MenuCommand menuCommand)
		{
			CreateAltGUIHostNGUIBasedObject<AltGUI3DPieChartNGUI>();
		}


		[MenuItem(EditorAltGUIPathNGUI + AltGUIAForgeFilteredPictureBoxNGUI.EditorName, false, AltGUIAForgeFilteredPictureBoxNGUI.EditorID)]
		[MenuItem(EditorNGUIPath + AltGUIAForgeFilteredPictureBoxNGUI.EditorName, false, AltGUIAForgeFilteredPictureBoxNGUI.EditorID)]
		[MenuItem(EditorNGUICreate + AltGUIAForgeFilteredPictureBoxNGUI.EditorName, false, AltGUIAForgeFilteredPictureBoxNGUI.EditorID)]
		public static void Add_AltGUIAForgeFilteredPictureBoxNGUI(MenuCommand menuCommand)
		{
			CreateAltGUIHostNGUIBasedObject<AltGUIAForgeFilteredPictureBoxNGUI>();
		}


		[MenuItem(EditorAltGUIPathNGUI + AltGUIAwesomiumNGUI.EditorName, false, AltGUIAwesomiumNGUI.EditorID)]
		[MenuItem(EditorNGUIPath + AltGUIAwesomiumNGUI.EditorName, false, AltGUIAwesomiumNGUI.EditorID)]
		[MenuItem(EditorNGUICreate + AltGUIAwesomiumNGUI.EditorName, false, AltGUIAwesomiumNGUI.EditorID)]
		public static void Add_AltGUIAwesomiumNGUI(MenuCommand menuCommand)
		{
			CreateAltGUIHostNGUIBasedObject<AltGUIAwesomiumNGUI>();
		}


		[MenuItem(EditorAltGUIPathNGUI + AltGUIBox2DNGUI.EditorName, false, AltGUIBox2DNGUI.EditorID)]
		[MenuItem(EditorNGUIPath + AltGUIBox2DNGUI.EditorName, false, AltGUIBox2DNGUI.EditorID)]
		[MenuItem(EditorNGUICreate + AltGUIBox2DNGUI.EditorName, false, AltGUIBox2DNGUI.EditorID)]
		public static void Add_AltGUIBox2DNGUI(MenuCommand menuCommand)
		{
			CreateAltGUIHostNGUIBasedObject<AltGUIBox2DNGUI>();
		}


		[MenuItem(EditorAltGUIPathNGUI + AltGUIFarseerPhysicsNGUI.EditorName, false, AltGUIFarseerPhysicsNGUI.EditorID)]
		[MenuItem(EditorNGUIPath + AltGUIFarseerPhysicsNGUI.EditorName, false, AltGUIFarseerPhysicsNGUI.EditorID)]
		[MenuItem(EditorNGUICreate + AltGUIFarseerPhysicsNGUI.EditorName, false, AltGUIFarseerPhysicsNGUI.EditorID)]
		public static void Add_AltGUIFarseerPhysicsNGUI(MenuCommand menuCommand)
		{
			CreateAltGUIHostNGUIBasedObject<AltGUIFarseerPhysicsNGUI>();
		}


		[MenuItem(EditorAltGUIPathNGUI + AltGUIGMapNGUI.EditorName, false, AltGUIGMapNGUI.EditorID)]
		[MenuItem(EditorNGUIPath + AltGUIGMapNGUI.EditorName, false, AltGUIGMapNGUI.EditorID)]
		[MenuItem(EditorNGUICreate + AltGUIGMapNGUI.EditorName, false, AltGUIGMapNGUI.EditorID)]
		public static void Add_AltGUIGMapNGUI(MenuCommand menuCommand)
		{
			CreateAltGUIHostNGUIBasedObject<AltGUIGMapNGUI>();
		}


		[MenuItem(EditorAltGUIPathNGUI + AltGUIHtmlLabelNGUI.EditorName, false, AltGUIHtmlLabelNGUI.EditorID)]
		[MenuItem(EditorNGUIPath + AltGUIHtmlLabelNGUI.EditorName, false, AltGUIHtmlLabelNGUI.EditorID)]
		[MenuItem(EditorNGUICreate + AltGUIHtmlLabelNGUI.EditorName, false, AltGUIHtmlLabelNGUI.EditorID)]
		public static void Add_AltGUIHtmlLabelNGUI(MenuCommand menuCommand)
		{
			CreateAltGUIHostNGUIBasedObject<AltGUIHtmlLabelNGUI>();
		}


		[MenuItem(EditorAltGUIPathNGUI + AltGUIHtmlPanelNGUI.EditorName, false, AltGUIHtmlPanelNGUI.EditorID)]
		[MenuItem(EditorNGUIPath + AltGUIHtmlPanelNGUI.EditorName, false, AltGUIHtmlPanelNGUI.EditorID)]
		[MenuItem(EditorNGUICreate + AltGUIHtmlPanelNGUI.EditorName, false, AltGUIHtmlPanelNGUI.EditorID)]
		public static void Add_AltGUIHtmlPanelNGUI(MenuCommand menuCommand)
		{
			CreateAltGUIHostNGUIBasedObject<AltGUIHtmlPanelNGUI>();
		}

		
		[MenuItem(EditorAltGUIPathNGUI + AltGUIICSharpCodeTextEditorNGUI.EditorName, false, AltGUIICSharpCodeTextEditorNGUI.EditorID)]
		[MenuItem(EditorNGUIPath + AltGUIICSharpCodeTextEditorNGUI.EditorName, false, AltGUIICSharpCodeTextEditorNGUI.EditorID)]
		[MenuItem(EditorNGUICreate + AltGUIICSharpCodeTextEditorNGUI.EditorName, false, AltGUIICSharpCodeTextEditorNGUI.EditorID)]
		public static void Add_AltGUIICSharpCodeTextEditorNGUI(MenuCommand menuCommand)
		{
			CreateAltGUIHostNGUIBasedObject<AltGUIICSharpCodeTextEditorNGUI>();
		}


		[MenuItem(EditorAltGUIPathNGUI + AltGUINPlotNGUI.EditorName, false, AltGUINPlotNGUI.EditorID)]
		[MenuItem(EditorNGUIPath + AltGUINPlotNGUI.EditorName, false, AltGUINPlotNGUI.EditorID)]
		[MenuItem(EditorNGUICreate + AltGUINPlotNGUI.EditorName, false, AltGUINPlotNGUI.EditorID)]
		public static void Add_AltGUINPlotNGUI(MenuCommand menuCommand)
		{
			CreateAltGUIHostNGUIBasedObject<AltGUINPlotNGUI>();
		}


		[MenuItem(EditorAltGUIPathNGUI + AltGUIOxyPlotNGUI.EditorName, false, AltGUIOxyPlotNGUI.EditorID)]
		[MenuItem(EditorNGUIPath + AltGUIOxyPlotNGUI.EditorName, false, AltGUIOxyPlotNGUI.EditorID)]
		[MenuItem(EditorNGUICreate + AltGUIOxyPlotNGUI.EditorName, false, AltGUIOxyPlotNGUI.EditorID)]
		public static void Add_AltGUIOxyPlotNGUI(MenuCommand menuCommand)
		{
			CreateAltGUIHostNGUIBasedObject<AltGUIOxyPlotNGUI>();
		}

		
		[MenuItem(EditorAltGUIPathNGUI + AltGUIPictureBoxNGUI.EditorName, false, AltGUIPictureBoxNGUI.EditorID)]
		[MenuItem(EditorNGUIPath + AltGUIPictureBoxNGUI.EditorName, false, AltGUIPictureBoxNGUI.EditorID)]
		[MenuItem(EditorNGUICreate + AltGUIPictureBoxNGUI.EditorName, false, AltGUIPictureBoxNGUI.EditorID)]
		public static void Add_AltGUIPictureBoxNGUI(MenuCommand menuCommand)
		{
			CreateAltGUIHostNGUIBasedObject<AltGUIPictureBoxNGUI>();
		}


		[MenuItem(EditorAltGUIPathNGUI + AltGUIQuickFontNGUI.EditorName, false, AltGUIQuickFontNGUI.EditorID)]
		[MenuItem(EditorNGUIPath + AltGUIQuickFontNGUI.EditorName, false, AltGUIQuickFontNGUI.EditorID)]
		[MenuItem(EditorNGUICreate + AltGUIQuickFontNGUI.EditorName, false, AltGUIQuickFontNGUI.EditorID)]
		public static void Add_AltGUIQuickFontNGUI(MenuCommand menuCommand)
		{
			CreateAltGUIHostNGUIBasedObject<AltGUIQuickFontNGUI>();
		}

		
		[MenuItem(EditorAltGUIPathNGUI + AltGUIRichTextBoxNGUI.EditorName, false, AltGUIRichTextBoxNGUI.EditorID)]
		[MenuItem(EditorNGUIPath + AltGUIRichTextBoxNGUI.EditorName, false, AltGUIRichTextBoxNGUI.EditorID)]
		[MenuItem(EditorNGUICreate + AltGUIRichTextBoxNGUI.EditorName, false, AltGUIRichTextBoxNGUI.EditorID)]
		public static void Add_AltGUIRichTextBoxNGUI(MenuCommand menuCommand)
		{
			CreateAltGUIHostNGUIBasedObject<AltGUIRichTextBoxNGUI>();
		}


		[MenuItem(EditorAltGUIPathNGUI + AltGUISvgNGUI.EditorName, false, AltGUISvgNGUI.EditorID)]
		[MenuItem(EditorNGUIPath + AltGUISvgNGUI.EditorName, false, AltGUISvgNGUI.EditorID)]
		[MenuItem(EditorNGUICreate + AltGUISvgNGUI.EditorName, false, AltGUISvgNGUI.EditorID)]
		public static void Add_AltGUISvgNGUI(MenuCommand menuCommand)
		{
			CreateAltGUIHostNGUIBasedObject<AltGUISvgNGUI>();
		}


		[MenuItem(EditorAltGUIPathNGUI + AltGUIZedGraphNGUI.EditorName, false, AltGUIZedGraphNGUI.EditorID)]
		[MenuItem(EditorNGUIPath + AltGUIZedGraphNGUI.EditorName, false, AltGUIZedGraphNGUI.EditorID)]
		[MenuItem(EditorNGUICreate + AltGUIZedGraphNGUI.EditorName, false, AltGUIZedGraphNGUI.EditorID)]
		public static void Add_AltGUIZedGraphNGUI(MenuCommand menuCommand)
		{
			CreateAltGUIHostNGUIBasedObject<AltGUIZedGraphNGUI>();
		}
	}
}
